# Vexaronet – nasazení úvodní stránky
Soubory: index.html, 404.html, robots.txt, sitemap.xml, netlify.toml, netlify/functions/chat.mjs.
1. Nahraj složku na GitHub a na Netlify zvol Import from Git (build příkaz prázdný, publish složka ".").
2. Netlify, Environment variables: GEMINI_API_KEY (klíč z Google AI Studia, nikdy ho neposílej do chatu). Volitelně GEMINI_MODEL.
3. Deploy znovu, aby se proměnná načetla.
4. Formulář early access: Netlify, Forms, zapni e-mailové notifikace.
5. Doména vexaronet.com přidej v Domain management.
Bez klíče chat napíše, že není dostupný.

## Supabase (přihlášení a registrace)
- V index.html jsou nahoře v JS konstanty SB_URL a SB_KEY (veřejný publishable klíč, smí být ve webu). Tajný klíč (sb_secret / service_role) NIKDY nevkládej do webu.
- V Supabase: Authentication, URL Configuration, do "Site URL" a "Redirect URLs" přidej https://vexaronet.com (a adresu z Netlify), jinak odkaz z potvrzovacího e-mailu povede jinam.
- Hodnoty tarifů (PLAN_VALUE) musí odpovídat tomu, co přijímá funkce create_company_for_plan.

## Ranní přehled do e-mailu a pobočky
1. V Supabase SQL editoru spusťte `schema_prehled_pobocky.sql` (tabulky locations a digest_settings, sloupec location_id).
2. V Cloudflare Pages (Settings → Variables and Secrets) přidejte: `DIGEST_SECRET` (libovolné dlouhé heslo), `SUPABASE_SERVICE_KEY` (service_role klíč z Supabase, Project Settings → API; tajný, nikam jinam). `RESEND_API_KEY` a volitelně `GEMINI_API_KEY` už máte.
3. V Supabase zapněte rozšíření pg_cron a pg_net (Database → Extensions) a spusťte `cron.schedule` z konce souboru schema_prehled_pobocky.sql s vaším DIGEST_SECRET.
4. V aplikaci na Přehledu: Dnes ve firmě → Zapnout ranní e-mail → Poslat zkušební.

## Docházka zaměstnanců (online / offline) a odpracované hodiny
1. V Supabase SQL Editoru spusťte celý soubor `schema_dochazka.sql` (jednou). Vytvoří tabulku `time_entries`, funkce `clock_in` a `clock_out` a dovolí členům firmy přidávat a upravovat zákazníky, zakázky a úkoly (mazat nemohou).
2. Majitel nebo správce vyznačí směny v Kalendáři (jméno nebo e-mail zaměstnance musí odpovídat jeho účtu).
3. Zaměstnanec po přihlášení vidí na Přehledu kartu **Moje docházka**: při příchodu na směnu klikne na **Přijít na směnu (online)**, při odchodu na **Odejít (offline)**. Čas bere server, ne telefon.
4. Majitel vidí v části **Zaměstnanci** kdo je online, odpracované hodiny za tento měsíc i celkem a poslední záznamy. Zapomenutou směnu ukončí tlačítkem **Ukončit**.
5. Zaměstnanec může přidávat zákazníky a zakázky. Faktury, finance a AI CEO nevidí.
6. **Hodinová sazba a výdělek:** v SQL Editoru jednou spusťte `schema_sazby.sql`. Pak majitel nebo správce zadá v části Zaměstnanci u každého člověka sazbu v Kč za hodinu. U každého se zobrazí výdělek za odpracované hodiny tento měsíc a součet za tým. Sazbu vidí jen majitel/správce a zaměstnanec u sebe. Jde o orientační přehled, ne o mzdovou agendu (daně a odvody se nepočítají).

## Poptávky na systém na míru
Poptávka se ukládá do samostatné tabulky `custom_inquiries` (soubor `schema_poptavky.sql`, spustit jednou v Supabase SQL Editoru) a nezávisí na odběru novinek. Majiteli přijde e-mail „Poptávka: systém na míru“ (potřebuje `RESEND_API_KEY` a `NOTIFY_EMAIL` v Cloudflare). Pokud selže uložení i e-mail, formulář zobrazí chybu a zákazník uvidí e-mail info@vexaronet.com.

## AI CEO – etapa 2

V záložce **AI CEO** (tarif PRO a vyšší) přibylo:
- **Zdraví firmy** – skóre 0–100 ze šesti oblastí (platby, zakázky v termínu, úkoly, aktivita zákazníků, rozložení tržeb, vývoj příjmů). Je to orientační ukazatel z dat v aplikaci, nikoli účetní hodnocení. Oblast bez dat se do skóre nepočítá. Skóre je i na přehledu.
- **Výhled na 30 dní** – očekávané platby podle splatnosti faktur a průměrné výdaje. Bez zůstatku na účtu, proto jen orientační.
- **Měsíční cíl** fakturace s průběhem a hrubým odhadem konce měsíce (ukládá se k účtu, záloha v prohlížeči).
- **Nová doporučení** z reálných dat: závislost na jednom zákazníkovi, zákazníci bez zakázky 90 dní, hotové zakázky bez faktury, zapomenutá směna (>12 h), ohrožený cíl.
- **Týdenní report** – fakta za 7 dní ke zkopírování + tlačítko pro slovní shrnutí od AI.
Žádné nové SQL není potřeba. Po nasazení je nutný redeploy funkce advisor (děje se automaticky při pushi).


## Zpětná vazba z aplikace
V Supabase SQL Editoru jednou spusťte `schema_zpetna_vazba.sql`. V aplikaci je v levém menu tlačítko **Něco nefunguje?**: uživatel vybere typ (problém, nápad, jiné) a napíše zprávu. Ukládá se do tabulky `feedback` (Supabase, Table Editor, feedback) i s e-mailem, stránkou a prohlížečem. Pokud tabulka ještě neexistuje, nabídne se odeslání e-mailem na info@vexaronet.com.


## Etapa zhezčování (říjen 2026)
Oprava horního menu (nezalamuje se, na středních šířkách se schová tlačítko Vyzkoušet), ořezaný text v tlačítkách ceníku, kratší nadpis na úvodu a aktuální stav vývoje (hotové: online rezervace, zaměstnanci a docházka s hodinami a výdělkem; etapa Finance a fakturace je rozpracovaná).

## Přizpůsobení podle oboru

Obor zvolený při registraci (Autoservis, Řemeslník, Restaurace, Služby, Kadeřnictví a krása, Obchod, Jiný obor) přepíná aplikaci:
pořadí a názvy menu (ostatní moduly jsou v "Další moduly"), stavy a šablonu zakázky, doporučené služby pro online objednání,
kartu "Začínáme", otázky AI CEO. Obor lze změnit v Nastavení → "Zaměření aplikace podle oboru"; v ukázce přepínačem "Obor".
Žádné nové DB sloupce, nic se nemaže – všechny moduly zůstávají dostupné.

## Import a export zákazníků (CSV)

V části Zákazníci je tlačítko "Import z CSV / Excelu": soubor se uloží jako CSV, rozpozná se záhlaví (Jméno/Firma, E-mail, Telefon, IČO, DIČ, Adresa, Poznámka), zobrazí se náhled a až po potvrzení se zákazníci uloží. Duplicity (stejný e-mail nebo jméno) se přeskočí, START má limit 50 zákazníků. "Export do CSV" je u zákazníků i zakázek. Testuje tests/imp.py.

## Databáze (stav 31. 10. 2026)

- Zkušební doba: výchozí 30 dní, START je rovnou "active" bez trial_end (sloupec trial_end už může být NULL).
- private.writable() povoluje zápis i pro plan='start' ve stavu active (bez paid_until).
- Tabulky member_rates a feedback (s rozšířenými sloupci email, page, user_agent) jsou v Supabase již vytvořené.
- Fakturace ověřena proti skutečné databázi (profile → start → issue, v transakci s rollbackem).

## E-shop (PRO a vyšší)

- Menu **E-shop**: nastavení obchodu (adresa, název, doprava, texty), seznam zboží a objednávek.
- Zboží se v obchodě zobrazí, když je ve **Skladu** zaškrtnuto „Zobrazit v e-shopu“ a má prodejní cenu. Zákazník vidí dostupné množství (nejvýše 50 ks).
- Veřejný obchod: `https://vexaronet.com/?s=adresa-obchodu` (bez registrace zákazníka).
- Objednávka proběhne v jedné databázové transakci (`public_shop_order`): kontrola skladu (nelze přeprodat), založení zákazníka, zakázky (stav Nová), objednávky, odpis ze skladu a vystavení faktury stejnou funkcí jako ruční fakturace (číslování, DPH).
- Po zaplacení označíte objednávku jako zaplacenou (označí i fakturu). Zrušení objednávky vrátí zboží na sklad, vystavenou fakturu je nutné stornovat ručně.
- Omezení (psát otevřeně): žádná platební brána (platba převodem), faktura se zákazníkovi neposílá e-mailem automaticky, bez fakturačních údajů se obchod veřejně nezobrazí.
- Databáze: `schema_eshop.sql` (tabulky shop_settings, shop_orders, shop_order_items, funkce public_shop, public_shop_order, shop_cancel_order). Ověřeno v transakci s rollbackem na ostré DB.
- Stavy zakázek: databáze povoluje jen kanonické kódy (new/progress/waiting/done/canceled); názvy podle oboru se ukládají do sloupce `jobs.stage`.

## Stažení aplikace (PWA, bez Google Play)

- Tlačítko „Stáhnout aplikaci“ na úvodní stránce (hero, menu, patička) otevře výběr Android / Windows / iPhone / Mac s návodem a tlačítkem Nainstalovat.
- Technicky: `manifest.webmanifest`, `sw.js` (síť má přednost, API se neukládá), ikony v `assets/`. Spuštění z ikony otevře `/?app=1` a rovnou aplikaci.
- Není to soubor .apk ani .exe. Pokud bude potřeba skutečný .apk (např. pro rozeslání mimo web), lze ho vyrobit z PWA nástrojem Bubblewrap/PWABuilder; Google Play to nevyžaduje, ale podpis a zkouška na zařízení ano.

## Soubory ke stažení (Android .apk, Windows .exe)

- Sestavuje je GitHub Actions (`.github/workflows/apps.yml`) při změně složek `android/` nebo `desktop/` a nahrává do vydání `app-latest`. Odkazy: `https://github.com/michal219/vexaronet/releases/download/app-latest/Vexaronet.apk` a `.../Vexaronet.exe`.
- Obě aplikace jen otevírají vexaronet.com (Android WebView, Windows Electron), takže se obsah aktualizuje sám s webem.
- APK se podepisuje klíčem, který se vytváří při každém sestavení: novou verzi je třeba před instalací odinstalovat. EXE nemá podpis vydavatele, Windows ukáže varování SmartScreen (Další informace, Přesto spustit).
- iPhone a Mac: jen instalace přes Safari (Přidat na plochu / do Docku), soubor ke stažení tam není možný.

## Editor jednoduchého webu (modul Weby)
- Úpravy: barva, vzhled (světlý/tmavý/teplý), 4 písma, obrázek v záhlaví a logo, galerie až 6 obrázků, 3 reference, 5 častých otázek, odkazy na Facebook/Instagram, odkaz na mapu, tlačítka rezervace a e-shopu.
- Obrázky se vkládají jen jako odkaz začínající https:// (nahrávání souborů zatím není). Odkazy jiného typu se při zobrazení ignorují.
- Vše je v tabulce `sites` (sloupec `data`), žádná změna databáze nebyla potřeba. Veřejná adresa: `/?w=adresa`.
- Vlastní doména zatím není.
- Nahrávání obrázků: bucket `site-images` (veřejné čtení, max 3 MB, JPG/PNG/WebP/GIF), zápis jen vlastník/admin do složky své firmy (`schema_storage.sql`, už nasazeno). V ukázce se nenahrává.

## Profil firmy pro AI (větev ve vývoji, zatím nenasazeno)

Ruční profil firmy (služby, zákazníci, cíl, značka) s automatickým ukládáním, verzemi a potvrzením. Dostupný ve všech tarifech vlastníkovi a správci
(v menu Další moduly → Profil firmy a v Nastavení). Společné údaje spravuje hlavní firma, pobočka má vlastní lokalitu.
1. V Supabase SQL Editoru jednou spusťte `db/migrations/20261107120000_profil_firmy.sql` (jen přidává objekty; zpět `..._rollback.sql`).
   Před tím vyzkoušejte na testovacím projektu podle `docs/TESTOVACI_PROSTREDI.md`.
2. Žádné nové proměnné prostředí ani AI klíč nejsou potřeba. Bez migrace aplikace u profilu zobrazí upozornění, nic se nerozbije.
3. Schéma formuláře je v `src/onboarding_schema.json`. Po jeho změně spusťte `python3 tools/sync_profile_schema.py`, `python3 build.py` a `tests/db/run_local.sh`.
4. Aplikace si pamatuje aktivní firmu v prohlížeči (Nastavení → Aktivní firma, jen když účet patří do více firem).

## AI Autopilot a bezpečnostní opravy (větev ve vývoji, zatím nenasazeno)

Podrobnosti: `docs/AUTOPILOT.md`, `docs/BEZPECNOSTNI_OPRAVY.md`. Žádná část nespouští placené volání AI.
1. Migrace v tomto pořadí, každou nejdřív na testovacím projektu (`docs/TESTOVACI_PROSTREDI.md`), na produkci až po výslovném souhlasu:
   `20261107120000_profil_firmy.sql`, `20261108100000_bezpecnostni_opravy.sql`, `20261108110000_autopilot_limity.sql` (všechny mají `_rollback.sql`).
2. Cloudflare funkce `advisor`, `web-ai`, `marketing`, `accountant` nově vyžadují `cid` firmy. Nasazujte je **spolu s novým `index.html`**;
   stará stránka v prohlížeči (cache, PWA) AI nepoužije, dokud se neobnoví.
3. Platformní vypínač placených AI běhů je po migraci vypnutý a zapíná se až po ověření (`docs/AUTOPILOT.md`, oddíl 4).
4. Před sestavením: `python3 build.py`. Testy: `tests/db/run_all_local.sh`, `node tests/*.test.mjs`, `python3 tests/profile_ui.py`, `python3 tests/autopilot_ui.py`.


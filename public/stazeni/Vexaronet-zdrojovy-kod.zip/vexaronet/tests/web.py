from playwright.sync_api import sync_playwright
R='/tmp/vexaronet-saas'
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':1360,'height':1000})
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/supabase.js',lambda r:r.fulfill(body='',content_type='text/javascript'))
    pg.goto('file://'+R+'/index.html');pg.wait_for_timeout(400)
    pg.click('.cta [data-demo]');pg.wait_for_selector('#vxapp .kpi')
    pg.evaluate("document.querySelector('#vxapp [data-tab=weby]').click()");pg.wait_for_timeout(600)
    print('form',pg.locator('#webForm').count(),'frame',pg.locator('#webFr').count())
    pg.fill('#w_ai','Rodinný autoservis v Plzni, děláme servis, pneuservis a diagnostiku pro řidiče a malé firmy.')
    pg.click('[data-web=ai]');pg.wait_for_timeout(1800)
    print('ai st:',pg.inner_text('#webAiSt')[:90]);print('title:',pg.input_value('#w_ht'),'| svc1:',pg.input_value('#w_sn0'))
    pg.fill('#w_cp','602 111 222');pg.fill('#w_ce','info@servis.cz');pg.fill('#w_col','#e8590c') if False else None
    pg.wait_for_timeout(300)
    src=pg.eval_on_selector('#webFr','e=>e.srcdoc')
    print('srcdoc has title',('Servis' in src or 'servis' in src),'tel',('tel:602111222' in src),'svc',('Pneuservis' in src))
    pg.screenshot(path='/tmp/web1.png')
    pg.click('#webForm button[type=submit]');pg.wait_for_timeout(700)
    print('toast',pg.inner_text('#appToast'),'| link card',pg.locator('.bklink').count())
    pg.check('#w_on');pg.click('#webForm button[type=submit]');pg.wait_for_timeout(700);print('toast2',pg.inner_text('#appToast'))
    pg.click('[data-web=open]');pg.wait_for_selector('#vxsite iframe');pg.wait_for_timeout(300)
    fr=pg.frame_locator('#vxsite iframe');print('full page h1:',fr.locator('h1').inner_text())
    pg.screenshot(path='/tmp/web2.png')
    # xss
    pg.click('.vxsx');pg.fill('#w_ht','<img src=x onerror=alert(1)>');pg.wait_for_timeout(200)
    src=pg.eval_on_selector('#webFr','e=>e.srcdoc');print('escaped',('<img src=x' not in src))
    print(errs);b.close()

# --- rozšíření editoru: obrázky, galerie, reference, FAQ, vzhled, odkazy ---
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':1360,'height':1000})
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/supabase.js',lambda r:r.fulfill(body='',content_type='text/javascript'))
    pg.goto('file://'+R+'/index.html');pg.wait_for_timeout(400)
    pg.click('.cta [data-demo]');pg.wait_for_selector('#vxapp .kpi')
    pg.evaluate("document.querySelector('#vxapp [data-tab=weby]').click()");pg.wait_for_timeout(600)
    pg.fill('#w_ht','Test web');pg.fill('#w_hi','https://example.com/hero.jpg');pg.fill('#w_lg','https://example.com/logo.png')
    pg.fill('#w_g0','https://example.com/a.jpg');pg.fill('#w_g1','javascript:alert(1)')
    pg.fill('#w_rt0','Skvělá práce');pg.fill('#w_rw0','Jana')
    pg.fill('#w_fq0','Kolik to stojí?');pg.fill('#w_fa0','Podle rozsahu.')
    pg.select_option('#w_style','dark');pg.select_option('#w_font','round')
    pg.fill('#w_ca','Plzeň 1');pg.check('#w_map');pg.fill('#w_fb','https://facebook.com/x');pg.fill('#w_ig','http://nope.cz')
    print('shop cb disabled:',pg.is_disabled('#w_shop'))
    if not pg.is_disabled('#w_shop'):pg.check('#w_shop')
    pg.wait_for_timeout(300)
    s=pg.eval_on_selector('#webFr','e=>e.srcdoc')
    ok=lambda n,c:print(('OK  ' if c else 'FAIL'),n)
    ok('hero img','hero.jpg' in s);ok('logo','logo.png' in s);ok('galerie','a.jpg' in s);ok('js: odkaz odfiltrován','javascript:' not in s)
    ok('reference','Skvělá práce' in s);ok('faq','<details>' in s);ok('tmavý','--bg:#0f1220' in s);ok('písmo','ui-rounded' in s)
    ok('mapa','mapy.cz' in s);ok('facebook','facebook.com/x' in s);ok('http instagram odfiltrován','nope.cz' not in s)
    pg.click('#webForm button[type=submit]');pg.wait_for_timeout(600)
    pg.reload() if False else None
    print(errs);b.close()

with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':1360,'height':1000})
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/supabase.js',lambda r:r.fulfill(body='',content_type='text/javascript'))
    pg.goto('file://'+R+'/index.html');pg.wait_for_timeout(400)
    pg.click('.cta [data-demo]');pg.wait_for_selector('#vxapp .kpi')
    pg.evaluate("document.querySelector('#vxapp [data-tab=weby]').click()");pg.wait_for_timeout(600)
    print('upload inputs:',pg.locator('#webForm input[data-up]').count())
    open('/tmp/t.png','wb').write(bytes.fromhex('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6300010000000500010d0a2db40000000049454e44ae426082'))
    pg.set_input_files('#webForm input[data-up="w_hi"]','/tmp/t.png');pg.wait_for_timeout(400)
    print('demo upload toast:',pg.inner_text('#appToast')[:60],errs);b.close()

# --- tlačítka a odkazy uvnitř hotového webu (kliknutí myší, ne JS) ---
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':1360,'height':900})
    pg.route('**/supabase.js',lambda r:r.fulfill(body='',content_type='text/javascript'))
    pg.goto('file://'+R+'/index.html');pg.wait_for_timeout(400)
    pg.click('.cta [data-demo]');pg.wait_for_selector('#vxapp .kpi')
    pg.evaluate("document.querySelector('#vxapp [data-tab=weby]').click()");pg.wait_for_timeout(600)
    pg.fill('#w_ai','Rodinný autoservis v Plzni, děláme servis, pneuservis a diagnostiku pro řidiče a malé firmy.')
    pg.click('[data-web=ai]');pg.wait_for_timeout(1500);pg.fill('#w_cp','602 111 222')
    pg.click('[data-web=open]');pg.wait_for_selector('#vxsite iframe');pg.wait_for_timeout(1200)
    f=pg.query_selector('#vxsite iframe').content_frame()
    for sel,h in(('.nv a[href="#sluzby"]','#sluzby'),('.nv a[href="#kontakt"]','#kontakt')):
        f.locator(sel).first.click();pg.wait_for_timeout(1500)
        okk=f.url.endswith(h) and f.evaluate('scrollY')>200 and pg.url.startswith('file://') and 'index.html' in pg.url
        print(('OK  ' if okk else 'FAIL'),'odkaz uvnitř webu scrolluje, nenačte aplikaci',sel,f.url)
    b.close()

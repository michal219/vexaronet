#!/usr/bin/env python3
import json, html, re, os
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(ROOT_DIR)  # relativní cesty (src/…) se berou od adresáře skriptu
D = os.environ.get('VX_BUILD_DIR', ROOT_DIR).rstrip('/') + '/'
import json as _json
try: CFG = _json.load(open(ROOT_DIR + '/config.local.json', encoding='utf-8'))
except Exception: CFG = {}
SRC_OFF = ['aitym','ceo','ucetni','autopilot','marketing','weby','automatizace','online','sklad','eshop','pobocky']  # moduly, které edice zdrojového kódu nenabízí
VERSION = open(ROOT_DIR + '/VERSION', encoding='utf-8').read().strip() if os.path.exists(ROOT_DIR + '/VERSION') else '0.0.0'
css = open(D + 'base.css', encoding='utf-8').read()
esc = lambda s: html.escape(s, quote=True)

IC = {
 'ai': '<rect x="5" y="5" width="14" height="14" rx="3.5"/><path d="M9.5 10h.01M14.5 10h.01"/><path d="M9.5 14.5c1.4 1 3.6 1 5 0"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>',
 'fin': '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M3 10h18M7 15h3"/>',
 'shop': '<path d="M3 4h2.2l2 11h11.3l2-8H6"/><circle cx="9.5" cy="19.5" r="1.4"/><circle cx="17" cy="19.5" r="1.4"/>',
 'biz': '<circle cx="9" cy="8" r="3.2"/><path d="M3.5 19c.6-3.3 2.8-5 5.5-5s4.9 1.7 5.5 5"/><path d="M16 6.5a3 3 0 010 5.6M18 14.2c1.6.7 2.6 2.2 3 4.3"/>',
 'web': '<rect x="3" y="4" width="18" height="15" rx="2.5"/><path d="M3 9h18"/><path d="M8 14.5l2.2 2.2L15 12"/>',
 'mkt': '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',
 'auto': '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
}
# Jediný zdroj pravdy o stavu funkcí: now = k dispozici, lim = k dispozici s omezením, soon = připravujeme.
# Položky končící na " (připravujeme)" se v detailu modulu řadí mezi plány. Stav modulu, štítky na kartách i roadmapa se berou odsud.
ST = {'now': 'k dispozici', 'lim': 'k dispozici s omezením', 'soon': 'připravujeme'}
MODS = [
 dict(id='ai', stage=5, state='lim', note='AI CEO, AI poradce a AI Účetní fungují po přihlášení, podle tarifu a přes externí AI službu. Odpovědi jsou návrhy, nic se nezmění bez vašeho potvrzení. Další asistenti a Autopilot ještě nejsou.',
      name='AI centrum', short='AI CEO ukazuje, co ve firmě sledovat, a navrhuje další kroky. AI Účetní pomáhá s doklady. Vy vždy schvalujete.',
      items=['AI CEO: doporučení, zdraví firmy a chat nad vašimi daty (tarif PRO a vyšší)','AI Účetní: odpovědi z vaší evidence a návrh vytěžení dokladu ke kontrole (potřebuje zapnutou AI službu)','AI návrh textů pro web a marketing (PRO a vyšší)','AI obchodník (připravujeme)','AI krizový manažer (připravujeme)','AI Autopilot, který propojuje moduly (připravujeme)','AI zákaznická podpora 24/7 (připravujeme)']),
 dict(id='fin', stage=4, state='lim', note='Faktury, příjmy a výdaje, import bankovních výpisů a reporty fungují. PDF, QR platby, odesílání e-mailem, DPH a účetnictví ještě nejsou. Faktury před ostrým použitím zkontrolujte s účetním.',
      name='Finance a fakturace', short='Faktury, příjmy a výdaje, párování plateb a reporty. Účetnictví a DPH připravujeme.',
      items=['Vystavování faktur s číslováním a DPH','Evidence příjmů a výdajů','Import bankovních výpisů (CSV) a párování plateb','Reporty s exportem do CSV a tiskem','PDF faktury a QR platby (připravujeme)','Odesílání faktur e-mailem (připravujeme)','DPH a daňové podklady (připravujeme)','Účetní deník a hlavní kniha (připravujeme)','Přímé napojení banky (připravujeme)']),
 dict(id='biz', stage=3, state='now', note='Základ je hotový a funguje se skutečnými daty.',
      name='Řízení firmy', short='Zákazníci, zakázky, úkoly, kalendář, online rezervace, sklad a zaměstnanci s docházkou.',
      items=['CRM a databáze zákazníků, import z CSV','Zakázky a úkoly se stavy podle oboru','Kalendář a online rezervace pro zákazníky','Zaměstnanci, role, docházka a hodinová sazba s výdělkem za měsíc','Skladové hospodářství','Pobočky a místa u zakázek, rezervací a směn','Firemní komunikace a e-mail (připravujeme)','Obchodní příležitosti a historie komunikace (připravujeme)']),
 dict(id='shop', stage=3, state='lim', note='Funguje v tarifu PRO a vyšších. Platba je jen převodem podle faktury, bez platební brány. Fakturu zákazníkovi zatím posíláte sami.',
      name='E-shop propojený se skladem a fakturami', short='Zákazník nakoupí na veřejné stránce obchodu, vám se sama vystaví faktura a ze skladu se odepíše zboží.',
      items=['Veřejný obchod s vlastním odkazem, bez registrace zákazníka','Objednávka vytvoří zákazníka, zakázku a fakturu','Zboží se hned odepíše ze skladu, nelze prodat víc, než je skladem','Faktura s údaji k platbě převodem a správným číslováním','Zrušení objednávky vrátí zboží na sklad','Platba kartou a online platební brána (připravujeme)','Odesílání faktur zákazníkovi e-mailem (připravujeme)']),
 dict(id='web', stage=6, state='lim', note='Editor, AI návrh textů (PRO a vyšší), obrázky a veřejný odkaz fungují. Každá firma má zatím jeden web a vlastní doména není k dispozici.',
      name='Jednoduché weby', short='Jednostránkový firemní web s editorem, galerií a AI návrhem textů na veřejném odkazu vexaronet.com.',
      items=['Editor jednostránkového webu: texty, služby, galerie, reference, časté otázky a kontakt','AI návrh textů podle vašeho popisu, vy ho upravíte a schválíte','Úprava barvy, vzhledu (světlý, tmavý, teplý), písma a obrázků včetně nahrání','Odkazy na rezervace, e-shop, sociální sítě a mapu','Veřejný odkaz a zobrazení na mobilu','Import objednávek z jiného e-shopu z CSV (faktura se vystaví po vašem potvrzení)','Automatické napojení na Shoptet, WooCommerce a další e-shopy (připravujeme)','Vlastní doména (připravujeme)','Více webů na jednu firmu (připravujeme)']),
 dict(id='mkt', stage=7, state='lim', note='Funguje AI návrh příspěvků, newsletterů a reklam (PRO a vyšší) a plán obsahu. Nic se samo nepublikuje ani neodesílá. Zbytek modulu ještě není.',
      name='Marketing', short='AI navrhne text příspěvku, newsletteru nebo reklamy a pomůže naplánovat obsah. Publikujete sami.',
      items=['AI návrhy příspěvků, e-mailů, reklam a odpovědí na recenze','Plán obsahu a evidence příspěvků','Slevové kódy (připravujeme)','Veřejné firemní profily (připravujeme)','Hodnocení a recenze zákazníků (připravujeme)','Statistiky návštěvnosti (připravujeme)']),
 dict(id='auto', stage=5, state='lim', note='Pravidla se vyhodnotí, když otevřete Vexaronet, a navrhnou úkoly, které vy potvrdíte. Běh na pozadí a automatické zprávy zákazníkům ještě nejsou.',
      name='Automatizace', short='Hlídání splatných faktur, termínů, hotových zakázek, neaktivních zákazníků a skladu. Navrhne úkoly, vy je schválíte.',
      items=['Pravidla pro splatné faktury, termíny zakázek, hotové zakázky bez faktury, neaktivní zákazníky, rezervace na zítra a nízký sklad','Návrhy úkolů, které vytvoříte tlačítkem','Ranní přehled dne do e-mailu (potřebuje zapnutou e-mailovou službu)','Běh pravidel bez otevření aplikace (připravujeme)','Automatické e-maily a upomínky zákazníkům (připravujeme)','Vlastní pravidla a propojení s dalšími službami (připravujeme)']),
]
STAGES = [
 ('Úvodní stránka a designový systém', 'Hotová úvodní stránka s ukázkou aplikace.', 'done'),
 ('Registrace, přihlášení a databáze', 'Registrace, přihlášení, obnova hesla a firemní účty fungují.', 'done'),
 ('Dashboard, CRM, zakázky a kalendář', 'Dashboard, zákazníci, zakázky, kalendář, úkoly, online rezervace, sklad a zaměstnanci s docházkou a hodinami fungují.', 'done'),
 ('Finance a fakturace', 'Vystavování faktur, příjmy a výdaje, import bankovních výpisů a reporty fungují. PDF, QR platby, odesílání faktur, DPH a účetnictví připravujeme. Vyžaduje odbornou kontrolu účetním.', 'next'),
 ('AI centrum a automatizace', 'AI CEO, AI poradce a AI Účetní fungují s omezeními, pravidla automatizace navrhují úkoly. AI Autopilot a další asistenti připravujeme. AI funkce vyžadují externí AI službu.', 'next'),
 ('E-shop a jednoduché weby', 'E-shop se skladem a fakturou i editor jednoduchého webu fungují. Platební brána, odesílání faktur a vlastní doména připravujeme.', 'next'),
 ('Marketing, analytika a další moduly', 'AI návrhy příspěvků a plán obsahu fungují. Slevové kódy, veřejné profily, recenze a statistiky připravujeme.', 'next'),
 ('Předplatné, zabezpečení a testování', 'Platební brána v aplikaci a nezávislý bezpečnostní audit ještě nejsou. Vexaronet se prodává jako zdrojový kód, předplatné se nenabízí.', 'plan'),
]
BIZ = {
 'Služby': ['Klienti a projekty','Schůzky a online objednání','Faktury a hlídání plateb','E-shop pro prodej zboží k službám','Evidence hodin týmu'],
 'Autoservis': ['Servisní zakázky a vozidla','Online objednání na servis','Sklad dílů','E-shop s díly a doplňky (faktura a sklad sami)','Faktury za práci a díly','Mechanici a docházka'],
 'Řemeslník': ['Zakázky se stavy a zálohami','Kalendář výjezdů','Materiál na skladě','E-shop s materiálem a výrobky','Pracovníci a hodiny','Faktury'],
 'Restaurace': ['Rezervace stolů online','Sklad surovin','Personál, směny a docházka','Akce a catering','Příjmy a výdaje'],
 'Kadeřnictví a krása': ['Online rezervace klientů','Klienti s poznámkami','Tým a směny','Prodej produktů ze skladu','E-shop s kosmetikou','Slevy a marketing'],
 'Obchod': ['Zboží a sklad pod minimem','E-shop s fakturou a odpisem ze skladu','Objednávky','Zákazníci a faktury','Slevové kódy a marketing','Více prodejen'],
 'Jiný obor': ['CRM','Kalendář','Faktury','Úkoly','E-shop se skladem'],
}
PLANS = [
 # key, název, měsíčně, ročně za měsíc, ročně za rok, podtitul, hot, tlačítko, odrážky
 ('start','VEXARONET START',0,0,0,'Pro začínající OSVČ a malé podnikatele.',False,'Založit účet zdarma',
  ['CRM do 50 zákazníků','Až 10 faktur měsíčně','Až 10 zakázek v evidenci najednou','Kalendář, úkoly a online rezervace','Jednoduchý finanční přehled','1 uživatel','Bez AI CEO a AI Účetní']),
 ('accountant','VEXARONET AI ÚČETNÍ',399,339,4068,'Evidence a AI Účetní pro OSVČ a s.r.o. Účetnictví a DPH připravujeme.',False,'Vyzkoušet 30 dní zdarma',
  ['Neomezené vystavování faktur','Evidence příjmů a výdajů','AI Účetní: vytěžení dokladů a dotazy k evidenci (100 dokladů měsíčně, s omezením)','Import bankovních výpisů (CSV)','Účetnictví a DPH (připravujeme)','1 uživatel','Přístup externího účetního (připravujeme)','Bez CRM a AI CEO']),
 ('pro','VEXARONET PRO',699,594,7128,'Řízení malé firmy: zákazníci, zakázky, sklad, e-shop a AI CEO.',True,'Vyzkoušet 30 dní zdarma',
  ['Vše z AI Účetní','Neomezené CRM, zakázky a kalendář','AI CEO: doporučení a chat nad daty (s omezením)','E-shop se skladem a fakturami (platba převodem)','1 jednoduchý web','3 uživatelé, 1 firma','150 AI dokladů měsíčně','500 AI akcí měsíčně (připravujeme)']),
 ('business','VEXARONET BUSINESS',1199,1019,12228,'Pro rostoucí firmy s týmem.',False,'Vyzkoušet 30 dní zdarma',
  ['Vše z PRO','Až 10 uživatelů','500 AI dokladů měsíčně','2 000 AI akcí měsíčně (připravujeme)','Pokročilý AI CEO a predikce (připravujeme)','Role a schvalovací procesy (připravujeme)','Prioritní podpora (připravujeme)']),
 ('enterprise','VEXARONET ENTERPRISE',None,None,None,'Pro větší společnosti a náročné provozy.',False,'Požádat o nabídku',
  ['Individuální počet uživatelů a limity','Více společností a poboček (připravujeme)','Vlastní integrace a automatizace podle dohody','Individuální onboarding','Podpora a SLA podle dohody','Cena podle nabídky']),
]
# řádky porovnání: popisek, [start, účetní, pro, business, enterprise], stav ('now' = už funguje, 'soon' = připravujeme)
Y='✓'; N='—'
CMP = [
 ('Základ', None, None),
 ('Uživatelé (kontrola limitu při pozvání v aplikaci)', ['1','1','3','10','individuálně'], 'lim'),
 ('Více firem na jeden účet', ['1','1','1','1','více firem a poboček'], 'soon'),
 ('CRM, zakázky a kalendář', None, None),
 ('Zákazníci', ['max. 50',N,'neomezeně','neomezeně','neomezeně'], 'now'),
 ('Zakázky v evidenci najednou', ['max. 10',N,'neomezeně','neomezeně','neomezeně'], 'now'),
 ('Úkoly a termíny', [Y,N,Y,Y,Y], 'now'),
 ('Kalendář a plánování', [Y,N,Y,Y,Y], 'now'),
 ('Ranní přehled dne do e-mailu (potřebuje zapnutou e-mailovou službu)', [Y,N,Y,Y,Y], 'lim'),
 ('Pobočky a místa u zakázek, rezervací a směn', [N,N,Y,Y,Y], 'now'),
 ('Online rezervace s veřejnou stránkou pro zákazníky', [Y,N,Y,Y,Y], 'now'),
 ('Obchodní příležitosti, historie komunikace, segmentace', [N,N,Y,Y,Y], 'soon'),
 ('Sklad, e-shop a týmy', None, None),
 ('Sklad a produkty', [N,N,Y,Y,Y], 'now'),
 ('Zaměstnanci, docházka a hodinová sazba', [N,N,Y,Y,Y], 'now'),
 ('E-shop: objednávka vytvoří fakturu a odepíše sklad (platba převodem)', [N,N,Y,Y,Y], 'lim'),
 ('Import objednávek z jiného e-shopu (CSV) do faktur', [N,N,Y,Y,Y], 'now'),
 ('Automatické napojení cizího e-shopu (Shoptet, WooCommerce)', [N,N,N,N,N], 'soon'),
 ('Platba kartou v e-shopu', [N,N,Y,Y,Y], 'soon'),
 ('Finance a účetnictví', None, None),
 ('Vystavování faktur', ['10 měsíčně','neomezeně','neomezeně','neomezeně','neomezeně'], 'now'),
 ('Evidence příjmů a výdajů, jednoduchý přehled', [Y,Y,Y,Y,Y], 'now'),
 ('Import bankovních výpisů (CSV) a párování plateb', [N,Y,Y,Y,Y], 'now'),
 ('AI vytěžení přijatých dokladů (výsledek je návrh ke kontrole)', [N,'100 / měsíc','150 / měsíc','500 / měsíc','individuálně'], 'lim'),
 ('PDF faktury, QR platby a odesílání faktur e-mailem', [N,Y,Y,Y,Y], 'soon'),
 ('Daňová evidence, podvojné účetnictví, deník, hlavní kniha, výkazy', [N,Y,Y,Y,Y], 'soon'),
 ('DPH a daňové podklady', [N,Y,Y,Y,Y], 'soon'),
 ('Majetek, odpisy a mzdová agenda', [N,Y,Y,Y,Y], 'soon'),
 ('Přístup externího účetního, auditní záznamy, archivace', [N,Y,Y,Y,Y], 'soon'),
 ('AI', None, None),
 ('AI CEO: doporučení a chat nad firemními daty', [N,N,Y,Y,Y], 'lim'),
 ('AI Účetní: dotazy k vaší evidenci (ne daňové rady)', [N,Y,Y,Y,Y], 'lim'),
 ('AI akce měsíčně (zatím se nepočítají)', [N,N,'500','2 000','individuálně'], 'soon'),
 ('AI Autopilot (akce vždy po schválení)', [N,N,Y,Y,Y], 'soon'),
 ('Weby, marketing a automatizace', None, None),
 ('Jednoduchý web: editor a AI návrh textů (vlastní doména připravujeme)', [N,N,'1 web','1 web','1 web'], 'lim'),
 ('Více webů na firmu', [N,N,N,'více webů','individuálně'], 'soon'),
 ('Marketing: AI návrhy příspěvků a plán obsahu', [N,N,Y,Y,Y], 'lim'),
 ('Automatizace: pravidla navrhující úkoly (po otevření aplikace)', [Y,N,Y,Y,Y], 'lim'),
 ('Ostatní', None, None),
 ('Reporty s exportem do CSV a tiskem', [Y,Y,Y,Y,Y], 'now'),
 ('Role, oprávnění a schvalovací procesy', [N,N,N,Y,Y], 'soon'),
 ('API integrace', [N,N,N,Y,Y], 'soon'),
 ('Veřejný firemní profil', [Y,Y,Y,Y,Y], 'soon'),
 ('Podpora e-mailem (info@vexaronet.com)', [Y,Y,Y,Y,Y], 'now'),
 ('Prioritní podpora a SLA', [N,N,N,'prioritní','dohodnutá (SLA)'], 'soon'),
]

def svg(k): return f'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">{IC[k]}</svg>'

mods_html = '\n'.join(f'''<article class="svc" data-r="up" style="--d:{i*0.06:.2f}s" data-glow>
  <div class="svc-ic">{svg(m['id'])}</div><h3>{esc(m['name'])}</h3><p>{esc(m['short'])}</p>
  <div class="svc-foot"><span class="from"><b class="stb stb-{m['state']}">{ST[m['state']]}</b> · etapa {m['stage']}</span><a class="more" href="#modul-{m['id']}" data-mod="{m['id']}" aria-label="Zjistit více: {esc(m['name'])}">Zjistit více <i aria-hidden="true"></i></a></div>
</article>''' for i, m in enumerate(MODS))

def kc(n): return f'{n:,}'.replace(',', ' ')
def plan_card(k,n,m,ym,yy,d,hot,btn,bul):
    if m is None: price='<b class="pp">Individuální cena</b>'; sub='<span class="pn">Cena na základě nabídky</span>'
    elif m==0: price='<b class="pp">0 Kč</b>'; sub='<span class="pn">zdarma, bez časového omezení</span>'
    else:
        price=f'<b class="pp" data-m="{kc(m)}" data-y="{kc(ym)}">{kc(m)} Kč</b>'
        sub=f'<span class="pn" data-m="měsíčně, bez DPH" data-y="měsíčně při roční platbě ({kc(yy)} Kč/rok), bez DPH">měsíčně, bez DPH</span>'
    cta=(f'<a class="btn btn-ghost" href="mailto:info@vexaronet.com?subject=Vexaronet%20ENTERPRISE">{btn}</a>' if k=='enterprise'
         else f'<button class="btn {"btn-main" if hot else "btn-ghost"}" type="button" data-early="{k}">{btn}</button>')
    return f'''<article class="plan{' hot' if hot else ''}" data-glow>{'<span class="ribbon">Nejvýhodnější</span>' if hot else ''}
  <h3>{n.replace('VEXARONET ','')}</h3><p class="note">{esc(d)}</p><div class="price">{price} <span class="per">Kč / měsíc</span></div>{sub}
  <ul class="ticks">{''.join(('<li class="soonli"><s>'+esc(b[:-len(' (připravujeme)')])+'</s> <em class="soonb">ve vývoji</em></li>') if b.endswith(' (připravujeme)') else '<li>'+esc(b)+'</li>' for b in bul)}</ul>{cta}</article>'''.replace(' <span class="per">Kč / měsíc</span>','')
cards='\n'.join(plan_card(*x) for x in PLANS)
def cell(v): return f'<td>{v}</td>'
rows=''
for lab,vals,st in CMP:
    if vals is None: rows+=f'<tr class="grp"><th colspan="6">{esc(lab)}</th></tr>'; continue
    badge={'now':'','lim':' <em class="soonb limb">s omezením</em>','soon':' <em class="soonb">připravujeme</em>'}[st]
    lab_h = f'<s>{esc(lab)}</s>' if st=='soon' else esc(lab)
    rows+=f'<tr><th scope="row">{lab_h}{badge}</th>'+''.join(cell(esc(v)) for v in vals)+'</tr>'
plans_html='''<div class="variants" data-r="up">
 <div class="vcard">
  <span class="eyebrow">Zdarma</span><h3>Aplikace pro váš počítač a zdrojový kód</h3>
  <div class="vprice"><b>0 €</b><span>zdarma ke stažení</span></div>
  <p class="note">Dostanete zdrojový kód a hotovou lokální aplikaci: soubor, který otevřete v prohlížeči a běží u vás v počítači. Data zůstávají u vás. Žádné předplatné.</p>
  <ul class="ticks">
   <li>Jádro aplikace: zákazníci a CRM, obchodní případy, nabídky, zakázky, úkoly, kalendář a rezervace, faktury, finance, zaměstnanci a docházka, reporty</li>
   <li>Složitější moduly (e-shop, sklad, pobočky, weby, AI) jsou v této edici ve výchozím nastavení vypnuté a nejsou součástí podpory</li>
   <li>CRM pro firmy z celé EU: 27 států, IČ DPH a IBAN se kontrolují podle tvaru</li>
   <li>Hotová lokální aplikace: bez serveru, bez účtu a bez internetu, záloha a obnova do souboru</li>
   <li>Automatické testy, architektura a návod, jak aplikaci znovu sestavit a upravit</li>
  </ul>
  <form id="dlForm" class="dlf" novalidate>
   <p class="hp" aria-hidden="true"><label>Nevyplňovat <input name="bot-field" tabindex="-1" autocomplete="off"></label></p>
   <div class="f"><label for="dlMail">Váš e-mail <i aria-hidden="true">*</i></label><input id="dlMail" name="email" type="email" required aria-required="true" autocomplete="email" inputmode="email"></div>
   <label class="chk"><input type="checkbox" name="lic"><span>Souhlasím s <a href="/licence/" target="_blank" rel="noopener">licenčními podmínkami</a>: software nesmím přeprodávat ani dál šířit. <i aria-hidden="true">*</i></span></label>
   <label class="chk"><input type="checkbox" name="souhlas"><span>Souhlasím, že mi Vexaronet bude na uvedený e-mail posílat novinky o vývoji. Souhlas mohu kdykoli odvolat. <a href="/ochrana-udaju/" target="_blank" rel="noopener">Zásady ochrany osobních údajů</a> <i aria-hidden="true">*</i></span></label>
   <label class="chk"><input type="checkbox" name="vek"><span>Je mi alespoň 15 let. <i aria-hidden="true">*</i></span></label>
   <button class="btn btn-main" type="submit" id="dlGo">⬇ Zadat e-mail a stáhnout zdarma</button>
   <div class="st" id="dlSt" role="status" aria-live="polite"></div>
  </form>
  <div id="dlOk" hidden></div>
  <p class="mut fine" id="dlNote">Po zadání e-mailu se hned zobrazí odkazy ke stažení: aplikace pro počítač (otevřete Vexaronet.html) a zdrojový kód, který aplikaci obsahuje. Běží u vás v počítači, na žádný web ji dávat nemusíte.</p>
 </div>
 <div class="vcard vc2">
  <span class="eyebrow">Předplatné</span><h3>Vexaronet online</h3>
  <div class="vprice"><b>cena zatím neurčena</b><span>oznámíme před startem</span></div>
  <p class="note">Aplikaci používáte v prohlížeči a nemusíte nic nasazovat ani spravovat. Cenu a podmínky předplatného zatím nemáme stanovené, žádná čísla proto nevymýšlíme.</p>
  <ul class="ticks">
   <li>Aplikace v prohlížeči, bez vlastní databáze a hostingu</li>
   <li>Zatím nic neúčtujeme a nic se automaticky nestrhává</li>
   <li>Ozveme se, jakmile bude cena a podmínky jasné</li>
  </ul>
  <button type="button" class="btn btn-ghost" data-namiru="online">Chci být u startu online verze</button>
 </div>
</div>
<p class="mut fine" style="text-align:center;margin:14px 0 6px"><button type="button" class="btn btn-ghost btn-demo" data-demo="1">▶ Nejdřív si vyzkoušet ukázku</button></p>
<div class="pnotes">
 <div><h4>Co stahujete</h4><p>Aplikace a zdrojový kód, ne služba. Data jsou jen na vašem počítači a zálohy si děláte sami. Faktury v lokální verzi jsou zjednodušené (bez výpočtu DPH) a musí je zkontrolovat účetní. Právní soulad (smlouvy, ochrana údajů, daňové a účetní náležitosti) je na vaší straně.</p></div>
 <div><h4>V jakém je to stavu</h4><p>Vexaronet je beta verze. Co funguje, je napsané jako funguje, části označené „připravujeme“ hotové nejsou. Přesně to vidíte v ukázce a ve stavu vývoje níže. Platební brána v aplikaci není, faktury se vystavují a platí převodem. Fakturace je zatím jen pro dodavatele z ČR a Slovenska.</p></div>
 <div><h4>Licence a podpora</h4><p>Stažení je zdarma a nic neplatíte. Software smíte používat ve své firmě a upravovat pro vlastní potřebu. Nesmíte ho prodávat, pronajímat ani dál šířit, viz <a href="/licence/" target="_blank" rel="noopener">licenční podmínky</a>. Podporu nezaručujeme, chybu nahlaste na info@vexaronet.com.</p></div>
</div>'''

stages_html = '\n'.join(f'''<div class="step" data-r="up">
  <div class="dot" aria-hidden="true">{i}</div>
  <div class="step-b st-{s}"><h3>{esc(t)} <span class="tagst">{ {'done':'Hotovo','next':'Rozpracováno','plan':'Plánováno'}[s] }</span></h3><p>{esc(d)}</p></div>
</div>''' for i, (t, d, s) in enumerate(STAGES, 1))

biz_chips = ''.join(f'<button type="button" class="chipb" data-biz="{esc(k)}" aria-pressed="{"true" if i==0 else "false"}">{esc(k)}</button>' for i, k in enumerate(BIZ))
biz_opts = '\n'.join(f'<option>{esc(k)}</option>' for k in BIZ)
keys = ''.join('<div class="kr">' + ''.join(f'<i style="flex:{w}"></i>' for w in r) + '</div>' for r in [[1]*14,[1]*13+[1.6],[1.6]+[1]*12+[1.4],[2.1]+[1]*10+[2.1],[1.2]*3+[6.2]+[1.2]*3])

extra_css = r'''

/* --- lokální verze --- */
html.vxlocal body>*:not(#vxapp):not(script):not(style){display:none!important}html.vxlocal .webb,html.vxlocal [data-app=logout]{display:none!important}
.lbox{display:flex;flex-direction:column;gap:6px;padding:12px;border:1px solid rgba(150,175,255,.25);border-radius:14px;margin:6px 0}.lbox small{color:var(--mut);font-size:.78rem;line-height:1.35}
/* --- web podle reklamy --- */
.vpick{display:flex;gap:14px;flex-wrap:wrap;margin:0 0 20px}.vpick .vp{flex:1 1 210px;max-width:270px;padding:16px 18px;border-radius:18px;border:1px solid rgba(150,175,255,.3);background:rgba(150,175,255,.08);display:flex;flex-direction:column;gap:3px}.vpick .vp2{border-color:rgba(139,92,246,.6)}.vpick i{font-style:normal;font-size:1.5rem;opacity:.9}.vpick b{font-size:1.05rem}.vpick span{color:var(--mut);font-size:.95rem}
.hero .why{max-width:540px;margin:0 0 22px;color:#b3bbd8;font-size:1rem;line-height:1.55}
.variants{display:grid;grid-template-columns:1fr 1fr;gap:24px;align-items:stretch;margin:8px 0 22px}@media(max-width:820px){.variants{grid-template-columns:1fr}}
.vcard{display:flex;flex-direction:column;gap:12px;border:1px solid var(--line,rgba(150,175,255,.25));border-radius:22px;padding:28px;background:rgba(255,255,255,.03)}.vcard.vc2{border-color:rgba(139,92,246,.6)}.vcard h3{font-size:1.5rem;margin:0}.vcard .ticks{flex:1}.vcard .btn{align-self:flex-start}
.dlf{display:flex;flex-direction:column;gap:10px}.dlf .f{display:flex;flex-direction:column;gap:4px}.dlf .chk{display:flex;gap:10px;align-items:flex-start;font-size:.9rem}.dlf .chk input{margin-top:3px}
.vprice{display:flex;flex-direction:column;gap:2px}.vprice b{font-size:2.6rem;line-height:1.1}.vc2 .vprice b{font-size:1.5rem;padding:.6rem 0 .5rem}.vprice span{color:var(--mut)}

/* --- ceník --- */
.plans5 .plan{position:relative}.plans5 .ribbon{position:absolute;top:-12px;left:50%;transform:translateX(-50%);background:var(--grad);color:#fff;font-size:.72rem;font-weight:700;padding:3px 12px;border-radius:99px;white-space:nowrap}.plans5 .price{min-height:2.2em;display:flex;align-items:flex-end}.plans5 .price b.pp:not([data-m]){font-size:1.2rem;white-space:normal}.plans5 .plan.hot{border-color:rgba(130,160,255,.7)}
.bill{display:flex;gap:10px;justify-content:center;margin:0 0 24px;flex-wrap:wrap}.bill small{opacity:.8;font-weight:500}
.plans5{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:14px;align-items:stretch}
@media(max-width:1180px){.plans5{grid-template-columns:repeat(3,minmax(0,1fr))}}@media(max-width:820px){.plans5{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:560px){.plans5{grid-template-columns:1fr}}
.plans5 .plan{padding:22px}.plans5 .plan h3{font-size:1.1rem}.plans5 .price b{font-size:1.6rem;white-space:nowrap}.plans5 .pn{font-size:.8rem;color:var(--mut);min-height:2.4em}.plans5 .note{font-size:.88rem;color:var(--mut);min-height:3.2em}
.plans5 .ticks li{font-size:.88rem}.plans5 .btn{width:100%;justify-content:center;text-align:center}
.cmpt{text-align:center;margin:44px 0 14px}.cmpw{overflow-x:auto;border:1px solid var(--line);border-radius:var(--r);background:var(--glass)}
.cmp{width:100%;border-collapse:collapse;min-width:760px;font-size:.9rem}.cmp th,.cmp td{padding:10px 12px;border-bottom:1px solid var(--line);text-align:center}
.cmp thead th{position:sticky;top:0;background:var(--ink);z-index:1}.cmp th[scope=row],.cmp thead th:first-child{text-align:left;font-weight:500}
.cmp .grp th{text-align:left;background:rgba(110,140,255,.12);font-weight:700;letter-spacing:.04em;text-transform:uppercase;font-size:.78rem}.cmp .hotc{color:#8fb2ff}
.custom{display:grid;grid-template-columns:1.5fr 1fr;gap:32px;align-items:center;padding:40px;border-radius:28px;border:1px solid rgba(140,165,255,.3);background:linear-gradient(150deg,rgba(40,52,130,.5),rgba(12,16,40,.7));box-shadow:0 30px 80px -24px rgba(70,90,240,.45)}
.custom h2{margin:14px 0 12px}.custom .ticks{margin-top:16px}.cu-p{padding:28px;border-radius:22px;background:rgba(8,10,30,.55);border:1px solid var(--line);display:flex;flex-direction:column;gap:12px}
.cu-p small{font-size:.78rem;letter-spacing:.16em;text-transform:uppercase;color:#a9c1ff;font-weight:700}.cu-price{display:flex;align-items:baseline;gap:10px}.cu-price span{color:var(--mut);font-size:1.1rem}.cu-price b{font-size:2.3rem;white-space:nowrap}
.cu-p .btn{width:100%;justify-content:center}.custom>*{min-width:0}.cu-p .btn{white-space:normal;text-align:center}@media(max-width:860px){.custom{grid-template-columns:minmax(0,1fr);padding:26px}}
.soonb{font-style:normal;font-size:.68rem;border:1px solid var(--line);border-radius:99px;padding:1px 7px;color:var(--mut);white-space:nowrap}
.pnotes{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;margin-top:26px}.pnotes>div{padding:18px;border-radius:16px;border:1px solid var(--line);background:var(--glass)}.pnotes h4{margin:0 0 6px}.pnotes p{margin:0;color:var(--mut);font-size:.9rem}
/* --- aplikace --- */
body:has(#vxapp) #chatFab,body:has(#vxapp) #chat{display:none!important}
.vxapp{--ink:#080d2b;--glass:rgba(22,30,82,.55);--line:rgba(130,150,255,.2);position:fixed;inset:0;z-index:1000;background:radial-gradient(900px 500px at 85% -10%,rgba(120,80,255,.22),transparent),radial-gradient(700px 500px at 0% 100%,rgba(60,110,255,.14),transparent),var(--ink);color:var(--text);display:flex;font-family:var(--fb)}
[data-theme=light] .vxapp{--ink:#eef1ff;--glass:rgba(255,255,255,.85);--line:rgba(60,80,200,.18)}
.vxapp button,.vxapp input,.vxapp select,.vxapp textarea{font:inherit}
.vxapp .pri{background:linear-gradient(135deg,#7a5cff,#6b4bf2);color:#fff;border:0;border-radius:12px;padding:10px 16px;cursor:pointer;display:inline-flex;gap:8px;align-items:center;font-weight:600;min-height:40px;box-shadow:0 8px 22px rgba(110,76,255,.35);transition:.2s}
.vxapp .pri:hover{transform:translateY(-1px);filter:brightness(1.1)}.vxapp .pri.sm{padding:8px 14px;white-space:nowrap}
.vxapp>aside{width:244px;flex:none;border-right:1px solid var(--line);display:flex;flex-direction:column;padding:16px 12px;overflow:auto;background:var(--glass);backdrop-filter:blur(14px)}
.vlogo{display:flex;gap:10px;align-items:center;padding:4px 10px 18px}.vlogo b{display:block;font-size:1.2rem;font-weight:800;letter-spacing:.04em;line-height:1.1}.vlogo small{color:var(--mut);font-size:.95rem}
.vxapp aside nav{display:flex;flex-direction:column;gap:3px;flex:1}
.vxapp aside nav button,.vxapp .sfoot>button{display:flex;align-items:center;gap:12px;background:none;border:0;color:var(--mut);padding:7px 12px;border-radius:12px;cursor:pointer;text-align:left;min-height:38px;transition:.2s;width:100%;font-size:.93rem}
.vxapp aside button:hover{background:rgba(110,140,255,.12);color:var(--text)}
.vxapp aside button[aria-pressed=true]{background:linear-gradient(135deg,#5b45e0,#4a3bc4);color:#fff;font-weight:700;box-shadow:0 6px 18px rgba(90,70,220,.35)}
.vxapp aside details.more{margin-top:6px;border-top:1px solid var(--line);padding-top:6px}.vxapp aside details.more summary{display:flex;align-items:center;gap:12px;padding:7px 12px;cursor:pointer;color:var(--mut);font-size:.9rem;list-style:none;border-radius:12px;min-height:38px}.vxapp aside details.more summary::-webkit-details-marker{display:none}.vxapp aside details.more summary:hover{background:rgba(110,140,255,.12);color:var(--text)}.vxapp aside details.more[open] summary{color:var(--text)}.vxapp .steps .stl{list-style:none;margin:8px 0 0;padding:0;display:grid;gap:6px}.vxapp .steps .stl button{display:flex;align-items:center;gap:12px;width:100%;text-align:left;background:none;border:1px solid var(--line);border-radius:12px;padding:10px 12px;color:var(--text);cursor:pointer;font:inherit}.vxapp .steps .stl button:hover{border-color:#7c8cff}.vxapp .steps .stl i{flex:none;width:22px;height:22px;border-radius:50%;border:2px solid var(--line);display:grid;place-items:center;font-style:normal;font-size:.8rem;color:#fff}.vxapp .steps .stl li.ok i{background:#1d9a68;border-color:#1d9a68}.vxapp .steps .stl li.ok span{color:var(--mut);text-decoration:line-through}.vxapp .chipsr{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}.vxapp .demoob{margin-left:auto;display:flex;align-items:center;gap:8px;font-size:.85rem}.vxapp .demoob select{padding:6px 8px;border-radius:10px;border:1px solid var(--line);background:var(--bg2,#10152e);color:var(--text)}
.vxapp aside .soon{opacity:.7}.vxapp aside em{margin-left:auto;font-size:.65rem;font-style:normal;border:1px solid var(--line);border-radius:99px;padding:1px 7px}
.subc{margin-top:12px;padding:14px;border-radius:14px;border:1px solid var(--line);background:rgba(110,76,255,.1);display:grid;gap:2px}.subc small{color:var(--mut)}.subc b{color:#ffcf6e}
.subc button{margin-top:8px;background:none;border:1px solid var(--line);color:inherit;border-radius:10px;padding:8px;cursor:pointer}
.vxmain{flex:1;display:flex;flex-direction:column;min-width:0}
.vxmain header{display:flex;align-items:center;gap:10px;padding:12px 20px;min-height:68px}
.gs{flex:1;max-width:620px;display:flex;align-items:center;gap:10px;padding:0 14px;border-radius:14px;border:1px solid var(--line);background:var(--glass);height:46px}
.gs input{flex:1;background:none;border:0;color:inherit;outline:0;min-width:0}.gs kbd{font-size:.72rem;border:1px solid var(--line);border-radius:6px;padding:2px 6px;color:var(--mut)}.gs .si{color:var(--mut);display:grid}
.vxmain header>.bellw{margin-left:auto}
.vxapp .ib{width:42px;height:42px;border-radius:50%;border:1px solid var(--line);background:none;color:inherit;display:grid;place-items:center;cursor:pointer;position:relative;flex:none}
.vxapp .ib.av{background:linear-gradient(135deg,#6e8cff,#a278ff);color:#fff;font-weight:800;border:0}
.usr{display:flex;gap:10px;align-items:center;background:none;border:0;color:inherit;cursor:pointer;text-align:left}.usr .un{display:grid;line-height:1.2}.usr small{color:var(--mut)}
.vxapp .burger{display:none}
.vxapp .bdg{position:absolute;top:-2px;right:-2px;min-width:18px;height:18px;border-radius:9px;background:#ff5a73;color:#fff;font-size:.7rem;font-style:normal;display:grid;place-items:center;padding:0 4px}
.vxapp .bellw,.vxapp .qw{position:relative}.vxapp .pop{display:none;position:absolute;right:0;top:50px;width:min(340px,86vw);max-height:60vh;overflow:auto;background:var(--ink);border:1px solid var(--line);border-radius:14px;padding:12px;box-shadow:0 20px 50px rgba(0,0,0,.4);z-index:5}
.vxapp .pop.on{display:block}.vxapp .pop h4{margin:0 0 8px}
.vxapp .qpop{width:200px;top:48px;padding:6px}.vxapp .qpop button{display:block;width:100%;text-align:left;background:none;border:0;color:inherit;padding:10px;border-radius:8px;cursor:pointer}.vxapp .qpop button:hover{background:rgba(110,140,255,.15)}
.vxapp .nt{display:block;width:100%;text-align:left;border:0;border-left:3px solid #6e8cff;padding:8px 10px;margin:6px 0;color:inherit;cursor:pointer;border-radius:0 8px 8px 0;background:rgba(110,140,255,.08)}
.vxapp .nt.bad{border-color:#ff5a73}.vxapp .nt.warn{border-color:#ffb347}
.vxapp main{flex:1;overflow:auto;padding:6px 20px 70px}
.vxapp main>*{max-width:1280px;margin-left:auto;margin-right:auto}
.vxapp h3{margin:0 0 10px;font-size:1.02rem}.vxapp h2{margin:0}.vxapp .mut,.vxapp small{color:var(--mut)}.vxapp .fine{font-size:.78rem;margin:10px 0 0}
.dgrid{display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:16px;align-items:start}
.dl{display:grid;gap:16px;min-width:0}.dr{position:sticky;top:0;margin:0!important}
.db4{grid-column:1/-1;display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:16px}.db4>.card2{margin:0}
.greet{display:flex;gap:16px;align-items:flex-start;flex-wrap:wrap}.greet>div:first-child{flex:1;min-width:220px}.greet h2{font-size:2rem}
.gd{text-align:right;color:var(--text);font-size:.9rem;line-height:1.4}
.kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}@media(max-width:1250px){.kpis{grid-template-columns:repeat(2,minmax(0,1fr))}}
.kpi{position:relative;text-align:left;display:grid;grid-template-columns:auto 1fr;gap:6px 12px;align-items:center;padding:16px;border-radius:16px;border:1px solid var(--line);background:var(--glass);color:inherit;animation:fin .5s both}
button.kpi{cursor:pointer;transition:.2s}button.kpi:hover{transform:translateY(-3px);border-color:rgba(130,160,255,.6)}
.kt small{display:block;font-size:.8rem}.kt b{font-size:1.3rem;white-space:nowrap}.ceop p{font-size:.9rem;margin:6px 0}.ks{grid-column:1/-1;display:flex;gap:8px;align-items:center;font-size:.8rem;min-height:30px;flex-wrap:wrap}
.ks .up{color:#3ddc97;font-style:normal;font-weight:700}.ks .dn2{color:#ff6b81;font-style:normal;font-weight:700}
.spk{margin-left:auto;display:flex;gap:3px;align-items:flex-end;height:30px}.spk i{width:5px;border-radius:2px;display:block;animation:grow .7s both;transform-origin:bottom}.sg{background:#3ddc97}.sr{background:#ff5a73}.sp{background:#a278ff}
.prog{flex:1;height:6px;border-radius:3px;background:rgba(130,150,255,.2);overflow:hidden;min-width:60px}.prog i{display:block;height:100%;background:linear-gradient(90deg,#6e8cff,#a278ff);border-radius:3px}
.ki{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;color:#fff;flex:none}
.ki.g{background:linear-gradient(135deg,#1fc58a,#13a06f)}.ki.r{background:linear-gradient(135deg,#ff5a73,#e03a56)}.ki.b{background:linear-gradient(135deg,#3b82f6,#2563eb)}.ki.p{background:linear-gradient(135deg,#8b5cf6,#6d3df0)}.ki.o{background:linear-gradient(135deg,#ffb347,#f59e0b)}
.vxapp .pres{display:inline-block;width:10px;height:10px;border-radius:50%;background:#7a82a8;margin-right:8px}.vxapp .pres.on{background:#35d49a;box-shadow:0 0 0 4px rgba(53,212,154,.25)}.vxapp .hh{text-align:right;min-width:96px}.vxapp .hh small{display:block}
.vxapp .card2{padding:18px;border-radius:18px;border:1px solid var(--line);background:var(--glass);margin-bottom:16px;backdrop-filter:blur(10px)}
.recs .rh{display:flex;gap:12px;align-items:center;margin-bottom:12px}.recs .rh h3{margin:0;flex:1;font-size:1.15rem}
.rl{display:grid;gap:10px}.rec{display:flex;gap:14px;align-items:center;padding:12px 14px;border-radius:14px;border:1px solid var(--line);background:rgba(110,140,255,.06);flex-wrap:wrap}
.rt{flex:1;min-width:200px}.rt b{display:block}.rt small{display:block;margin-top:2px}.ra{display:flex;gap:8px;flex-wrap:wrap}
.ceop{text-align:left}.orb{margin:-4px 0 0}.ceop h3{font-size:1.4rem;margin:0}.ceop .chatl{height:150px;margin:12px 0 8px}
.qp{display:grid;gap:6px;margin-bottom:10px}.qp button{text-align:left;background:rgba(110,140,255,.08);border:1px solid var(--line);color:inherit;padding:9px 12px;border-radius:10px;cursor:pointer;transition:.2s}.qp button:hover{background:rgba(110,140,255,.2)}
.vxapp .aif{display:flex;gap:8px}.vxapp .aif input{flex:1;min-width:0;padding:11px 14px;border-radius:12px;border:1px solid var(--line);background:rgba(110,140,255,.06);color:inherit}
.sendb{width:44px;border-radius:12px;border:0;background:linear-gradient(135deg,#7a5cff,#6b4bf2);color:#fff;cursor:pointer;display:grid;place-items:center}
.vxapp .chatl{overflow:auto;display:flex;flex-direction:column;gap:8px;padding:4px}
.vxapp .msg{max-width:92%;padding:9px 13px;border-radius:14px;line-height:1.45;white-space:pre-wrap;font-size:.92rem}.vxapp .msg.bot{background:rgba(110,140,255,.16);align-self:flex-start}.vxapp .msg.me{background:linear-gradient(135deg,#6e8cff,#a278ff);color:#fff;align-self:flex-end}.vxapp .msg.err{color:#ff8fa0}
.dr0 .chatl{height:360px}
.accrf{margin-top:14px;padding-top:12px;border-top:1px solid var(--line)}.accrf h4{margin:0 0 8px}.accrf details{margin:10px 0}.accrf summary{cursor:pointer;color:var(--mut,#9aa3c7)}#accRes .draft{margin:8px 0}
.ev{list-style:none;margin:0;padding:0;display:grid;gap:8px}.ev button{display:flex;gap:12px;align-items:center;width:100%;text-align:left;background:none;border:0;color:inherit;cursor:pointer;padding:6px;border-radius:10px}.ev button:hover{background:rgba(110,140,255,.1)}
.evd{width:62px;flex:none}.evd b{display:block;color:#6e8cff;font-size:.85rem}.evd small{font-size:.8rem}
.qg{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.qg button{position:relative;display:grid;gap:6px;justify-items:center;text-align:center;font-size:.78rem;padding:10px 4px;border-radius:12px;border:1px solid var(--line);background:rgba(110,140,255,.06);color:inherit;cursor:pointer;transition:.2s}
.qg button:hover{transform:translateY(-2px);border-color:rgba(130,160,255,.6)}.qg .qs{opacity:.65}.qg em{position:absolute;top:4px;right:4px;font-size:.6rem;font-style:normal;color:var(--mut)}
.vxapp .tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px}
.vxapp .two{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:16px}.vxapp .two>.card2{margin:0}.vxapp .two{margin-bottom:16px}
.vxapp .rows{list-style:none;margin:0;padding:0;display:grid;gap:8px}
.vxapp .hlt-h{display:flex;gap:16px;align-items:center;margin-bottom:12px}.vxapp .hring .hr0{fill:none;stroke:rgba(255,255,255,.1);stroke-width:8}.vxapp .hring .hr1{fill:none;stroke:#6e8cff;stroke-width:8;stroke-linecap:round}.vxapp .hring.g .hr1{stroke:#3ddc97}.vxapp .hring.o .hr1{stroke:#ffb347}.vxapp .hring.r .hr1{stroke:#ff6b81}.vxapp .hrt{fill:var(--tx,#fff);font:700 22px system-ui}
.vxapp .hlab.g{color:#3ddc97}.vxapp .hlab.o{color:#ffb347}.vxapp .hlab.r{color:#ff6b81}.vxapp .hbars{list-style:none;margin:0;padding:0}.vxapp .hbars li{display:grid;grid-template-columns:1fr 90px 30px;gap:10px;align-items:center;padding:8px 0;border-top:1px solid rgba(255,255,255,.07)}.vxapp .hbars small{display:block;color:var(--mut)}.vxapp .hbars em{font-style:normal;text-align:right;font-weight:600}
.vxapp .hb{position:relative;display:block;height:8px;border-radius:6px;background:rgba(255,255,255,.1);overflow:visible}.vxapp .hb i{display:block;height:100%;border-radius:6px;background:#6e8cff}.vxapp .hb i.g{background:#3ddc97}.vxapp .hb i.o{background:#ffb347}.vxapp .hb i.r{background:#ff6b81}.vxapp .hb u{position:absolute;top:-4px;width:2px;height:16px;background:#fff;opacity:.7}
.vxapp .goalr{display:flex;gap:8px;margin:6px 0 12px}.vxapp .goalr input{flex:1;min-width:0}.vxapp .goalt{margin:8px 0}
@media(max-width:560px){.vxapp .hbars li{grid-template-columns:1fr 70px 28px}}
.vxapp .rows li{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:center;padding:12px 14px;border-radius:12px;border:1px solid var(--line);background:rgba(110,140,255,.06)}
.vxapp .cstools{margin:0 0 10px;justify-content:flex-end}.vxapp .rows.big li[data-edit]{cursor:pointer;transition:.2s}.vxapp .rows.big li[data-edit]:hover{border-color:rgba(130,160,255,.6)}
.vxapp .rows li.off{opacity:.55}.vxapp .rows small{display:block}.vxapp .rows li>span{color:var(--mut);font-size:.9rem}
.vxapp .irow{display:grid;grid-template-columns:1fr 64px 56px 100px 64px 24px;gap:6px;margin-bottom:6px}.vxapp .irow input,.vxapp .irow select{padding:8px;border-radius:8px;border:1px solid var(--line);background:var(--glass);color:inherit;min-width:0}@media(max-width:520px){.vxapp .irow{grid-template-columns:1fr 1fr}.vxapp .irow .id{grid-column:1/-1}}.beta{font-size:.6rem;font-weight:800;letter-spacing:.08em;background:#ffb347;color:#2a1a00;border-radius:6px;padding:1px 6px;margin-left:4px;vertical-align:middle}.betab{display:flex;gap:12px;justify-content:space-between;align-items:center;padding:10px 14px;margin:8px 0 12px;border-radius:12px;border:1px solid rgba(255,179,71,.5);background:rgba(255,179,71,.1);font-size:.9rem}.ready{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin:16px 0}.ready h4{margin:0 0 6px}.ready .soonl li{opacity:.75}@media(max-width:520px){.ready{grid-template-columns:1fr}}.vxapp .inc{color:#3ddc97!important}.vxapp .late{color:#ff6b81!important;font-weight:700}.vxapp .stt{font-style:normal;padding:2px 8px;border-radius:99px;border:1px solid var(--line)}
.vxapp .bar2{display:flex;gap:10px;justify-content:space-between;margin:10px 0 14px;flex-wrap:wrap}
.vxapp .srch{flex:1;min-width:180px;max-width:360px;padding:10px 14px;border-radius:12px;border:1px solid var(--line);background:var(--glass);color:inherit}
.vxapp .lnk{background:none;border:0;text-decoration:underline;padding:0;color:inherit;cursor:pointer}
.vxapp .dh{margin:18px 0 8px;color:var(--mut)}.vxapp .dh.today{color:#6e8cff;font-weight:800}.vxapp .dh.past{opacity:.6}
.vxapp .chart{width:100%;height:auto}.vxapp .gl{stroke:var(--line)}.vxapp .ax{fill:var(--mut);font-size:11px}
.vxapp .cbar{transform-box:fill-box;transform-origin:bottom;animation:grow .7s cubic-bezier(.2,.8,.2,1) both}.vxapp .cv{fill:var(--text);font-size:10px;font-weight:700;opacity:.9}.vxapp .gl0{stroke:var(--mut);opacity:.55}.vxapp .chov{fill:transparent}.vxapp .cgrp:hover .chov{fill:rgba(130,160,255,.10)}.vxapp .cgrp:hover .cbar{filter:brightness(1.12)}
@keyframes grow{from{transform:scaleY(0)}}
.vxapp .leg{display:flex;gap:18px;flex-wrap:wrap;font-size:.85rem;color:var(--mut);margin-top:6px}.vxapp .leg b{color:var(--text);margin-left:4px}.vxapp .leg i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:6px}.vxapp .sb1{background:#6e8cff}.vxapp .sb2{background:#2fd08f}.vxapp .sb3{background:#ff5a73}
.vxapp .dn{display:flex;gap:14px;align-items:center;flex-wrap:wrap}.vxapp .seg{animation:segin .9s both}@keyframes segin{from{opacity:0}}
.vxapp .dnt{fill:var(--text);font-size:15px;font-weight:800}.vxapp .dns{fill:var(--mut);font-size:8px}.vxapp .leg2 li{display:flex;align-items:center;gap:0}.vxapp .leg2 li b{margin-left:auto;padding-left:12px}.vxapp .leg2{list-style:none;margin:0;padding:0;display:grid;gap:6px;font-size:.85rem}.vxapp .leg2 i{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:8px}
.vxapp .chks{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px;margin:12px 0}.vxapp fieldset{border:0;padding:0;margin:10px 0}
.vxapp .amodal{position:absolute;inset:0;background:rgba(0,0,0,.6);display:none;place-items:center;padding:16px;z-index:10;overflow:auto}.vxapp .amodal.on{display:grid}
.vxapp .mbox{width:min(600px,100%);background:var(--ink);border:1px solid var(--line);border-radius:18px;padding:20px;max-height:92vh;overflow:auto}
.vxapp textarea{width:100%;box-sizing:border-box;border-radius:12px;border:1px solid var(--line);background:var(--glass);color:inherit;padding:10px}
.vxapp .toast{position:fixed;left:50%;bottom:24px;font-weight:600;box-shadow:0 10px 30px rgba(0,0,0,.45);transform:translate(-50%,30px);opacity:0;pointer-events:none;padding:12px 18px;border-radius:12px;background:#1e2a5a;color:#fff;transition:.3s;z-index:60;max-width:90vw}
.vxapp .toast.on{opacity:1;transform:translate(-50%,0)}.vxapp .toast.err{background:#a3243a}.vxapp .toast.ok{background:#1d7a55}
.vxapp .scrim{display:none}.vxapp .note{font-size:.92rem}.vxapp .dact{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}
@media(max-width:1100px){.dgrid{grid-template-columns:minmax(0,1fr)}.dr{position:static}.usr .un{display:none}}
@media(max-width:820px){
 .vxapp>aside{position:fixed;inset:0 auto 0 0;z-index:30;transform:translateX(-100%);transition:.3s;background:var(--ink)}
 .vxapp.side>aside{transform:none}.vxapp.side .scrim{display:block;position:fixed;inset:0;z-index:25;background:rgba(0,0,0,.5)}
 .vxapp .burger{display:grid}.vxmain header{padding:8px 12px;gap:6px}.vxapp main{padding:6px 12px 70px}.gs kbd,.webb{display:none}.greet h2{font-size:1.5rem}.gd{text-align:left}.qg{grid-template-columns:repeat(2,1fr)}
}
@media(prefers-reduced-motion:reduce){.vxapp .cbar,.vxapp .seg,.vxapp .kpi,.spk i{animation:none}}
'''

tpl = r'''<!doctype html>
<html lang="cs" data-theme="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Vexaronet – zakázky, rezervace a faktury pro malé firmy</title>
<meta name="description" content="Vexaronet pro OSVČ a malé firmy: zdarma ke stažení: aplikace pro váš počítač i zdrojový kód. CRM pro celou EU, zakázky, kalendář a rezervace, faktury a finance. Vyzkoušejte ukázku.">
<meta name="theme-color" content="#03040a">
<script>(function(){try{var q=new URLSearchParams(location.search),st=(window.matchMedia&&matchMedia("(display-mode: standalone)").matches)||navigator.standalone===true;if(q.get("app")==="1"&&!q.get("r")&&!q.get("w")&&!q.get("s")||st&&!q.get("r")&&!q.get("w")&&!q.get("s")){document.documentElement.classList.add("appmode")}}catch(e){}})()</script><link rel="manifest" href="/manifest.webmanifest"><link rel="apple-touch-icon" href="/assets/apple-touch-icon.png"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-title" content="Vexaronet">
<link rel="canonical" href="https://vexaronet.com/">
<meta property="og:type" content="website"><meta property="og:locale" content="cs_CZ"><meta property="og:site_name" content="Vexaronet">
<meta property="og:title" content="Vexaronet – zdarma ke stažení pro váš počítač"><meta property="og:description" content="Zákazníci, zakázky, kalendář, online rezervace, sklad, faktury a e-shop na jednom místě. Zdarma ke stažení: aplikace pro váš počítač a zdrojový kód.">
<meta property="og:url" content="https://vexaronet.com/"><meta property="og:image" content="https://vexaronet.com/assets/og-image.jpg"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta property="og:image:alt" content="Přehled firmy ve Vexaronetu: ukázková data, ukazatele, faktury a doporučení AI CEO"><meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="Vexaronet – zakázky, rezervace a faktury pro malé firmy"><meta name="twitter:description" content="Zákazníci, zakázky, kalendář, online rezervace, sklad, faktury a e-shop na jednom místě. Zdarma ke stažení."><meta name="twitter:image" content="https://vexaronet.com/assets/og-image.jpg">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0' stop-color='%233b7bff'/%3E%3Cstop offset='1' stop-color='%238b5cf6'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='32' height='32' rx='8' fill='%2303040a'/%3E%3Cpath d='M7 9l9 15 9-15' fill='none' stroke='url(%23g)' stroke-width='3.4' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E">
<script type="application/ld+json">{"@context":"https://schema.org","@graph":[{"@type":"Organization","name":"Vexaronet","url":"https://vexaronet.com/","email":"info@vexaronet.com"},{"@type":"WebSite","name":"Vexaronet","url":"https://vexaronet.com/","inLanguage":"cs"}]}</script>
<script>try{var t=localStorage.getItem('vx-theme');if(t==='light'||t==='dark')document.documentElement.setAttribute('data-theme',t)}catch(e){}</script>
<link rel="preload" href="/assets/fonts/manrope-latin-wght-normal.woff2" as="font" type="font/woff2" crossorigin>
<style>@@CSS@@</style>
</head>
<body>
<a class="skip" href="#obsah">Přeskočit na obsah</a>
<div class="bg" aria-hidden="true"><div class="b b1"></div><div class="b b2"></div><div class="b b3"></div><div class="grid"></div><div class="hot"></div><div class="vig"></div></div>

<header class="nav" id="nav"><div class="in">
  <a class="logo" href="#top" aria-label="Vexaronet – úvod"><svg viewBox="0 0 32 32" aria-hidden="true"><defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5b9bff"/><stop offset="1" stop-color="#8b5cf6"/></linearGradient></defs><rect width="32" height="32" rx="9" fill="#0a0e24" stroke="rgba(150,175,255,.35)"/><path d="M7.5 9.5l8.5 14 8.5-14" fill="none" stroke="url(#lg)" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/></svg><span>Vexaronet<small>pro malé firmy</small></span></a>
  <nav class="links" aria-label="Hlavní navigace"><a href="#funkce">Funkce</a><a href="#ukazka">Ukázka</a><a href="#cenik">Stáhnout zdarma</a><a href="#namiru">Na míru</a><a href="#postup">Vývoj</a><a href="#early">Novinky e-mailem</a></nav>
  <div class="nav-r">
    <button class="themeb" id="theme" type="button" aria-label="Přepnout světlý a tmavý režim"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 14.5A8 8 0 019.5 4 8 8 0 1020 14.5z"/></svg></button>
    <button class="btn btn-ghost btn-sm" id="acc" type="button">Přihlásit</button>
    <button class="btn btn-ghost btn-sm" type="button" data-namiru="start">Dejte mi vědět</button>
    <button class="btn btn-main btn-sm btn-demo" type="button" data-demo="1" title="Otevře ukázkovou aplikaci bez registrace, s ukázkovými daty">▶ Ukázka, jak to vypadá</button>
    <button class="burger" id="burger" aria-label="Otevřít menu" aria-expanded="false" aria-controls="mnav"><i></i></button>
  </div>
</div></header>
<nav class="mnav" id="mnav" aria-label="Mobilní navigace"><a href="#funkce" style="--i:1">Funkce</a><a href="#ukazka" style="--i:2">Ukázka</a><a href="#cenik" style="--i:3">Stáhnout zdarma</a><a href="#postup" style="--i:4">Vývoj</a><a href="#early" style="--i:5">Novinky</a><a href="#namiru" style="--i:5">Systém na míru</a><a href="#prihlaseni" style="--i:6">Přihlásit se</a><a href="#demo" data-demo="1" style="--i:7" title="Otevře ukázkovou aplikaci bez registrace, s ukázkovými daty">▶ Ukázka, jak to vypadá</a><a href="#stahnout" data-install="1" style="--i:8">Instalace aplikace</a></nav>

<main id="obsah">
<section class="hero" id="top"><div class="wrap">
  <div>
    <span class="eyebrow fade" id="launchE">Vexaronet je venku</span>
    <h1 id="h1">Vexaronet si stáhnete <span class="grad">zdarma</span>.</h1>
    <p class="sub fade d2">Zakázky, zákazníci, faktury a kalendář malé firmy v jedné aplikaci, která běží u vás v počítači. Bez účtu, bez internetu, bez poplatku.</p>
    <div class="vpick fade d2"><div class="vp"><i aria-hidden="true">⬇</i><b>Aplikace pro počítač</b><span>zdarma</span></div><div class="vp vp2"><i aria-hidden="true">&lt;/&gt;</i><b>Zdrojový kód</b><span>zdarma</span></div></div>
    <div class="cta fade d3"><a class="btn btn-main" href="#cenik">⬇ Stáhnout zdarma</a><button class="btn btn-ghost btn-demo" type="button" data-demo="1" title="Otevře ukázkovou aplikaci bez registrace, s ukázkovými daty">▶ Ukázka, jak to vypadá</button></div>
    <p class="betan fade d3"><b>Beta verze.</b> Základ funguje, další části jsou označené „připravujeme“. Data máte jen u sebe v prohlížeči, pravidelně si stahujte zálohu.</p>
    <p class="hlinks fade d3"><a href="#funkce">Co už funguje</a> · <a href="#cenik">Stažení</a> · <button type="button" class="lnkb" data-install="1">Instalace aplikace</button></p>
  </div>
  <div class="scene" id="scene"><div class="fit" id="fit"><div class="stage" id="stage"><div class="laptop" id="laptop">
    <div class="sh"></div>
    <div class="lid"><div class="screen"><button type="button" class="shotb" id="shotB" data-zoom="1" aria-label="Zvětšit ukázku přehledu v účtu"><img src="assets/prehled.webp" width="2160" height="1314" alt="Přehled firmy ve Vexaronetu: ukazatele, doporučení AI CEO a chat s AI CEO (ukázková data)" fetchpriority="high"></button><span class="sample">Ukázková data · kliknutím zvětšíte</span></div></div>
    <div class="base"><div class="keys">@@KEYS@@</div><div class="pad"></div></div><div class="edge"></div>
  </div>
  <div class="fl d">AI CEO</div><div class="fl e">Faktury a CRM</div>
  </div></div></div>
</div></section>

<div class="strip" aria-hidden="true"><div class="tr">
 <span>AI centrum</span><span>Faktury a evidence</span><span>CRM a zakázky</span><span>Jednoduché weby</span><span>Marketing</span><span>Automatizace</span>
 <span>AI centrum</span><span>Faktury a evidence</span><span>CRM a zakázky</span><span>Jednoduché weby</span><span>Marketing</span><span>Automatizace</span>
</div></div>

<section id="jak"><div class="wrap">
  <div class="sec-h c" data-r="up"><span class="eyebrow">Jak to funguje</span><h2>Od stažení <span class="grad">k první zakázce</span></h2><p class="lead">Po stažení máte hotovou aplikaci, která běží u vás v počítači, a k ní zdrojový kód. Nepotřebujete web ani účet. Online variantu nasazovat nemusíte.</p></div>
  <div class="how" data-r="up">
   <div class="hs"><b>1</b><h3>Stáhnete balíček</h3><p>Stáhnete si balíček zdarma: hotovou lokální aplikaci, nebo i zdrojový kód s návodem.</p></div>
   <div class="hs"><b>2</b><h3>Dvakrát kliknete</h3><p>Soubor Vexaronet.html se otevře v prohlížeči. Data zůstávají jen na vašem počítači, bez účtu a bez internetu.</p></div>
   <div class="hs"><b>3</b><h3>Přidáte zákazníky</h3><p>Nahrajete je z Excelu (CSV) nebo napíšete ručně. Zakázky, úkoly a termíny máte na jednom místě.</p></div>
   <div class="hs"><b>4</b><h3>Vystavujete a zálohujete</h3><p>Faktury, docházka a reporty. Zálohu stáhnete jedním kliknutím do souboru.</p></div>
  </div>
  <div class="cta" style="justify-content:center;margin-top:24px"><button class="btn btn-main btn-demo" type="button" data-demo="1" title="Otevře ukázkovou aplikaci bez registrace, s ukázkovými daty">▶ Ukázka, jak to vypadá</button><a class="btn btn-ghost" href="#cenik">⬇ Stáhnout zdarma</a></div>
</div></section>

<section id="ucet"><div class="wrap">
  <div class="sec-h c" data-r="up"><span class="eyebrow">Přehled firmy · online verze</span><h2>Takhle vypadá <span class="grad">přehled firmy</span></h2><p class="lead">Online verze ukazuje na jednom místě ukazatele firmy, doporučení AI CEO a jeho chat. Lokální verze a zdrojový kód obsahují jádro aplikace bez AI částí. Obrázek je z aplikace s ukázkovými daty, kliknutím ho zvětšíte.</p></div>
  <button type="button" class="appshot" data-zoom="1" data-r="up" aria-label="Zvětšit ukázku přehledu v účtu"><img src="assets/prehled.webp" width="2160" height="1314" loading="lazy" alt="Přehled firmy ve Vexaronetu: tržby, nezaplacené faktury, aktivní zakázky, doporučení AI CEO a chat s AI CEO (ukázková data)"></button>
  <div class="cta" style="justify-content:center;margin-top:22px"><button class="btn btn-main btn-demo" type="button" data-demo="1" title="Otevře ukázkovou aplikaci bez registrace, s ukázkovými daty">▶ Ukázka, jak to vypadá</button></div>
  <p class="mut fine" style="text-align:center;margin-top:12px">Ukázková data. Aplikace je v beta verzi, hotové části fungují se skutečnými daty, nehotové jsou označené „připravujeme“.</p>
  <div class="ceox" data-r="up"><h3>Co je AI CEO, běžnou řečí</h3><div class="ceoc">
   <div><b>Kontroluje</b><p>Čte data, která ve Vexaronetu máte: faktury po splatnosti, zakázky, rezervace, sklad, příjmy a výdaje. Z nich skládá zdraví firmy, platby od zákazníků a výhled na 30 dní.</p></div>
   <div><b>Navrhuje</b><p>Napíše doporučení, co řešit jako první, a v chatu odpoví na otázky nad vašimi daty.</p></div>
   <div><b>Rozhodujete vy</b><p>AI CEO sám nic nemění, nevystavuje ani neodesílá. Je v tarifu PRO a vyšším a běží přes externí AI službu. Odpovědi mohou být nepřesné, důležité věci si ověřte.</p></div>
  </div></div>
</div></section>

<section id="funkce"><div class="wrap">
  <div class="sec-h" data-r="up"><span class="eyebrow">Funkce platformy</span><h2>Sedm oblastí, <span class="grad">jasný stav u každé</span></h2><p class="lead">U každého modulu je napsáno, co už funguje, co funguje s omezením a co teprve připravujeme. Úplně hotový je zatím jen základ řízení firmy, ostatní moduly fungují částečně.</p><p class="legend"><b class="stb stb-now">k dispozici</b> funguje se skutečnými daty · <b class="stb stb-lim">s omezením</b> funguje, ale má podmínku nebo chybějící část · <b class="stb stb-soon">připravujeme</b> zatím nejde použít</p></div>
  <div class="svcs">@@MODS@@</div>
</div></section>

<section id="ukazka"><div class="wrap">
  <div class="sec-h c" data-r="up"><span class="eyebrow">Interaktivní ukázka</span><h2>Ukázky <span class="grad">principu</span></h2><p class="lead">Dvě krátké ukázky s vymyšlenými daty. Celou aplikaci si můžete vyzkoušet v demu.</p></div>
  <div class="demo">
    <div class="panel" data-r="up"><span class="tag-demo">Ukázka</span><h3>Dashboard podle oboru</h3><p class="sm">Po registraci vyberete typ podnikání a menu a názvy se přizpůsobí.</p>
      <div class="bar" id="bizbar" role="group" aria-label="Typ podnikání">@@BIZ@@</div><div class="mods" id="mods"></div></div>
    <div class="panel" data-r="up" style="--d:.1s"><span class="tag-demo">Ukázka</span><h3>AI připraví, vy schválíte</h3><p class="sm">Takhle funguje schvalování: AI navrhuje, změnu dat provedete až vy. Samotný AI Autopilot ještě není hotový, tahle ukázka je jen princip.</p>
      <div class="act" id="a1"><b>Odeslat upomínku 3 klientům</b><small>Faktury po splatnosti, celkem 18 400 Kč (ukázka)</small><div class="bts"><button class="btn btn-main btn-sm" type="button" data-ap="ok">Schválit</button><button class="btn btn-ghost btn-sm" type="button" data-ap="no">Zamítnout</button></div><div class="res" hidden></div></div>
      <div class="act" id="a2"><b>Vystavit fakturu za zakázku č. 41</b><small>Částka 6 500 Kč (ukázka)</small><div class="bts"><button class="btn btn-main btn-sm" type="button" data-ap="ok">Schválit</button><button class="btn btn-ghost btn-sm" type="button" data-ap="no">Zamítnout</button></div><div class="res" hidden></div></div>
    </div>
  </div>
  <div class="warn" data-r="up"><b>Důležité upozornění:</b> faktury a evidence nejsou legislativně ověřené. Před ostrým použitím je nechte zkontrolovat účetním. Účetnictví a DPH ještě nejsou hotové. Funkce závislé na externích službách (platby, e-maily, AI) fungují jen tam, kde jsou služby zapnuté.</div>
</div></section>

<section id="cenik"><div class="wrap">
  <div class="sec-h c" data-r="up"><span class="eyebrow">Stažení</span><h2>Stáhněte si, <span class="grad">co potřebujete</span></h2><p class="lead">Aplikace i zdrojový kód jsou zdarma. Online verzi s předplatným připravujeme, cena zatím není.</p></div>
  @@PLANS@@
</div></section>

<section id="namiru"><div class="wrap">
  <div class="custom" data-r="up">
    <div class="cu-t"><span class="eyebrow">Řešení na míru</span><h2>Potřebujete systém <span class="grad">přesně pro svou firmu?</span></h2>
    <p class="lead">Pokud vám nestačí hotová aplikace, můžeme připravit systém podle toho, jak vaše firma pracuje. Vycházíme z hotových částí Vexaronetu, takže nezačínáme od nuly. Rozsah vždy určuje individuální nabídka.</p>
    <ul class="ticks"><li>Moduly a postupy podle toho, jak vaše firma pracuje</li><li>Případně AI asistent nad vašimi zakázkami, zákazníky a fakturami</li><li>Nasazení, nastavení a zaškolení týmu</li></ul>
    <h3 class="cuh">Jak poptávka probíhá</h3><ol class="cuol"><li>Pošlete poptávku (formulář níže nebo e-mail info@vexaronet.com).</li><li>Ozveme se a probereme, co potřebujete. Konzultace je nezávazná.</li><li>Pošleme individuální nabídku s rozsahem a cenou. Nic se neděje bez vašeho odsouhlasení.</li></ol>
    <p class="mut fine">Údržba, podpora po nasazení a případné pravidelné náklady (provoz, služby třetích stran) se určují v nabídce, žádné nevymýšlíme předem. Referenční projekty zatím nemáme. Problém nebo chybu nahlásíte e-mailem na info@vexaronet.com.</p></div>
    <div class="cu-p"><small>Cena</small><div class="cu-price"><span>od</span> <b>20 000 Kč</b></div><p class="mut">Orientační cena bez DPH za jednorázovou přípravu. Cena od 20 000 Kč nezahrnuje předem daný rozsah, konečnou cenu a rozsah určí individuální nabídka po nezávazné konzultaci. Může zahrnovat například úpravu modulů nebo nastavení pro vaši firmu.</p>
    <button type="button" class="btn btn-main" id="askCustom" data-namiru="1">Poslat poptávku</button></div>
  </div>
</div></section>

<section id="otazky"><div class="wrap">
  <div class="sec-h c" data-r="up"><span class="eyebrow">Časté otázky</span><h2>Co se nejčastěji <span class="grad">ptáte</span></h2><p class="lead">Co funguje, je napsané jako funguje, co se připravuje, jako připravuje.</p></div>
  <div class="faq" data-r="up">
   <details><summary>Je to opravdu zdarma?</summary><p>Ano. Aplikaci pro počítač i zdrojový kód si stáhnete zdarma a nic neplatíte. Online verzi s předplatným teprve připravujeme, její cena zatím není stanovená a nic vám neúčtujeme.</p></details>
   <details><summary>Co dostanu a co si musím platit?</summary><p>Dostanete hotovou lokální aplikaci (soubor, který otevřete v prohlížeči), zdrojový kód, testy a dokumentaci, vše zdarma. Žádné další služby platit nemusíte. Nic nenasazujete na web, aplikace běží u vás v počítači. Software nesmíte přeprodávat ani dál šířit, viz licenční podmínky. Napište na info@vexaronet.com.</p></details>
   <details><summary>Musím něco instalovat nebo platit hosting?</summary><p>U lokální verze ne. Rozbalíte složku, otevřete soubor Vexaronet.html a aplikace běží. Data se ukládají v prohlížeči na tomto počítači a zálohu stáhnete do souboru jedním kliknutím. Pravidelně ji ukládejte mimo počítač, protože po smazání dat prohlížeče by data zmizela. Aktualizaci pošleme jako nový soubor a vy ho jen vyměníte.</p></details>
   <details><summary>Mám zákazníky v Excelu. Dají se přenést?</summary><p>Ano. Tabulku uložíte jako CSV a nahrajete ji v části Zákazníci (Import z CSV). Před uložením uvidíte náhled a duplicity se přeskočí. Zakázky a faktury se zatím zadávají ručně. Data si můžete stáhnout zpět do CSV.</p></details>
   <details><summary>Co už opravdu funguje a co se připravuje?</summary><p>Funguje: zákazníci, zakázky, kalendář a online rezervace, sklad, zaměstnanci s docházkou, faktury a příjmy a výdaje, import bankovních výpisů, reporty. S omezením: e-shop (platba převodem), editor webu, AI CEO a AI Účetní, marketingové návrhy a automatizace (vyžadují externí služby nebo tarif). Připravujeme: PDF a QR platby, odesílání faktur, DPH a účetnictví, AI Autopilot, platební bránu a vlastní doménu. Přesný stav u každého modulu najdete v části Funkce.</p></details>
   <details><summary>Dá se spustit e-shop propojený se skladem a fakturami?</summary><p>Jen v online verzi. V lokální verzi a ve zdrojovém kódu je e-shop ve výchozím nastavení vypnutý. V online verzi ano, v tarifech PRO a vyšších. Zákazník nakoupí na veřejné stránce obchodu bez registrace, objednávka se uloží, zboží se odepíše ze skladu a vystaví se faktura. Platba kartou není, zákazník platí převodem podle faktury. Fakturu mu zatím posíláte sami, e-mailem se neodesílá. Před spuštěním je potřeba vyplnit fakturační údaje.</p></details>
   <details><summary>Dělá AI něco sama bez mého svolení?</summary><p>Ne. AI CEO a AI Účetní navrhují a upozorňují a AI texty jen připraví návrh. Cokoli změní vaše data, uložíte až vy. AI Autopilot, který by akce propojoval, ještě není hotový.</p></details>
   <details><summary>Kam se posílají moje data kvůli AI?</summary><p>Když použijete AI funkci, odešle se váš dotaz a údaje potřebné k odpovědi externí AI službě (Google). Podrobnosti jsou v zásadách ochrany osobních údajů.</p></details>
   <details><summary>Kde jsou moje data a vidí je někdo jiný?</summary><p>Databáze běží v regionu EU (Stockholm). Každá firma vidí jen svoje záznamy a zaměstnanci jen to, co jim role dovolí. Zálohy, šifrování a bezpečnostní audit zatím jako hotovou jistotu neslibujeme. V lokální verzi jsou data jen na vašem počítači a nikam se neodesílají. Podrobnosti najdete v zásadách ochrany osobních údajů.</p></details>
   <details><summary>Můžu data exportovat nebo účet zrušit?</summary><p>V lokální verzi stáhnete zálohu všech dat jedním kliknutím do souboru. V online verzi můžete data stáhnout do CSV z reportů a seznamů. Zrušení účtu online a smazání dat zatím nejsou samoobslužné: napište na info@vexaronet.com. Samoobslužné zrušení připravujeme.</p></details>
   <details><summary>Je to vhodné pro můj obor?</summary><p>Po registraci vyberete obor (autoservis, řemeslník, restaurace, služby, kadeřnictví a krása, obchod nebo jiný) a aplikace přizpůsobí menu, názvy, stavy zakázek a první kroky. Moduly mimo váš obor zůstávají dostupné.</p></details>
   <details><summary>Nahradí mi to účetního?</summary><p>Ne. Vexaronet pomáhá připravit podklady (evidence, faktury, export pro účetního). Účetnictví a DPH ještě nejsou hotové a daňové ani právní rady od nás nečekejte.</p></details>
  </div>
</div></section>

<section id="postup"><div class="wrap">
  <div class="sec-h c" data-r="up"><span class="eyebrow">Postup vývoje</span><h2>Osm etap <span class="grad">k hotové platformě</span></h2><p class="lead">Stavíme po částech a každou etapu otestujeme. Stav je uveden otevřeně.</p></div>
  <div class="tl" id="tl"><div class="tl-f"></div>@@STAGES@@</div>
</div></section>

<section id="early"><div class="wrap contact">
  <div data-r="up"><span class="eyebrow">Novinky a stav vývoje</span><h2>Stav vývoje <span class="grad">a novinky e-mailem</span></h2><p class="lead">Vexaronet je beta verze. Níže je souhrn stavu. Chcete-li jen dostávat novinky, stačí nechat e-mail.</p><div class="ready"><div><h4>Už funguje</h4><ul class="ticks"><li>Registrace, přihlášení, obnova hesla</li><li>Přehled firmy s grafy</li><li>Zákazníci, zakázky, kalendář, úkoly</li><li>Online rezervace pro zákazníky</li><li>Zaměstnanci, docházka a odpracované hodiny s výdělkem</li><li>Sklad a e-shop (platba převodem)</li><li>Faktury, příjmy a výdaje, import bankovních výpisů</li><li>Jednoduchý web a AI návrhy textů (s omezením)</li><li>AI CEO a AI Účetní (s omezením)</li></ul></div><div><h4>Připravujeme</h4><ul class="ticks soonl"><li>PDF faktury, QR platby, odesílání faktur</li><li>DPH a účetnictví (po odborné kontrole)</li><li>Platební brána a placené předplatné</li><li>AI Autopilot a další AI asistenti</li><li>Vlastní doména pro web</li><li>Slevové kódy, profily a recenze</li></ul></div></div>
    <div class="ci"><a href="mailto:info@vexaronet.com"><small>E-mail</small><b>info@vexaronet.com</b></a><button type="button" class="btn btn-ghost" id="openChat" style="justify-content:flex-start">Zeptat se AI asistenta</button></div></div>
  <form class="card" id="form" name="early-access" data-r="up" novalidate>
    <p class="hp" aria-hidden="true"><label>Nevyplňovat <input name="bot-field" tabindex="-1" autocomplete="off"></label></p>
    <div class="bar" role="group" aria-label="Účel formuláře"><button type="button" class="chipb" data-fmode="news" aria-pressed="true">Novinky e-mailem</button><button type="button" class="chipb" data-fmode="custom" aria-pressed="false">Poptávka systému na míru</button></div>
    <p class="mut fine" id="fPurpose">Stačí e-mail. Pošleme vám jen informace o vývoji Vexaronetu a odhlásit se můžete kdykoli.</p>
    <div class="fg">
      <div class="f"><label for="fMail">E-mail <i aria-hidden="true">*</i></label><input id="fMail" name="email" type="email" required aria-required="true" autocomplete="email" inputmode="email"></div>
      <div class="f"><label for="fName"><span id="fNameL">Jméno (nepovinné)</span></label><input id="fName" name="jmeno" autocomplete="name"></div>
      <div class="f" data-cu hidden><label for="fCo">Firma (nepovinné)</label><input id="fCo" name="firma" autocomplete="organization"></div>
      <div class="f" data-cu hidden><label for="fBiz">Typ podnikání</label><select id="fBiz" name="obor"><option value="">Vyberte</option>@@BIZOPTS@@</select></div>
      <input type="hidden" id="fPlan" name="tarif" value="">
      <div class="f full" data-cu hidden><label for="fMsg" id="fMsgL">Co by měl systém umět? Popište firmu a čeho chcete dosáhnout.</label><textarea id="fMsg" name="zprava"></textarea></div>
      <div class="f full"><label class="chk"><input type="checkbox" name="souhlas" id="fOk" required aria-required="true"><span id="fOkT">Souhlasím, že mi Vexaronet bude na uvedený e-mail posílat novinky o vývoji. Souhlas mohu kdykoli odvolat. <a href="/ochrana-udaju/" target="_blank" rel="noopener">Zásady ochrany osobních údajů</a> <i aria-hidden="true">*</i></span></label></div>
      <div class="f full" id="fAgeW"><label class="chk"><input type="checkbox" name="vek" id="fAge"><span>Je mi alespoň 15 let. <i aria-hidden="true">*</i></span></label></div>
      <div class="f full"><button class="btn btn-main" type="submit" id="send">Odebírat novinky</button></div>
    </div>
    <div class="st" id="st" role="status" aria-live="polite"></div>
  </form>
</div></section>
</main>


<footer><div class="wrap">
  <div class="fg2">
    <div><a class="logo" href="#top" style="padding:0"><svg viewBox="0 0 32 32" aria-hidden="true"><rect width="32" height="32" rx="9" fill="#0a0e24" stroke="rgba(150,175,255,.35)"/><path d="M7.5 9.5l8.5 14 8.5-14" fill="none" stroke="url(#lg)" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/></svg><span>Vexaronet<small>pro malé firmy</small></span></a><p style="color:var(--mut);margin-top:14px;max-width:320px;font-size:.93rem">Aplikace pro podnikatele a malé firmy: zákazníci, zakázky, faktury a AI CEO na jednom místě. Zatím v beta verzi pro Česko.</p></div>
    <div><h4>Navigace</h4><a href="#funkce">Funkce</a><a href="#ukazka">Ukázka</a><a href="#cenik">Ceník</a><a href="#otazky">Časté otázky</a><button type="button" class="fl2" data-install="1">Instalace aplikace</button><a href="#postup">Vývoj</a><a href="#early">Novinky e-mailem</a></div>
    <div><h4>Informace</h4><button type="button" class="fl2" data-legal="podminky">Obchodní podmínky</button><button type="button" class="fl2" data-legal="licence">Licenční podmínky</button><button type="button" class="fl2" data-legal="ochrana-udaju">Ochrana osobních údajů</button><button type="button" class="fl2" data-legal="cookies">Cookies</button><button type="button" class="fl2" data-privacy="1">Nastavení soukromí</button><a href="/nahlasit/">Nahlásit nezákonný obsah</a><a href="/dsa/">Kontaktní místa (DSA)</a><a href="mailto:info@vexaronet.com">info@vexaronet.com</a></div>
  </div>
  <div class="copy"><span>© <span id="yr">2026</span> Vexaronet</span><span>vexaronet.com</span></div>
</div></footer>

<button class="fab" id="chatFab" type="button" aria-expanded="false" aria-controls="chat"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 5h16v11H9l-5 4z"/></svg><span class="t">AI asistent</span><i class="pulse"></i></button>
<div class="aichat" id="chat" role="dialog" aria-label="AI asistent Vexaronet"><div class="ch"><div><b>AI asistent</b><small>Odpovídá automaticky, jde o AI</small></div><button type="button" id="chatX" aria-label="Zavřít chat">✕</button></div><div id="chatBody" aria-live="polite"></div><div id="chatSugg"></div><form id="chatForm"><textarea id="chatIn" rows="1" placeholder="Napište dotaz…" aria-label="Vaše zpráva" maxlength="1000"></textarea><button type="submit" aria-label="Odeslat">➤</button></form><p class="ainote">Asistent může chybovat. Závazné jsou informace od týmu.</p></div>
<div id="appSplash" class="appsplash" hidden><svg viewBox="0 0 32 32" width="72" height="72" aria-hidden="true"><defs><linearGradient id="lg2" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5b9bff"/><stop offset="1" stop-color="#8b5cf6"/></linearGradient></defs><rect width="32" height="32" rx="9" fill="#0a0e24" stroke="rgba(150,175,255,.35)"/><path d="M7.5 9.5l8.5 14 8.5-14" fill="none" stroke="url(#lg2)" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/></svg><h1>Vexaronet</h1><p>Přihlaste se do svého účtu.</p><button class="btn btn-main" type="button" id="splashLogin">Přihlásit se</button></div>
<dialog id="dlg" aria-labelledby="dT"><div class="dlg" id="dBody"></div></dialog>
<noscript><style>[data-r]{opacity:1!important;transform:none!important}.hero h1 .w>span{transform:none}.fade{opacity:1;transform:none}</style></noscript>
<script src="/assets/vendor/supabase-js-2.45.4/supabase.js" integrity="sha384-0w2KAL2YHP6wKOkUDzkCDGgVvfmHnj02DHeQ6XcHOgTfFsGyonKOpShMH1x6nk9o" defer></script>
<script type="application/json" id="modData">@@MODDATA@@</script>
<script type="application/json" id="bizData">@@BIZDATA@@</script>
<script>
(function(){'use strict';
var $=function(s,r){return (r||document).querySelector(s)},$$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};
var RM=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
var MOD=JSON.parse($('#modData').textContent),BIZ=JSON.parse($('#bizData').textContent);
$('#yr').textContent=new Date().getFullYear();
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
var LAUNCH=@@LAUNCH@@;
(function(){var h=$('#h1'),e=$('#launchE');if(!h||!LAUNCH)return;var d=Math.ceil((new Date(LAUNCH+'T00:00:00+01:00')-new Date())/864e5),dt=new Date(LAUNCH+'T12:00:00').toLocaleDateString('cs-CZ');
if(d>1){h.textContent='Vexaronet spouštíme už za '+d+'\u00a0'+(d<5?'dny':'dní')+'.';if(e)e.textContent='Start '+dt}else if(d===1){h.textContent='Vexaronet spouštíme už zítra.';if(e)e.textContent='Start '+dt}else{h.textContent='Vexaronet právě spouštíme.';if(e)e.textContent='Dokončujeme poslední kroky'}})();
(function(){var h=$('#h1');var t=h.textContent.trim();h.setAttribute('aria-label',t);var i=0;h.innerHTML=t.split(' ').map(function(w){i++;return '<span class="w" aria-hidden="true"><span style="--i:'+i+'">'+w+'</span></span>'}).join(' ')})();

/* motiv */
$('#theme').addEventListener('click',function(){var r=document.documentElement,n=r.getAttribute('data-theme')==='light'?'dark':'light';r.setAttribute('data-theme',n);try{localStorage.setItem('vx-theme',n)}catch(e){}});

/* scroll */
var nav=$('#nav'),pars=$$('[data-par]'),tl=$('#tl'),steps=$$('.step');
function onScroll(){var y=window.scrollY;nav.classList.toggle('sc',y>20);document.documentElement.style.setProperty('--gy',(-y*.3)+'px');
 if(!RM)pars.forEach(function(p){p.style.transform='translate3d(0,'+(y*parseFloat(p.dataset.par))+'px,0)'});
 var r=tl.getBoundingClientRect(),vh=window.innerHeight;tl.style.setProperty('--p',Math.min(1,Math.max(0,(vh*.6-r.top)/r.height)).toFixed(3));
 steps.forEach(function(s){s.classList.toggle('act',s.getBoundingClientRect().top<vh*.62)});
 var cur='';['funkce','ukazka','cenik','namiru','postup','early'].forEach(function(id){var e=document.getElementById(id);if(e&&e.getBoundingClientRect().top<vh*.4)cur=id});
 $$('.links a').forEach(function(a){a.classList.toggle('on',a.getAttribute('href')==='#'+cur)})}
var tick=false;window.addEventListener('scroll',function(){if(!tick){tick=true;requestAnimationFrame(function(){onScroll();tick=false})}},{passive:true});onScroll();
if(!RM)window.addEventListener('pointermove',function(e){var d=document.documentElement.style;d.setProperty('--cx',e.clientX+'px');d.setProperty('--cy',e.clientY+'px')},{passive:true});
document.addEventListener('pointermove',function(e){var c=e.target.closest&&e.target.closest('[data-glow]');if(c){var b=c.getBoundingClientRect();c.style.setProperty('--mx',(e.clientX-b.left)+'px');c.style.setProperty('--my',(e.clientY-b.top)+'px')}},{passive:true});

/* reveal */
var rv=$$('[data-r]');if('IntersectionObserver' in window&&!RM){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.12,rootMargin:'0px 0px -6% 0px'});rv.forEach(function(e){io.observe(e)})}else rv.forEach(function(e){e.classList.add('in')});

/* menu */
var bur=$('#burger'),mn=$('#mnav');
function menu(o){bur.setAttribute('aria-expanded',o);bur.setAttribute('aria-label',o?'Zavřít menu':'Otevřít menu');mn.classList.toggle('on',o);document.body.style.overflow=o?'hidden':''}
bur.addEventListener('click',function(){menu(bur.getAttribute('aria-expanded')!=='true')});$$('a',mn).forEach(function(a){a.addEventListener('click',function(){menu(false)})});
document.addEventListener('keydown',function(e){if(e.key==='Escape')menu(false)});

/* notebook */
var scene=$('#scene'),lap=$('#laptop');
function resize(){var s=Math.min(1,scene.clientWidth/640);document.documentElement.style.setProperty('--s',s.toFixed(3));scene.style.height=(540*s)+'px'}resize();window.addEventListener('resize',resize);
var tx=0,ty=0,cx=0,cy=0,last=0,t0=performance.now(),vis=true;
$('.hero').addEventListener('pointermove',function(e){var b=scene.getBoundingClientRect();tx=Math.max(-1.4,Math.min(1.4,(e.clientX-(b.left+b.width/2))/(b.width/2)));ty=Math.max(-1.4,Math.min(1.4,(e.clientY-(b.top+b.height/2))/(b.height/2)));last=performance.now()});
if('IntersectionObserver' in window)new IntersectionObserver(function(e){vis=e[0].isIntersecting}).observe(scene);
function loop(now){if(vis){var idle=now-last>2500,gx=idle?Math.sin((now-t0)/2400)*.8:tx,gy=idle?Math.cos((now-t0)/3100)*.35:ty;cx+=(gx-cx)*.07;cy+=(gy-cy)*.07;lap.style.setProperty('--ry',(cx*12).toFixed(2));lap.style.setProperty('--rx',(-cy*7).toFixed(2))}requestAnimationFrame(loop)}
if(!RM)requestAnimationFrame(loop);


/* zvětšení ukázky přehledu */
(function(){var zs=$$('[data-zoom]');if(!zs.length)return;var z=null,from=null;
function close(){if(z){z.classList.remove('on');document.documentElement.style.overflow='';if(from)from.focus()}}
zs.forEach(function(zb){zb.addEventListener('click',function(){from=zb;if(!z){z=document.createElement('div');z.id='zoomShot';z.setAttribute('role','dialog');z.setAttribute('aria-modal','true');z.setAttribute('aria-label','Ukázka přehledu v účtu');z.innerHTML='<button type="button" class="zx" aria-label="Zavřít">×</button><img src="assets/prehled.webp" alt="Přehled firmy ve Vexaronetu (ukázková data)"><p>Ukázková data. Takto vypadá přehled po přihlášení do účtu.</p>';document.body.appendChild(z);z.addEventListener('click',close)}
z.classList.add('on');document.documentElement.style.overflow='hidden'})});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&z&&z.classList.contains('on'))close()})})();

/* ukázka: obor */
var mods=$('#mods');
function showBiz(k){mods.innerHTML=BIZ[k].map(function(m,i){return '<div style="animation-delay:'+(i*.07)+'s">'+esc(m)+'</div>'}).join('')}
$('#bizbar').addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;$$('#bizbar button').forEach(function(x){x.setAttribute('aria-pressed',x===b)});showBiz(b.dataset.biz)});showBiz(Object.keys(BIZ)[0]);
/* ukázka: schvalování */
$$('.act').forEach(function(a){a.addEventListener('click',function(e){var b=e.target.closest('[data-ap]');if(!b)return;var ok=b.dataset.ap==='ok';a.classList.remove('ok','no');a.classList.add(ok?'ok':'no');$('.bts',a).hidden=true;var r=$('.res',a);r.hidden=false;r.textContent=ok?'Schváleno uživatelem. V ostré verzi by se akce provedla. Tady jde jen o ukázku, nic se neodeslalo.':'Zamítnuto. AI akci neprovede.'})});

/* dialogy */
var dlg=$('#dlg'),dB=$('#dBody'),lastFocus=null;
function openD(h){lastFocus=document.activeElement;dB.innerHTML='<button class="dx" type="button" aria-label="Zavřít">×</button>'+h;if(!dlg.open){if(dlg.showModal)dlg.showModal();else dlg.setAttribute('open','')}$('.dx',dB).focus();dB.scrollTop=0}
function closeDlg(){if(dlg.open)dlg.close()}
dlg.addEventListener('click',function(e){if(e.target===dlg||e.target.closest('.dx')||e.target.closest('[data-close]'))closeDlg()});
dlg.addEventListener('close',function(){if(/^#(modul|ochrana|cookies|prihlaseni|podminky)/.test(location.hash))history.replaceState(null,'',location.pathname+location.search);if(lastFocus&&lastFocus.focus)lastFocus.focus({preventScroll:true})});
function showMod(id){var m=MOD[id];if(!m)return;var SO=/ \(připravujeme\)$/,ok=m.items.filter(function(i){return !SO.test(i)}),so=m.items.filter(function(i){return SO.test(i)}).map(function(i){return i.replace(SO,'')});openD('<span class="eyebrow">Modul · etapa '+m.stage+'</span><h2 id="dT">'+esc(m.name)+'</h2><p>'+esc(m.short)+'</p><div class="draft"><b>Stav: '+esc(m.stlab)+'.</b> '+esc(m.note)+'</div>'+(ok.length?'<h3>Už funguje</h3><ul class="ticks">'+ok.map(function(i){return '<li>'+esc(i)+'</li>'}).join('')+'</ul>':'')+(so.length?'<h3>Připravujeme</h3><ul class="ticks soonl">'+so.map(function(i){return '<li>'+esc(i)+'</li>'}).join('')+'</ul>':'')+'<p class="mut fine">Důležité akce AI provádí jen po vašem schválení.</p><div class="dact"><button class="btn btn-main" type="button" data-early="start">Založit účet zdarma</button><button class="btn btn-ghost" type="button" data-app="mclose">Zavřít</button></div>')}
var LEGAL={'ochrana-udaju':'<span class="eyebrow">Právní informace</span><h2 id="dT">Ochrana osobních údajů</h2><p class="mut">Poslední aktualizace: 27. listopadu 2026.</p><div class="draft"><b>Návrh k právní kontrole.</b> Text popisuje, jak služba funguje v beta verzi. Před veřejným spuštěním ho musí zkontrolovat odborník.</div><h3>Kdo údaje zpracovává</h3><p>Správcem osobních údajů je provozovatel služby Vexaronet (web vexaronet.com). <b>Úplné identifikační údaje provozovatele (jméno nebo firma, IČO, adresa) zatím nejsou doplněné.</b> Doplníme je před veřejným spuštěním a nejpozději před přijímáním plateb. Kontakt pro všechny dotazy k osobním údajům: <a href=\"mailto:info@vexaronet.com\">info@vexaronet.com</a>.</p><h3>Jaké údaje zpracováváme a proč</h3><ul><li><b>Stažení aplikace a odběr novinek.</b> E-mail, který zadáte před stažením, čas a znění souhlasu a potvrzení věku alespoň 15 let. Účel: umožnit stažení a posílat informace o vývoji Vexaronetu. Právní základ: váš souhlas, který můžete kdykoli odvolat odkazem v e-mailu nebo zprávou na info@vexaronet.com. Souhlas s novinkami je podmínkou stažení zdarma. Bez něj stažení nabízet nemůžeme a můžete se s námi domluvit e-mailem jinak.</li><li><b>Aplikace v počítači (lokální verze).</b> Data, která do ní zadáte, zůstávají jen v prohlížeči na vašem počítači. Aplikace je nikam neposílá a my k nim nemáme přístup. Odpovídáte za jejich zálohu.</li><li><b>Věk.</b> Při registraci jen potvrzení věkové hranice (18 let, u pozvaného zaměstnance 15 let) a čas potvrzení; u odběru novinek potvrzení věku alespoň 15 let (souhlas podle § 7 zákona č. 110/2019 Sb.). Datum narození ani doklad nesbíráme.</li><li><b>Odhlášení z novinek.</b> Odhlásit se lze odkazem v každém e-mailu, bez přihlášení. Odhlášenou adresu si ponecháme v seznamu odhlášených, abychom vám nic dalšího neposlali (právní základ: plnění právní povinnosti a oprávněný zájem).</li><li><b>Oznámení nezákonného obsahu.</b> Jméno, e-mail, označený obsah, vysvětlení a otisk IP adresy (jen kvůli ochraně proti zahlcení, IP samotnou neukládáme). Účel: vyřízení oznámení a evidence podle nařízení o digitálních službách. Právní základ: plnění právní povinnosti.</li><li><b>Účet a používání aplikace.</b> E-mail, jméno, název firmy, země, volitelně obor, role, údaje o tarifu a zkušebním období a čas souhlasu s podmínkami. Účel: provoz účtu a poskytování služby. Právní základ: plnění smlouvy.</li><li><b>Data, která do aplikace zadáte vy.</b> Zákazníci, zakázky, faktury, rezervace, úkoly, směny a docházka vašich zaměstnanců. Tato data patří vám. Ve vztahu k údajům vašich zákazníků a zaměstnanců jste správcem vy a my je pro vás ukládáme a zpracováváme jako zpracovatel.</li><li><b>Docházka.</b> Čas příchodu a odchodu, který zaměstnanec sám potvrdí tlačítkem Online a Offline. Vidí ji zaměstnanec a majitel nebo správce firmy.</li><li><b>Objednávky a rezervace zákazníků vaší firmy.</b> Jméno, kontakt a údaje objednávky zadané na veřejné stránce obchodu nebo rezervací. Správcem je firma, která stránku provozuje.</li><li><b>Poptávka systému na míru.</b> Jméno, e-mail, firma, obor a text poptávky. Účel: odpovědět a připravit nabídku. Právní základ: opatření před uzavřením smlouvy na vaši žádost.</li><li><b>Novinky o vývoji (dobrovolný souhlas).</b> Jméno, e-mail, případně firma a obor. Účel: poslat informace o vývoji. Právní základ: váš souhlas, který můžete kdykoli odvolat. Souhlas s novinkami je oddělený od registrace a od podmínek služby.</li></ul><h3>AI funkce a předávání údajů</h3><p>Když použijete AI funkci (AI CEO, AI Účetní, návrh textů webu nebo marketingu), odešle se váš dotaz a údaje potřebné k odpovědi externímu poskytovateli jazykového modelu (Google). U AI Účetní to může být i nahraný doklad. AI jen navrhuje, změny dat potvrzujete vy. Odpovědi mohou být nepřesné.</p><h3>Komu údaje předáváme</h3><p>Technickým poskytovatelům, bez kterých služba nefunguje: Cloudflare (hosting a síť), Supabase (databáze a přihlášení, region EU Stockholm), Resend (odesílání e-mailů) a Google (jazykový model). Údaje neprodáváme a nepoužíváme je k reklamě. Informace o předávání údajů mimo Evropský hospodářský prostor a o záručních mechanismech doplníme do finální verze.</p><h3>Jak dlouho údaje uchováváme</h3><p>Konkrétní lhůty uchování zatím nemáme stanovené a doplníme je do finální verze. Dokud je nestanovíme, platí: údaje o účtu a firmě uchováváme po dobu používání služby, přihlášku k novinkám do odvolání souhlasu.</p><h3>Export, zrušení účtu a smazání údajů</h3><p>Data můžete stáhnout do CSV z reportů a seznamů. Zrušení účtu a smazání údajů zatím nejsou samoobslužné, požádejte o ně e-mailem na <a href=\"mailto:info@vexaronet.com\">info@vexaronet.com</a>. Zákonem uložené uchování dokladů (například daňových) tím není dotčeno.</p><h3>Vaše práva</h3><p>Máte právo na přístup k údajům, jejich opravu, výmaz, omezení zpracování, přenositelnost a právo vznést námitku. Souhlas můžete kdykoli odvolat. Stačí napsat na <a href=\"mailto:info@vexaronet.com\">info@vexaronet.com</a>. Máte také právo podat stížnost u Úřadu pro ochranu osobních údajů (uoou.gov.cz).</p>','podminky':'<span class="eyebrow">Právní informace</span><h2 id="dT">Obchodní podmínky</h2><p class="mut">Poslední aktualizace: 27. listopadu 2026.</p><div class="draft"><b>Návrh pro beta verzi, nejde o schválené právní znění.</b> Před veřejným spuštěním a přijímáním plateb ho musí zkontrolovat právník.</div><h3>1. Provozovatel</h3><p>Službu Vexaronet (vexaronet.com) provozuje provozovatel, jehož identifikační údaje (jméno nebo firma, IČO, adresa) <b>zatím nejsou doplněné</b> a doplníme je před veřejným spuštěním. Kontakt: <a href=\"mailto:info@vexaronet.com\">info@vexaronet.com</a>.</p><h3>2a. Stažení aplikace pro počítač a zdrojového kódu</h3><p>Aplikaci pro počítač (lokální verzi) a zdrojový kód si můžete stáhnout zdarma po zadání e-mailu a souhlasu s odběrem novinek. Použití se řídí <a href=\\"/licence/\\">licenčními podmínkami</a>: software nesmíte přeprodávat ani dál šířit. Lokální verze běží ve vašem počítači, vaše data zůstávají u vás a zálohujete si je sami.</p><h3>2. Co služba je</h3><p>Vexaronet je webová aplikace pro evidenci zákazníků, zakázek, rezervací, skladu, faktur a dalších agend malé firmy. Je ve fázi beta. U každé funkce je na webu uvedeno, zda je k dispozici, k dispozici s omezením, nebo se připravuje. Funkce označené „připravujeme“ nejsou součástí služby.</p><h3>3. Účet a zkušební období</h3><p>Pro používání potřebujete účet. Tarif START je zdarma bez časového omezení. Placené tarify můžete jednou na firmu 30 dní zdarma vyzkoušet bez platební karty, počítá se od prvního přihlášení. Po skončení se účet vrátí na START, data zůstanou, ale funkce placeného tarifu a limity START se řídí tarifem START.</p><h3>3a. Věk uživatelů</h3><p>Účet s vlastní firmou a placenými tarify může založit jen osoba starší 18 let. Osoba od 15 let, která ukončila povinnou školní docházku, může používat účet, do kterého ji pozve zaměstnavatel (firma, pro kterou pracuje). Osobám mladším 15 let službu neposkytujeme. Při registraci se ptáme jen na potvrzení věkové hranice; datum narození ani doklady nesbíráme.</p><h3>4. Ceny a platby</h3><p>Stažení aplikace pro počítač a zdrojového kódu je zdarma. Platby za online verzi zatím nejsou spuštěné, předplatné nelze zaplatit a nic se neúčtuje. Uvedené ceny jsou měsíční bez DPH. Před zahájením placení vás o podmínkách a cenách výslovně informujeme.</p><h3>5. AI funkce</h3><p>AI funkce navrhují texty, doporučení a údaje. Jejich výstup může být nepřesný, odpovídáte za jeho zkontrolování před použitím. Nic, co mění vaše data, se neprovede bez vašeho potvrzení.</p><h3>6. Faktury a účetnictví</h3><p>Vexaronet nenahrazuje účetního ani daňového poradce. Faktury a evidence před ostrým použitím nechte zkontrolovat účetním. Účetnictví a DPH nejsou součástí aktuální verze.</p><h3>7. Vaše data</h3><p>Data, která do služby vložíte, patří vám. Můžete je exportovat do CSV. Zrušení účtu a smazání dat vyřídíme na žádost na <a href=\"mailto:info@vexaronet.com\">info@vexaronet.com</a>. Lhůty uchování doplníme do finální verze.</p><h3>8. Dostupnost a omezení odpovědnosti</h3><p>Beta verze se vyvíjí, funkce se mohou měnit a služba může být dočasně nedostupná. Konkrétní rozsah odpovědnosti doplní právník do finální verze.</p><h3>9. Obsah, který zveřejňujete, a jeho moderování</h3><p>Firmy mohou ve Vexaronetu zveřejnit web, e-shop, rezervační stránku a profil. Takový obsah ukládáme a zpřístupňujeme na jejich žádost (hostingová služba podle nařízení (EU) 2022/2065 o digitálních službách). Za obsah odpovídá firma, která ho zveřejnila.</p><ul><li><b>Co není dovoleno:</b> obsah, který je nezákonný (např. podvodná nabídka, porušení autorských práv, neoprávněné zveřejnění osobních údajů, nebezpečné zboží) nebo je v rozporu s těmito podmínkami.</li><li><b>Jak nahlásit:</b> kdokoli může nahlásit konkrétní obsah formulářem <a href=\"/nahlasit/\">Nahlásit nezákonný obsah</a> (odkaz je i na každém zveřejněném webu, obchodě a rezervační stránce). Přijetí potvrdíme e-mailem s referenčním číslem.</li><li><b>Jak rozhodujeme:</b> každé oznámení posoudí člověk; automatizované moderování ani automatické mazání nepoužíváme. Obsah neodstraňujeme jen proto, že přišlo oznámení. Možná opatření: bez opatření, omezení viditelnosti, znepřístupnění nebo odstranění obsahu, pozastavení služby, předání orgánům. Podezření na trestný čin ohrožující život nebo bezpečnost oznamujeme policii.</li><li><b>Odůvodnění a náprava:</b> pokud obsah omezíme, pošleme firmě odůvodnění (co, proč, na jakém základě a jaké má možnosti nápravy). Oznamovatele vyrozumíme o rozhodnutí. Proti rozhodnutí se lze ohradit odpovědí na kontaktní místo (rozhodnutí znovu posoudíme) nebo se obrátit na soud či dozorový orgán.</li><li><b>Kontaktní místa:</b> viz <a href=\"/dsa/\">Kontaktní místa (DSA)</a>.</li></ul><h3>10. Změny podmínek a kontakt</h3><p>O podstatné změně podmínek vás budeme informovat. Dotazy a nahlášení problémů pište na <a href=\"mailto:info@vexaronet.com\">info@vexaronet.com</a>.</p>','cookies':'<span class=\"eyebrow\">Právní informace</span><h2 id=\"dT\">Informace o cookies</h2><p class=\"mut\">Poslední aktualizace: 27. listopadu 2026.</p><h3>Nezbytné úložiště (bez souhlasu)</h3><p>Prohlížeč si v úložišti (ne v cookies) pamatuje jen to, co je nutné pro službu, kterou jste si vyžádali: přihlášení do aplikace (zajišťuje ho Supabase), zvolený světlý nebo tmavý režim, historii rozhovoru s AI asistentem v rámci aktuální karty a vaši volbu v nastavení soukromí. Na to se podle § 89 odst. 3 zákona č. 127/2005 Sb. souhlas nevyžaduje.</p><h3>Nepovinné služby (jen se souhlasem)</h3><p>Web <b>v současnosti nepoužívá</b> žádnou analytiku, reklamní cookies ani nahrávání relací a nesleduje vás napříč weby. Pokud bychom je v budoucnu zapnuli, spustí se až po vašem souhlasu v liště, kde je odmítnutí stejně snadné jako přijetí. Volbu půjde kdykoli změnit nebo odvolat v odkazu „Nastavení soukromí“ v patičce; po odvolání se sběr hned zastaví.</p><h3>Externí služby při načtení webu</h3><p>Písma i knihovnu pro přihlášení hostujeme sami, při načtení stránky se proto nic nestahuje od Google Fonts ani z cizích CDN. Po přihlášení komunikuje aplikace se Supabase (databáze a přihlášení, EU).</p><h3>Aplikace v počítači</h3><p>Stažená lokální verze si ukládá vaše data a nastavení v úložišti prohlížeče (localStorage) na vašem počítači. Je to nezbytné pro její fungování a nikam se to neodesílá.</p>','licence':'<span class=\\"eyebrow\\">Právní informace</span><h2 id=\\"dT\\">Licenční podmínky</h2><p class=\\"mut\\">Poslední aktualizace: 27. listopadu 2026.</p><div class=\\"draft\\"><b>Návrh k právní kontrole.</b> Text vyjadřuje záměr provozovatele. Před širším šířením ho má zkontrolovat právník.</div><h3>1. Co se licencuje</h3><p>Aplikace Vexaronet ve verzi pro počítač a její zdrojový kód (dále „software“). Stáhnout ho můžete zdarma na vexaronet.com po zadání e-mailu a souhlasu s novinkami. Autorská práva k softwaru má provozovatel Vexaronet.</p><h3>2. Co smíte</h3><ul><li>Používat software ve vlastní firmě nebo vlastní činnosti, na svých počítačích, bez časového omezení.</li><li>Upravovat zdrojový kód pro vlastní potřebu.</li><li>Zálohovat si software a svá data.</li></ul><h3>3. Co nesmíte</h3><ul><li><b>Software ani jeho upravenou verzi nesmíte prodávat, pronajímat, půjčovat ani sublicencovat.</b></li><li>Nesmíte ho nabízet jiným osobám jako službu (například provozovat ho pro své zákazníky na webu).</li><li>Nesmíte ho zveřejňovat ani rozesílat dál, ani zdarma. Kdo ho chce, stáhne si ho sám na vexaronet.com.</li><li>Nesmíte odstraňovat označení autora a používat název Vexaronet a logo pro vlastní produkt nebo službu.</li></ul><h3>4. Povaha licence</h3><p>Licence je bezúplatná, nevýhradní, nepřenosná a časově neomezená. Zanikne porušením těchto podmínek. Po zániku musíte software přestat používat a smazat ho.</p><h3>5. Bez záruky</h3><p>Software je beta verze a poskytuje se tak, jak je, bez záruky. Odpovídáte za zálohování svých dat a za kontrolu faktur a dalších dokladů před jejich použitím. Faktury v lokální verzi jsou zjednodušené a nenahrazují účetnictví. Provozovatel neodpovídá za škodu vzniklou používáním softwaru v rozsahu, v jakém to zákon dovoluje. Zákonná práva, která nelze smluvně vyloučit, tím nejsou dotčena.</p><h3>6. Aktualizace a podpora</h3><p>Aktualizace ani individuální podporu nezaručujeme. Chybu nebo dotaz pošlete na info@vexaronet.com, odpovíme podle možností.</p><h3>7. Součásti třetích stran</h3><p>Součástí balíčku mohou být komponenty třetích stran (například knihovna supabase-js) s vlastními licencemi, které tyto podmínky nemění.</p><h3>8. Rozhodné právo a kontakt</h3><p>Podmínky se řídí právem České republiky. Provozovatel: identifikační údaje (jméno nebo firma, IČO, adresa) zatím nejsou doplněné. Kontakt: <a href=\\"mailto:info@vexaronet.com\\">info@vexaronet.com</a>. Zpracování e-mailu při stažení popisují <a href=\\"/ochrana-udaju/\\">zásady ochrany osobních údajů</a>.</p>','dsa':'<span class=\"eyebrow\">Právní informace</span><h2 id=\"dT\">Kontaktní místa a hlášení obsahu (DSA)</h2><p class=\"mut\">Poslední aktualizace: 10. listopadu 2026.</p><p>Vexaronet ukládá a zveřejňuje obsah, který do něj vkládají firmy (weby, e-shopy, rezervační stránky, profily). Podle nařízení (EU) 2022/2065 o digitálních službách jsme proto poskytovatelem hostingové služby.</p><h3>Jednotné kontaktní místo pro orgány členských států, Komisi a sbor (čl. 11)</h3><p>E-mail: <a href=\"mailto:info@vexaronet.com\">info@vexaronet.com</a>. Komunikovat lze česky nebo anglicky.</p><h3>Kontaktní místo pro uživatele a veřejnost (čl. 12)</h3><p>E-mail: <a href=\"mailto:info@vexaronet.com\">info@vexaronet.com</a>, česky nebo anglicky. Odpovídá člověk, nejen automatický systém.</p><h3>Nahlášení nezákonného obsahu (čl. 16)</h3><p>Použijte formulář <a href=\"/nahlasit/\">Nahlásit nezákonný obsah</a>. Uveďte přesnou adresu (URL) obsahu, případně kde přesně na stránce je, vysvětlete, proč ho považujete za nezákonný, a připojte jméno, e-mail a prohlášení o dobré víře. Oznámení obsahu sexuálního zneužívání dětí lze podat i bez jména a e-mailu. Přijetí potvrdíme e-mailem s referenčním číslem. Každé oznámení posoudí člověk; obsah automaticky neodstraňujeme. O rozhodnutí vás vyrozumíme.</p><h3>Když omezíme váš obsah (čl. 17)</h3><p>Firmě, jejíhož obsahu se rozhodnutí týká, pošleme odůvodnění: co jsme udělali, na základě čeho, proč a jaké má možnosti nápravy. Proti rozhodnutí se můžete ohradit na kontaktním místě (rozhodnutí znovu posoudíme) nebo se obrátit na soud či dozorový orgán (koordinátor digitálních služeb).</p><h3>Provozovatel</h3><p>Identifikační údaje provozovatele (jméno nebo firma, IČO, adresa) zatím nejsou doplněné; doplníme je před veřejným spuštěním. Pravidla pro obsah jsou v <a href=\"/podminky/\">obchodních podmínkách</a> (bod 9).</p>'};
function showLegal(k){if(LEGAL[k])openD(LEGAL[k]+'<div class="dact"><button class="btn btn-ghost" type="button" data-app="mclose">Zavřít</button></div>')}
var DIP=null;window.addEventListener('beforeinstallprompt',function(e){e.preventDefault();DIP=e;var m=document.getElementById('insGo');if(m)m.hidden=false});
window.addEventListener('appinstalled',function(){DIP=null;try{toastI('Aplikace je nainstalovaná.')}catch(e){}});
function toastI(t){var d=document.getElementById('insSt');if(d)d.textContent=t}
function insPlat(){var u=navigator.userAgent||'';if(/android/i.test(u))return 'android';if(/iphone|ipad|ipod/i.test(u)||(/Macintosh/i.test(u)&&navigator.maxTouchPoints>1))return 'ios';if(/windows/i.test(u))return 'windows';if(/Macintosh|Mac OS/i.test(u))return 'mac';return 'other'}
var DL='https://github.com/michal219/vexaronet/releases/download/app-latest/';
var INS={android:['Android (telefon, tablet)','<p><b>Doporučeno: instalace z prohlížeče.</b></p><ol class="ticks"><li>Otevřete <b>vexaronet.com</b> v prohlížeči <b>Chrome</b>.</li><li>Klepněte na tlačítko <b>Nainstalovat z prohlížeče</b> níže. Pokud se nezobrazí, otevřete menu <b>⋮</b> vpravo nahoře a zvolte <b>Instalovat aplikaci</b> (nebo <b>Přidat na plochu</b>).</li><li>Ikona Vexaronetu se objeví mezi aplikacemi.</li></ol>','<p>Soubor .apk je určený jen pro zařízení, kde instalace z prohlížeče nejde. Telefon při jeho otevření vyžaduje povolit instalaci z neznámého zdroje. Aplikace je podepsaná testovacím klíčem, který se s každou novou verzí mění, takže před aktualizací starou verzi odinstalujte. Soubor není z obchodu s aplikacemi a jeho bezpečnost systém neověřuje.</p>'],
 windows:['Windows (počítač)','<p><b>Doporučeno: instalace z prohlížeče.</b></p><ol class="ticks"><li>Otevřete <b>vexaronet.com</b> v prohlížeči <b>Chrome</b> nebo <b>Edge</b>.</li><li>Klikněte na tlačítko <b>Nainstalovat z prohlížeče</b> níže. Pokud se nezobrazí, klikněte na ikonu instalace vpravo v adresním řádku, nebo v Edge na <b>⋯ → Aplikace → Nainstalovat tento web jako aplikaci</b>.</li><li>Aplikace se otevře v samostatném okně a najdete ji v nabídce Start.</li></ol>','<p>Soubor .exe zatím <b>není digitálně podepsaný</b> a nemá ověřeného vydavatele, proto ho Windows nebo antivirus může zablokovat nebo na něj upozornit. Nedoporučujeme obcházet varování systému. Používejte instalaci z prohlížeče.</p>'],
 ios:['iPhone a iPad','<ol class="ticks"><li>Otevřete <b>vexaronet.com</b> v prohlížeči <b>Safari</b>.</li><li>Klepněte na <b>Sdílet</b> (čtverec se šipkou) a zvolte <b>Přidat na plochu</b>.</li></ol><p class="mut fine">Pro iPhone a iPad žádný soubor ke stažení není, instaluje se jen takto přes Safari.</p>'],
 mac:['Mac','<ol class="ticks"><li>V <b>Safari</b>: <b>Soubor → Přidat do Docku</b>. V <b>Chromu</b>: ikona instalace v adresním řádku.</li></ol><p class="mut fine">Pro Mac žádný soubor ke stažení není.</p>']};
function insShow(k){var p=INS[k]||INS.windows;var b=document.getElementById('insBody');if(!b)return;var fl=(k==='android'||k==='windows');b.innerHTML='<h3>'+p[0]+'</h3>'+p[1]+(fl?'<div class="dact"><button class="btn btn-main" type="button" id="insGo"'+(DIP?'':' hidden')+'>Nainstalovat z prohlížeče</button></div><details class="moreset insf"><summary>'+(k==='android'?'Soubor .apk (pokročilé)':'Soubor .exe (nepodepsaný, nedoporučujeme)')+'</summary>'+p[2]+'<p><a class="btn btn-ghost btn-sm" href="'+DL+(k==='android'?'Vexaronet.apk':'Vexaronet.exe')+'" rel="noopener">Stáhnout '+(k==='android'?'.apk':'.exe')+'</a></p></details>':'');[].forEach.call(document.querySelectorAll('[data-ins]'),function(x){x.setAttribute('aria-pressed',x.dataset.ins===k)})}
function installModal(){if(window.matchMedia&&matchMedia('(display-mode: standalone)').matches){openD('<h2 id="dT">Aplikace už běží</h2><p>Vexaronet už používáte jako nainstalovanou aplikaci.</p>');return}
 var k=insPlat();if(k==='other')k='windows';
 openD('<span class="eyebrow">Zdarma, bez obchodu s aplikacemi</span><h2 id="dT">Aplikace Vexaronet na plochu</h2><p>Vyberte zařízení. Nejjednodušší je přidat Vexaronet na plochu přímo z prohlížeče. Nepotřebujete účet v Google Play ani v Obchodě Microsoft.</p><div class="bar" role="group" aria-label="Zařízení"><button type="button" class="chipb" data-ins="android" aria-pressed="false">Android</button><button type="button" class="chipb" data-ins="windows" aria-pressed="false">Windows</button><button type="button" class="chipb" data-ins="ios" aria-pressed="false">iPhone / iPad</button><button type="button" class="chipb" data-ins="mac" aria-pressed="false">Mac</button></div><div id="insBody"></div><p class="mut" id="insSt" role="status"></p><p class="mut" style="font-size:13px">Aplikace je jen obal kolem webu Vexaronet. Má stejné funkce jako web, vlastní ikonu a okno a pro práci potřebuje internet. Podepsané vydání pro obchody s aplikacemi zatím nemáme.</p>');insShow(k)}
document.addEventListener('click',function(e){var i=e.target.closest('[data-install]');if(i){e.preventDefault();installModal();return}var s=e.target.closest('[data-ins]');if(s){insShow(s.dataset.ins);return}var g=e.target.closest('#insGo');if(g&&DIP){DIP.prompt();DIP.userChoice.then(function(c){toastI(c&&c.outcome==='accepted'?'Instalace spuštěna.':'Instalace zrušena.');DIP=null;g.hidden=true})}});
if('serviceWorker' in navigator&&(location.protocol==='https:'||location.hostname==='localhost')){window.addEventListener('load',function(){navigator.serviceWorker.register('/sw.js').catch(function(){})})}
function route(){var h=location.hash,m;if(h==='#prihlaseni')showAuth('login');else if(m=h.match(/^#modul-(\w+)/))showMod(m[1]);else if(h==='#ochrana-udaju'||h==='#cookies'||h==='#podminky'||h==='#licence')showLegal(h.slice(1));else{var pn=location.pathname.replace(/\/$/,'');if(pn==='/podminky'||pn==='/ochrana-udaju'||pn==='/cookies'||pn==='/licence')showLegal(pn.slice(1))}}
document.addEventListener('click',function(e){
 var a=e.target.closest('[data-mod]');if(a){e.preventDefault();history.replaceState(null,'','#modul-'+a.dataset.mod);showMod(a.dataset.mod);return}
 var l=e.target.closest('[data-legal]');if(l){history.replaceState(null,'','#'+l.dataset.legal);showLegal(l.dataset.legal);return}
 var lk=e.target.closest('a[href="#ochrana-udaju"]');if(lk){e.preventDefault();history.replaceState(null,'','#ochrana-udaju');showLegal('ochrana-udaju');return}
 var p=e.target.closest('[data-early]');if(p){e.preventDefault();showAuth('signup');if($('#aPlan')){$('#aPlan').value=p.dataset.early||'start';planTxt()}}});
document.addEventListener('click',function(e){var b=e.target.closest('[data-bill]');if(!b)return;var y=b.dataset.bill==='y';[].forEach.call(document.querySelectorAll('[data-bill]'),function(x){x.setAttribute('aria-pressed',x===b)});[].forEach.call(document.querySelectorAll('.pp[data-m]'),function(el){el.textContent=(y?el.dataset.y:el.dataset.m)+' Kč'});[].forEach.call(document.querySelectorAll('.pn[data-m]'),function(el){el.textContent=y?el.dataset.y:el.dataset.m})});
window.addEventListener('hashchange',route);setTimeout(route,0);
document.addEventListener('DOMContentLoaded',function(){if(VX_ED==='local'){LOCAL=true;document.documentElement.classList.add('vxlocal');try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist()}catch(e){}startDemo()}});
if(location.pathname.replace(/\/$/,'')==='/cenik')setTimeout(function(){var c=document.getElementById('cenik');if(c)c.scrollIntoView()},400);

/* formulář */
var form=$('#form'),st=$('#st'),sendB=$('#send'),loadT=Date.now();
function msg(t,c){st.className='st '+c;st.textContent=t}
var custom=false;
function setMode(c){if(typeof c!=='boolean')c=custom;custom=c;var aw=document.getElementById('fAgeW');if(aw)aw.hidden=c;sendB.textContent=c?'Odeslat poptávku':'Odebírat novinky';[].forEach.call(document.querySelectorAll('[data-fmode]'),function(b){b.setAttribute('aria-pressed',String((b.dataset.fmode==='custom')===c))});[].forEach.call(document.querySelectorAll('#form [data-cu]'),function(x){x.hidden=!c});$('#fPlan').value=c?'Systém na míru (od 20 000 Kč)':'';$('#fNameL').textContent=c?'Jméno *':'Jméno (nepovinné)';$('#fName').required=c;$('#fPurpose').textContent=c?'Popište, co potřebujete. Údaje použijeme jen k odpovědi na poptávku a nezapíšeme vás k odběru novinek.':'Stačí e-mail. Pošleme vám jen informace o vývoji Vexaronetu a odhlásit se můžete kdykoli.';$('#fOkT').innerHTML=c?'Souhlasím se zpracováním údajů za účelem vyřízení poptávky. <a href="/ochrana-udaju/" target="_blank" rel="noopener">Zásady ochrany osobních údajů</a> <i aria-hidden="true">*</i>':'Souhlasím, že mi Vexaronet bude na uvedený e-mail posílat novinky o vývoji. Souhlas mohu kdykoli odvolat. <a href="/ochrana-udaju/" target="_blank" rel="noopener">Zásady ochrany osobních údajů</a> <i aria-hidden="true">*</i>'}
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-fmode]');if(b){setMode(b.dataset.fmode==='custom')}});
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-namiru]');if(!b)return;e.preventDefault();setMode(true);if(b.dataset.namiru==='code'){var pl=$('#fPlan');if(pl)pl.value='Zdrojový kód Vexaronet (zdarma)';var mm=$('#fMsg');if(mm&&!mm.value)mm.value='Mám zájem o zdrojový kód Vexaronet. Prosím o informace o licenčních podmínkách a podpoře.'}else if(b.dataset.namiru==='online'){var pl2=$('#fPlan');if(pl2)pl2.value='Vexaronet online (předplatné, cena zatím neurčena)';var m2=$('#fMsg');if(m2&&!m2.value)m2.value='Mám zájem o Vexaronet online jako předplatné. Dejte mi prosím vědět, až bude znám start, cena a podmínky.'}else if(b.dataset.namiru==='start'){var pl3=$('#fPlan');if(pl3)pl3.value='Informace o startu prodeje (kód / online)';var m3=$('#fMsg');if(m3&&!m3.value)m3.value='Dejte mi prosím vědět o startu prodeje Vexaronetu. Zajímá mě: zdrojový kód / online předplatné (nehodící se škrtněte).'}$('#early').scrollIntoView({behavior:'smooth'});setTimeout(function(){var m=$('#fMsg');if(m)m.focus({preventScroll:true})},700)});
form.addEventListener('submit',function(e){e.preventDefault();var f=form.elements;
 if(!f.email.value.trim()||(custom&&!f.jmeno.value.trim())){msg(custom?'Vyplňte prosím jméno a e-mail.':'Vyplňte prosím e-mail.','err');(f.email.value.trim()?f.jmeno:f.email).focus();return}
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email.value.trim())){msg('Zkontrolujte prosím formát e-mailu.','err');return}
 if(!f.souhlas.checked){msg('Pro odeslání je nutný souhlas se zpracováním údajů.','err');return}
 if(!custom&&!f.vek.checked){msg('Novinky může odebírat osoba od 15 let (souhlas se zpracováním podle § 7 zák. č. 110/2019 Sb.). Potvrďte prosím věk.','err');return}
 if(f['bot-field'].value||Date.now()-loadT<2500){msg('Odeslání se nepodařilo ověřit. Zkuste to prosím znovu.','err');return}
 sendB.disabled=true;sendB.textContent='Odesílám…';st.className='st';
 fetch('/api/subscribe',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({email:f.email.value.trim(),name:f.jmeno.value.trim()||'(neuvedeno)',company:f.firma.value.trim(),business_type:f.obor.value,interested_plan:f.tarif.value,message:f.zprava.value.trim(),consent:true,inquiry:custom,hp:f['bot-field'].value})}).then(function(r){if(!r.ok)throw new Error(r.status);return r.json()}).then(function(d){msg((custom?'Děkujeme, poptávku jsme přijali. Ozveme se vám na uvedený e-mail.':(d&&d.duplicate?'Tento e-mail už novinky odebírá. Děkujeme!':'Děkujeme, e-mail jsme uložili. O novinkách vám dáme vědět.')),'ok');form.reset();setMode()}).catch(function(er){msg('Odeslání se teď nepodařilo (chyba '+((er&&er.message)||'síť')+'). Napište nám prosím na info@vexaronet.com.','err')}).then(function(){sendB.disabled=false;setMode()})});


(function(){var f=document.getElementById('dlForm');if(!f)return;var st=document.getElementById('dlSt'),b=document.getElementById('dlGo'),ok=document.getElementById('dlOk'),t0=Date.now();
function m(t,c){st.className='st '+c;st.textContent=t}
f.addEventListener('submit',function(e){e.preventDefault();var x=f.elements,em=x.email.value.trim();
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)){m('Zadejte prosím platný e-mail.','err');x.email.focus();return}
 if(!x.lic.checked){m('Pro stažení je nutný souhlas s licenčními podmínkami.','err');return}
 if(!x.souhlas.checked){m('Pro stažení zdarma je nutný souhlas s odběrem novinek.','err');return}
 if(!x.vek.checked){m('Potvrďte prosím, že je vám alespoň 15 let.','err');return}
 if(x['bot-field'].value||Date.now()-t0<2500){m('Odeslání se nepodařilo ověřit. Zkuste to prosím znovu.','err');return}
 b.disabled=true;b.textContent='Odesílám…';st.className='st';
 fetch('/api/subscribe',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({email:em,name:'(stažení)',interested_plan:'stažení zdarma',consent:true,inquiry:false,hp:x['bot-field'].value})}).then(function(r){if(!r.ok)throw new Error(r.status);return r.json()}).then(function(){
  f.hidden=true;var nt=document.getElementById('dlNote');if(nt)nt.hidden=true;ok.hidden=false;ok.innerHTML='<p class="note"><b>Děkujeme.</b> Odkazy ke stažení:</p><div class="cta"><a class="btn btn-main" href="/stazeni/Vexaronet-lokalni.zip" download>⬇ Aplikace pro počítač (zip)</a><a class="btn btn-ghost" href="/stazeni/Vexaronet-zdrojovy-kod.zip" download>⬇ Zdrojový kód (zip)</a></div><p class="mut fine">Aplikaci rozbalte a otevřete Vexaronet.html. Data zůstávají jen ve vašem počítači, pravidelně si stahujte zálohu.</p>'}).catch(function(er){m('Odeslání se teď nepodařilo (chyba '+((er&&er.message)||'síť')+'). Zkuste to prosím znovu nebo napište na info@vexaronet.com.','err');b.disabled=false;b.textContent='⬇ Zadat e-mail a stáhnout zdarma'})})})();

window.DOC_T=document.title;
/* ===== Supabase: registrace a přihlášení ===== */
var SB_URL=@@CFG_SBURL@@;
var SB_KEY=@@CFG_SBKEY@@;var VX_VERSION=@@VERSION@@,VX_FEED=@@CFG_FEED@@,VX_ED=@@CFG_ED@@,VX_OFF=@@CFG_OFF@@; /* veřejný (publishable) klíč, smí být ve webu */
var PLAN_OPTS=[['start','START – zdarma'],['pro','Vexaronet PRO – 699 Kč / měsíc bez DPH, 30 dní zdarma'],['accountant','AI Účetní – 399 Kč / měsíc bez DPH, 30 dní zdarma'],['business','Vexaronet BUSINESS – 1 199 Kč / měsíc bez DPH, 30 dní zdarma']];
var PLAN_ALLOWED=['start','accountant','pro','business','enterprise'],LEGACY={'VEXARONET PRO':'pro','AI ÚČETNÍ':'accountant','STARTER':'start','PRO':'pro','BUSINESS':'business'};
function planVal(x){x=LEGACY[x]||x;return PLAN_ALLOWED.indexOf(x)>=0?x:'pro'}
var TERMS_VERSION='beta-2026-10-18';
var sb=null;
function getSb(){if(DEMO)return demoSb();if(sb)return sb;if(window.supabase&&window.supabase.createClient){sb=window.supabase.createClient(SB_URL,SB_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}})}return sb}
var accB=$('#acc');
function setAcc(on){accB.textContent=on?'Otevřít účet':'Přihlásit'}
window.addEventListener('load',function(){var c=getSb();if(c)c.auth.getSession().then(function(r){setAcc(!!(r.data&&r.data.session))}).catch(function(){});if(c)c.auth.onAuthStateChange(function(ev,ses){setAcc(!!ses);if(ev==='PASSWORD_RECOVERY')setTimeout(function(){showAuth('newpw')},0)})});
/* Věk při registraci (docs/PRAVNI_SOULAD.md, oblast 1): účet a firmu zakládá zletilá osoba (18+, placené předplatné a podnikání),
   pozvaný zaměstnanec smí být od 15 let (§ 35 obč. zák., výkon závislé práce). Mladším 15 let službu nenabízíme. Souhlas rodiče
   proto nevyžadujeme: nezletilým nenabízíme nic, k čemu by byl potřeba. Ukládá se jen kategorie, ne datum narození. */
var AGE_TXT={owner:'Potvrzuji, že je mi 18 let nebo více.',invited:'Potvrzuji, že je mi alespoň 15 let a mám ukončenou povinnou školní docházku (účet pro práci u zaměstnavatele).',
 noOwner:'Firmu a účet s předplatným může založit jen osoba starší 18 let. Pokud je vám 15 až 17 let a pracujete u firmy, která Vexaronet používá, požádejte ji o pozvánku a zaškrtněte „Jsem pozvaný/á“. Mladším 15 let službu nenabízíme.',
 noInvited:'Pozvaný účet může mít osoba od 15 let s ukončenou povinnou školní docházkou. Mladším 15 let službu nenabízíme.'};
function authForm(mode){
 var plans=PLAN_OPTS.map(function(p){return '<option value="'+p[0]+'">'+p[1]+'</option>'}).join('');
 var biz=Object.keys(BIZ).map(function(b){return '<option>'+esc(b)+'</option>'}).join('');
 var inApp=document.documentElement.classList.contains('appmode');
 var tabs='<div class="bar" role="tablist"><button type="button" class="chipb" data-auth="login" aria-pressed="'+(mode==='login')+'">Přihlášení</button>'+(inApp?'':'<button type="button" class="chipb" data-auth="signup" aria-pressed="'+(mode==='signup')+'">Registrace</button>')+'</div>';
 if(mode==='reset')return '<span class="eyebrow">Účet</span><h2 id="dT">Obnovení hesla</h2><p>Zadejte e-mail a pošleme vám odkaz pro nastavení nového hesla.</p><form id="authForm" novalidate><div class="fg"><div class="f full"><label for="aMail">E-mail <i aria-hidden="true">*</i></label><input id="aMail" type="email" autocomplete="email" inputmode="email" required aria-required="true"></div><div class="f full"><button class="btn btn-main" type="submit" id="aGo">Poslat odkaz</button> <button class="btn btn-ghost" type="button" data-auth="login">Zpět na přihlášení</button></div></div><div class="st" id="aSt" role="status" aria-live="polite"></div></form>';
 if(mode==='newpw')return '<span class="eyebrow">Účet</span><h2 id="dT">Nové heslo</h2><form id="authForm" novalidate><div class="fg"><div class="f full"><label for="aPw">Nové heslo (alespoň 8 znaků) <i aria-hidden="true">*</i></label><input id="aPw" type="password" autocomplete="new-password" minlength="8" required aria-required="true"></div><div class="f full"><button class="btn btn-main" type="submit" id="aGo">Uložit heslo</button></div></div><div class="st" id="aSt" role="status" aria-live="polite"></div></form>';
 return '<span class="eyebrow">Účet</span><h2 id="dT">'+(mode==='login'?'Přihlášení':'Založit účet')+'</h2>'+tabs
 +'<form id="authForm" novalidate><div class="fg">'
 +(mode==='signup'?'<p class="mut fine full" style="grid-column:1/-1">K založení účtu stačí jméno, e-mail a heslo. Firmu, obor a další věci můžete nastavit později v aplikaci.</p><div class="f"><label for="aName">Jméno a příjmení <i aria-hidden="true">*</i></label><input id="aName" autocomplete="name" required aria-required="true"></div><div class="f"><label for="aCo">Název firmy (nepovinné)</label><input id="aCo" autocomplete="organization" placeholder="Když nevyplníte, použije se vaše jméno"></div><div class="f full"><label class="chk"><input type="checkbox" id="aInv"><span>Jsem pozvaný/á do firmy svého zaměstnavatele (firmu zakládat nechci). Registruji se e-mailem, na který pozvánka přišla.</span></label></div>':'')
 +'<div class="f '+(mode==='login'?'full':'')+'"><label for="aMail">E-mail <i aria-hidden="true">*</i></label><input id="aMail" type="email" autocomplete="email" inputmode="email" required aria-required="true"></div>'
 +'<div class="f '+(mode==='login'?'full':'')+'"><label for="aPw">Heslo'+(mode==='signup'?' (alespoň 8 znaků)':'')+' <i aria-hidden="true">*</i></label><input id="aPw" type="password" autocomplete="'+(mode==='login'?'current-password':'new-password')+'" minlength="8" required aria-required="true"></div>'
 +(mode==='signup'?'<div class="f full"><p id="aPlanTxt" class="plantxt" role="note"></p><details class="moreset"><summary>Tarif, obor a země (nepovinné)</summary><div class="fg"><div class="f full"><label for="aPlan">Tarif</label><select id="aPlan">'+plans+'</select></div><div class="f"><label for="aBiz">Obor podnikání</label><select id="aBiz"><option value="">Vyberu později</option>'+biz+'</select></div><div class="f"><label for="aCt">Stát</label><select id="aCt"><option>Česko</option><option>Slovensko</option><option>Jiná země</option></select></div></div></details></div>'
 +'<div class="f full"><label class="chk"><input type="checkbox" id="aAge" required aria-required="true"><span id="aAgeT">'+AGE_TXT.owner+' <i aria-hidden="true">*</i></span></label><p class="mut fine" id="aAgeH">Ptáme se jen na potvrzení věkové hranice, datum narození ani doklad neukládáme.</p></div>'
 +'<div class="f full"><label class="chk"><input type="checkbox" id="aOk" required aria-required="true"><span>Souhlasím s <a href="/podminky/" data-legal-link="podminky" target="_blank" rel="noopener">obchodními podmínkami</a>. Informace o zpracování osobních údajů najdete v <a href="/ochrana-udaju/" data-legal-link="ochrana-udaju" target="_blank" rel="noopener">zásadách ochrany osobních údajů</a>. <i aria-hidden="true">*</i></span></label></div>':'')
 +'<div class="f full"><button class="btn btn-main" type="submit" id="aGo">'+(mode==='login'?'Přihlásit se':'Založit účet zdarma')+'</button>'+(mode==='login'?' <button class="btn btn-ghost" type="button" data-auth="reset">Zapomenuté heslo</button>':'')+'</div></div><div class="st" id="aSt" role="status" aria-live="polite"></div></form>';
}
function planTxt(){var p=$('#aPlan'),t=$('#aPlanTxt'),g=$('#aGo');if(!p||!t)return;var k=p.value,nm=(PLAN_OPTS.filter(function(x){return x[0]===k})[0]||[k,k])[1];
 if(k==='start'){t.innerHTML='<b>Tarif START je zdarma</b> bez časového omezení a bez platební karty.';g.textContent='Založit účet zdarma'}
 else{t.innerHTML='<b>Zvolený tarif: '+esc(nm)+'.</b> Vyzkoušíte ho 30 dní zdarma bez platební karty. Platby zatím nejsou spuštěné, nic se neúčtuje. Po zkušební době se účet vrátí na tarif START (data zůstanou). Roční platbu zatím nelze sjednat.';g.textContent='Založit účet a vyzkoušet 30 dní zdarma'}}
var FEATS_SU=[['zakaznici','Zákazníci (CRM)'],['zakazky','Zakázky a úkoly'],['kalendar','Kalendář a rezervace'],['faktury','Faktury a finance'],['ai','AI poradce'],['zamestnanci','Zaměstnanci'],['weby','Jednoduchý web'],['marketing','Marketing'],['automatizace','Automatizace']];
function showAuth(mode){if(document.documentElement.classList.contains('appmode')&&mode==='signup')mode='login';openD(authForm(mode||'login'));if(mode==='signup')planTxt()}
document.addEventListener('change',function(e){if(e.target&&e.target.name==='pl'&&e.target.closest('#planForm')){var g=document.getElementById('plGo');if(g)g.textContent=e.target.value==='start'?'Přejít na START (zdarma)':'Odeslat nezávaznou žádost'}if(e.target&&e.target.id==='aPlan')planTxt();if(e.target&&e.target.id==='aInv'){var t=document.getElementById('aAgeT'),a=document.getElementById('aAge');if(t)t.innerHTML=esc(e.target.checked?AGE_TXT.invited:AGE_TXT.owner)+' <i aria-hidden="true">*</i>';if(a)a.checked=false}});
function aMsg(t,c){var e=$('#aSt');if(e){e.className='st '+c;e.textContent=t}}
function niceErr(e){var m=(e&&e.message)||String(e);if(/registration_closed/.test(m))return 'Všech 10 míst pro testovací firmy je obsazeno, zakládání nových firem je do spuštění uzavřené. Pokud vás pozval zaměstnavatel, přihlaste se e-mailem, na který přišla pozvánka.';if(/check constraint|violates/i.test(m))return 'Vybraný tarif zatím není v databázi povolený. Napište na info@vexaronet.com.';if(/Invalid login/i.test(m))return 'Nesprávný e-mail nebo heslo.';if(/already registered|already been/i.test(m))return 'Tento e-mail už je zaregistrovaný. Přihlaste se.';if(/Email not confirmed/i.test(m))return 'E-mail zatím není potvrzený. Klikněte na odkaz v e-mailu, který jsme poslali.';if(/rate limit/i.test(m))return 'Příliš mnoho pokusů. Zkuste to později.';return 'Chyba: '+m}
async function ensureCompany(c,user){
 var r=await c.from('company_members').select('company_id,role,companies(id,name,parent_company_id,created_at)').eq('user_id',user.id);
 if(r.error)r=await c.from('company_members').select('company_id,role').eq('user_id',user.id);
 if(r.error)throw r.error;
 if(r.data&&r.data.length){APP.mships=r.data;var stc=null;try{stc=localStorage.getItem('vx_active_company_'+user.id)}catch(x){}return VXPCORE.pickCompany(r.data,stc)}
 try{var ai=await c.rpc('accept_company_invites');if(!ai.error&&ai.data>0){var r3=await c.from('company_members').select('company_id').eq('user_id',user.id).limit(1);if(r3.data&&r3.data.length)return r3.data[0].company_id}}catch(x){}
 var md=user.user_metadata||{};if(!md.company_name)return null;
 var a=await c.rpc('record_registration_acceptance',{version:TERMS_VERSION,accepted:true});if(a.error)throw a.error;
 var k=await c.rpc('create_company_for_plan',{company_name:md.company_name,company_industry:md.industry||'',selected_plan:planVal(md.plan)});
 if(k.error)throw k.error;
 var r2=await c.from('company_members').select('company_id').eq('user_id',user.id).limit(1);
 return r2.data&&r2.data[0]?r2.data[0].company_id:(typeof k.data==='string'?k.data:null)}
function kv(o){if(o==null)return '<p>Žádná data.</p>';if(typeof o!=='object')return '<p>'+esc(o)+'</p>';var rows=Array.isArray(o)?o.map(function(x,i){return [i+1,x]}):Object.keys(o).map(function(k){return [k,o[k]]});return '<ul class="ticks">'+rows.map(function(r){var v=r[1];return '<li><b>'+esc(r[0])+':</b> '+esc(typeof v==='object'?JSON.stringify(v):v)+'</li>'}).join('')+'</ul>'}
async function showAccount(){
 var c=getSb();openD('<span class="eyebrow">Účet</span><h2 id="dT">Můj účet</h2><p>Načítám…</p>');
 try{
  var u=(await c.auth.getUser()).data.user;if(!u){showAuth('login');return}
  var cid=await ensureCompany(c,u);var h='<span class="eyebrow">Účet</span><h2 id="dT">Můj účet</h2><p>'+esc(u.email)+'</p>';
  if(!cid){h+='<div class="draft">K účtu zatím není přiřazená žádná firma.</div>'}
  else{
   var co=await c.from('companies').select('name,industry').eq('id',cid).limit(1);
   var sub=await c.from('subscriptions').select('plan,status,trial_end,paid_until').eq('company_id',cid).limit(1);
   if(co.data&&co.data[0])h+='<h3>Firma</h3><p>'+esc(co.data[0].name)+(co.data[0].industry?' ('+esc(co.data[0].industry)+')':'')+'</p>';
   if(sub.data&&sub.data[0]){var s=sub.data[0],left='';if(s.trial_end){var d=Math.ceil((new Date(s.trial_end)-new Date())/864e5);left=d>0?'Zbývá '+d+' dní zkušebního období.':'Zkušební období skončilo.'}h+='<h3>Předplatné</h3><p>Tarif: '+esc(s.plan)+', stav: '+esc(s.status)+'. '+left+'</p>'}
   var ds=await c.rpc('dashboard_summary',{cid:cid});
   h+='<h3>Přehled firmy (data z databáze)</h3>'+(ds.error?'<p>Přehled se nepodařilo načíst: '+esc(ds.error.message)+'</p>':kv(ds.data));
  }
  h+='<div class="dact"><button class="btn btn-main" type="button" id="openApp">Otevřít aplikaci</button><button class="btn btn-ghost" type="button" id="logout">Odhlásit se</button></div>';
  dB.innerHTML='<button class="dx" type="button" aria-label="Zavřít">×</button>'+h;
 }catch(e){dB.innerHTML='<button class="dx" type="button" aria-label="Zavřít">×</button><span class="eyebrow">Účet</span><h2 id="dT">Můj účet</h2><div class="draft">'+esc(niceErr(e))+'</div><div class="dact"><button class="btn btn-ghost" type="button" id="logout">Odhlásit se</button></div>'}}
accB.addEventListener('click',async function(){var c=getSb();if(!c){showAuth('login');setTimeout(function(){aMsg('Přihlášení se nepodařilo načíst. Zkontrolujte připojení.','err')},50);return}var r=await c.auth.getSession();if(r.data&&r.data.session)openApp();else showAuth('login')});
$('#mnav').addEventListener('click',function(e){if(e.target.getAttribute('href')==='#prihlaseni'){e.preventDefault();menu(false);var c=getSb();if(c)c.auth.getSession().then(function(r){if(r.data&&r.data.session)openApp();else showAuth('login')});else showAuth('login')}});
document.addEventListener('click',async function(e){
 var t=e.target.closest('[data-auth]');if(t){showAuth(t.dataset.auth);return}
 if(e.target.closest('#logout')){var c=getSb();if(c)await c.auth.signOut();closeDlg()}});
document.addEventListener('submit',async function(e){
 if(e.target.id!=='authForm')return;e.preventDefault();var c=getSb();
 if(!c){aMsg('Služba přihlášení není dostupná. Zkuste to později.','err');return}
 var signup=!!$('#aName'),reset=!$('#aPw'),newpw=!$('#aMail'),mail=newpw?'':$('#aMail').value.trim(),pw=reset?'':$('#aPw').value,b=$('#aGo');
 if(!newpw&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail)){aMsg('Zkontrolujte formát e-mailu.','err');return}
 if(!reset&&pw.length<8){aMsg('Heslo musí mít alespoň 8 znaků.','err');return}
 if(signup&&!$('#aName').value.trim()){aMsg('Vyplňte jméno a příjmení.','err');return}
 if(signup&&!$('#aAge').checked){aMsg($('#aInv').checked?AGE_TXT.noInvited:AGE_TXT.noOwner,'err');$('#aAge').focus();return}
 if(signup&&!$('#aOk').checked){aMsg('Pro registraci potvrďte souhlas s obchodními podmínkami.','err');$('#aOk').focus();return}
 b.disabled=true;aMsg('Zpracovávám…','ok');
 try{
  if(reset){var rr=await c.auth.resetPasswordForEmail(mail,{redirectTo:location.origin+'/'});if(rr.error)throw rr.error;aMsg('Pokud je e-mail zaregistrovaný, poslali jsme na něj odkaz pro nové heslo.','ok')}
  else if(newpw){var up=await c.auth.updateUser({password:pw});if(up.error)throw up.error;history.replaceState(null,'',location.pathname);await openApp()}
  else if(signup){
   var ft=[].map.call(document.querySelectorAll('input[name=aFt]:checked'),function(x){return x.value});
   var r=await c.auth.signUp({email:mail,password:pw,options:{emailRedirectTo:location.origin+'/',data:{full_name:$('#aName').value.trim(),company_name:$('#aInv').checked?'':($('#aCo').value.trim()||$('#aName').value.trim()),invited:$('#aInv').checked,age_group:$('#aInv').checked?'15+':'18+',age_confirmed_at:new Date().toISOString(),industry:$('#aBiz').value,plan:$('#aPlan').value,country:$('#aCt').value,features:ft,onboarded:true,terms_accepted_at:new Date().toISOString()}}});
   if(r.error)throw r.error;
   if(r.data&&r.data.session){await openApp()}else{aMsg('Účet je vytvořený. Poslali jsme vám e-mail, potvrďte ho a pak se přihlaste.'+($('#aPlan').value==='start'?'':' 30denní zkušební období začne po prvním přihlášení.'),'ok')}
  }else{
   var l=await c.auth.signInWithPassword({email:mail,password:pw});if(l.error)throw l.error;await openApp()}
 }catch(err){aMsg(niceErr(err),'err')}
 b.disabled=false});

/* ===== Aplikace po přihlášení ===== */
var APP={cid:null,co:'',ind:'',tab:'prehled',user:null,meta:{},role:null,sub:null,d:null,chat:[],busy:false};
var FEATS=[['zakaznici','Zákazníci (CRM)'],['zakazky','Zakázky a úkoly'],['kalendar','Kalendář a rezervace'],['faktury','Faktury a finance'],['ai','AI CEO'],['zamestnanci','Zaměstnanci'],['weby','Jednoduchý web'],['marketing','Marketing'],['automatizace','Automatizace']];
@@EU@@
var COUNTRIES=['Česko','Slovensko'].concat(VXEU.list().map(function(x){return x.name}).filter(function(n){return n!=='Česko'&&n!=='Slovensko'}),['Jiná země']);
var IC={eshop:'M3 4h2l2 11h11l2-8H6M9 20a1 1 0 100-2 1 1 0 000 2zM17 20a1 1 0 100-2 1 1 0 000 2z',fb:'M4 5h16v11H9l-5 4zM8 9h8M8 12h5',online:'M12 3a9 9 0 100 18 9 9 0 000-18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18',prehled:'M3 12l9-8 9 8M5 10v10h5v-6h4v6h5V10',zakaznici:'M16 11a4 4 0 10-8 0 4 4 0 008 0zM4 21c0-4 4-6 8-6s8 2 8 6',zakazky:'M4 7h16v13H4zM9 7V4h6v3',kalendar:'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4',ukoly:'M5 12l4 4 10-10',faktury:'M6 3h9l4 4v14H6zM9 12h7M9 16h7',ceo:'M12 3l2 5 5 2-5 2-2 5-2-5-5-2 5-2z',ucetni:'M6 3h12v18H6zM9 7h6M9 11h6M9 15h3',zamestnanci:'M8 11a3 3 0 100-6 3 3 0 000 6zM16 12a3 3 0 100-6M2 20c0-3 3-5 6-5s6 2 6 5M16 15c3 0 6 1 6 5',weby:'M3 5h18v14H3zM3 9h18',marketing:'M4 14V10l12-5v14zM16 9a3 3 0 010 6',automatizace:'M13 2L4 14h7l-1 8 9-12h-7z',sklad:'M3 8l9-5 9 5v10l-9 5-9-5zM3 8l9 5 9-5',pobocky:'M12 21s7-6 7-11a7 7 0 10-14 0c0 5 7 11 7 11zM12 12a2.5 2.5 0 100-5 2.5 2.5 0 000 5z',finance:'M4 19V9M10 19V5M16 19v-7M22 19H2',reporty:'M5 20V10M12 20V4M19 20v-8',profil:'M12 15a3 3 0 100-6 3 3 0 000 6zM19 12l2-1-2-4-2 1-2-1V5h-4v2l-2 1-2-1-2 4 2 1v2l-2 1 2 4 2-1 2 1v2h4v-2l2-1 2 1 2-4-2-1z',bell:'M6 17V11a6 6 0 1112 0v6l2 2H4zM10 21h4',menu:'M4 6h16M4 12h16M4 18h16',sun:'M12 8a4 4 0 100 8 4 4 0 000-8zM12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5',plus:'M12 5v14M5 12h14',search:'M11 18a7 7 0 100-14 7 7 0 000 14zM21 21l-5-5',send:'M3 11l18-8-8 18-2-8z',warn:'M12 4l9 16H3zM12 10v4M12 17v1',tr:'M4 17l6-6 4 4 6-8'};
function ico(k,s){return '<svg viewBox="0 0 24 24" width="'+(s||20)+'" height="'+(s||20)+'" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="'+IC[k]+'"/></svg>'}

/* ===== Profily oborů: aplikace se po registraci přizpůsobí oboru ===== */
var OB={
'Autoservis':{
 nav:['prehled','zakazky','kalendar','online','zakaznici','sklad','eshop','faktury','zamestnanci','ukoly','finance','reporty','ceo'],
 lab:{zakazky:'Servisní zakázky',zakaznici:'Zákazníci a vozidla',sklad:'Sklad dílů',zamestnanci:'Mechanici a docházka',online:'Online objednání'},
 jobNew:'Nová servisní zakázka',jobAct:'Aktivní servisní zakázky',
 statuses:['Přijato','Diagnostika','Čeká na díly','V opravě','Hotovo'],
 tpl:'Vozidlo (značka, model):\nSPZ:\nNajeto (km):\nZávada nebo požadovaná práce:\nPoužité díly:',
 svc:[['Prohlídka vozu',30],['Výměna oleje a filtrů',60],['Přezutí pneumatik',45],['Diagnostika závad',90],['Příprava na STK',60]],
 steps:[['Přidejte zákazníky (SPZ vozidla pište do poznámky)','zakaznici','cust'],['Založte první servisní zakázku','zakazky','jobs'],['Nastavte online objednání a služby','online','svc'],['Zadejte díly do skladu a minimální množství','sklad','prod'],['Pozvěte mechaniky a zapněte docházku','zamestnanci','team'],['Vystavte první fakturu za práci a díly','faktury','inv']],
 q:[['Sezóna přezouvání','Navrhni, jak oslovit zákazníky autoservisu před sezónou přezouvání pneumatik.'],['Zkontrolovat servisní zakázky','Zkontroluj stav zakázek a termínů a řekni, co hoří.'],['Připomenout STK a servis','Napiš krátkou zprávu pro zákazníky autoservisu, kterým se blíží STK nebo pravidelný servis.'],['Přehled financí','Připrav stručný přehled financí mé firmy podle čísel.'],['Získat nové zákazníky','Navrhni 3 způsoby, jak získat nové zákazníky pro autoservis.']],
 ai:'Autoservis: servisní zakázky se stavy, vozidla (SPZ), online rezervace termínů, sklad dílů pod minimem, sezónní přezouvání, faktury za práci a díly, hodiny mechaniků.'},
'Řemeslník':{
 nav:['prehled','zakazky','zakaznici','kalendar','sklad','eshop','faktury','zamestnanci','ukoly','finance','reporty','ceo','online'],
 lab:{zakazky:'Zakázky a projekty',sklad:'Materiál',zamestnanci:'Pracovníci a hodiny',kalendar:'Kalendář výjezdů',online:'Online objednání'},
 jobNew:'Nová zakázka',jobAct:'Aktivní zakázky',
 statuses:['Poptávka','Nabídka odeslána','Schváleno','Realizace','Hotovo'],
 tpl:'Místo realizace (adresa):\nRozsah prací:\nMateriál:\nDohodnutá cena a záloha:\nTermín zahájení:',
 svc:[['Zaměření a konzultace na místě',60],['Prohlídka před nabídkou',45],['Havarijní výjezd',90]],
 steps:[['Přidejte zákazníky s kontakty a adresou','zakaznici','cust'],['Založte první zakázku se stavem a cenou','zakazky','jobs'],['Naplánujte výjezdy v kalendáři','kalendar','cal'],['Zadejte materiál do skladu a minimální množství','sklad','prod'],['Pozvěte pracovníky a zapněte docházku s hodinami','zamestnanci','team'],['Vystavte fakturu nebo zálohu','faktury','inv']],
 q:[['Připravit cenovou nabídku','Pomoz mi připravit přehlednou cenovou nabídku pro zákazníka na zakázku řemeslné firmy.'],['Zkontrolovat zakázky','Zkontroluj stav zakázek a termínů a řekni, co hoří.'],['Neuhrazené faktury a zálohy','Přehledně shrň neuhrazené faktury a navrhni, koho urgovat.'],['Přehled financí','Připrav stručný přehled financí mé firmy podle čísel.'],['Získat nové zakázky','Navrhni 3 způsoby, jak získat nové zakázky pro řemeslnou firmu.']],
 ai:'Řemeslník: zakázky/projekty se stavy (poptávka, nabídka, realizace), kalendář výjezdů, materiál na skladě, zálohy a faktury, hodiny pracovníků.'},
'Restaurace':{
 nav:['prehled','kalendar','online','sklad','zamestnanci','zakazky','zakaznici','finance','faktury','ukoly','reporty','ceo'],
 lab:{kalendar:'Rezervace a směny',online:'Rezervace stolů online',sklad:'Sklad surovin',zamestnanci:'Personál a směny',zakazky:'Akce a objednávky',zakaznici:'Hosté a firmy'},
 jobNew:'Nová akce nebo objednávka',jobAct:'Aktivní akce a objednávky',
 statuses:['Nová','Potvrzeno','Připravuje se','Hotovo'],
 tpl:'Typ akce (oslava, firemní akce, catering):\nPočet osob:\nMenu a požadavky:\nAlergeny a poznámky:',
 svc:[['Rezervace stolu pro 2 osoby',90],['Rezervace stolu pro 4 osoby',120],['Rezervace stolu pro 6 a více osob',150],['Oslava nebo firemní akce',180]],
 steps:[['Nastavte rezervace stolů online (otevírací doba a kapacita)','online','svc'],['Zadejte suroviny do skladu a minimální množství','sklad','prod'],['Pozvěte personál a vyznačte směny','zamestnanci','team'],['Založte první akci nebo objednávku (oslavy, catering)','zakazky','jobs'],['Přidejte stálé hosty a firmy','zakaznici','cust'],['Vystavte první fakturu (např. za firemní akci)','faktury','inv']],
 q:[['Naplnit prázdné dny','Navrhni, jak naplnit rezervacemi méně vytížené dny v restauraci.'],['Hlídat suroviny a náklady','Navrhni, jak hlídat náklady na suroviny a snížit plýtvání v restauraci.'],['Plánování směn','Poraď, jak jednoduše naplánovat směny personálu podle vytížení.'],['Přehled financí','Připrav stručný přehled financí mé firmy podle čísel.'],['Marketing pro restauraci','Doporuč jednoduchou marketingovou kampaň pro restauraci.']],
 ai:'Restaurace: rezervace stolů (kapacita), sklad surovin pod minimem, personál a směny s docházkou, firemní akce a catering jako zakázky, provozní příjmy a výdaje.'},
'Služby':{
 nav:['prehled','zakaznici','zakazky','ukoly','kalendar','online','faktury','finance','reporty','zamestnanci','ceo'],
 lab:{zakazky:'Projekty a zakázky',kalendar:'Kalendář schůzek',online:'Online schůzky',zamestnanci:'Tým a hodiny'},
 jobNew:'Nový projekt',jobAct:'Aktivní projekty',
 statuses:['Poptávka','Nabídka','Probíhá','Ke schválení','Hotovo'],
 tpl:'Zadání:\nVýstup a termín:\nRozsah (hodiny nebo paušál):\nKontaktní osoba:',
 svc:[['Úvodní konzultace zdarma',30],['Konzultace',60],['Workshop nebo školení',120]],
 steps:[['Přidejte klienty a kontakty','zakaznici','cust'],['Založte první projekt a rozdělte práci na úkoly','zakazky','jobs'],['Nastavte online objednání schůzek','online','svc'],['Pozvěte kolegy a zapněte evidenci hodin','zamestnanci','team'],['Vystavte první fakturu','faktury','inv']],
 q:[['Shrnout rozpracované projekty','Shrň rozpracované zakázky a řekni, co je potřeba dotáhnout.'],['Neuhrazené faktury','Přehledně shrň neuhrazené faktury a navrhni, koho urgovat.'],['Napsat nabídku','Připrav krátkou obchodní nabídku pro stávající klienty mé firmy.'],['Přehled financí','Připrav stručný přehled financí mé firmy podle čísel.'],['Získat nové klienty','Navrhni 3 způsoby, jak získat nové klienty pro firmu poskytující služby.']],
 ai:'Služby (poradenství, agentury, freelanceři): projekty se stavy, úkoly, schůzky v kalendáři, faktury a hlídání plateb, evidence hodin týmu.'},
'Kadeřnictví a krása':{
 nav:['prehled','kalendar','online','zakaznici','zamestnanci','sklad','eshop','faktury','finance','marketing','ukoly','reporty','ceo','pobocky','zakazky'],
 lab:{kalendar:'Kalendář a rezervace',online:'Online rezervace',zakaznici:'Klienti',zamestnanci:'Tým a směny',sklad:'Produkty a sklad',pobocky:'Provozovny'},
 jobNew:'Nová objednávka',jobAct:'Aktivní objednávky',
 statuses:['Objednáno','Potvrzeno','Hotovo'],
 tpl:'Služba:\nPoznámka ke klientovi (preference, alergie, barva):',
 svc:[['Dámský střih',60],['Pánský střih',30],['Barvení',120],['Úprava vousů',30],['Manikúra',60]],
 steps:[['Nastavte online rezervace: otevírací dobu a služby','online','svc'],['Přidejte klienty a poznámky k nim','zakaznici','cust'],['Vyznačte směny členů týmu','zamestnanci','team'],['Zadejte produkty k prodeji do skladu','sklad','prod'],['Vystavte první fakturu','faktury','inv']],
 q:[['Naplnit prázdné termíny','Navrhni, jak naplnit prázdné termíny v kadeřnictví nebo salonu krásy.'],['Vrátit zapomenuté klienty','Napiš krátkou zprávu pro klienty, kteří nebyli v salonu několik měsíců.'],['Slevový kód nebo akce','Navrhni jednoduchou slevovou akci pro salon, která nezničí marži.'],['Přehled financí','Připrav stručný přehled financí mé firmy podle čísel.'],['Marketing pro salon','Doporuč jednoduchou marketingovou kampaň pro salon.']],
 ai:'Kadeřnictví a krása: online rezervace klientů, kalendář a směny týmu, klienti s poznámkami, prodej produktů ze skladu, marketing (slevy), případně více provozoven.'},
'Obchod':{
 nav:['prehled','sklad','eshop','zakazky','zakaznici','faktury','finance','marketing','zamestnanci','pobocky','ukoly','reporty','ceo','kalendar','online'],
 lab:{sklad:'Zboží a sklad',zakazky:'Objednávky',pobocky:'Prodejny',zamestnanci:'Prodavači a směny'},
 jobNew:'Nová objednávka',jobAct:'Aktivní objednávky',
 statuses:['Nová','Připravuje se','Odesláno','Hotovo'],
 tpl:'Zboží:\nZpůsob dodání (osobně nebo doprava):\nPoznámka:',
 svc:[['Vyzvednutí objednávky v prodejně',15],['Konzultace k výběru zboží',30]],
 steps:[['Zadejte zboží do skladu a minimální množství','sklad','prod'],['Přidejte stálé zákazníky','zakaznici','cust'],['Evidujte první objednávku','zakazky','jobs'],['Vystavte první fakturu','faktury','inv'],['Zapněte e-shop (PRO) a zobrazte zboží veřejně','eshop','shop'],['Vyznačte směny prodavačů','zamestnanci','team']],
 q:[['Co dochází na skladě','Zkontroluj, jaké zboží dochází, a navrhni, co dokoupit.'],['Slevová akce','Navrhni jednoduchou slevovou akci pro obchod, která nezničí marži.'],['Neuhrazené faktury','Přehledně shrň neuhrazené faktury a navrhni, koho urgovat.'],['Přehled financí','Připrav stručný přehled financí mé firmy podle čísel.'],['Získat nové zákazníky','Navrhni 3 způsoby, jak získat nové zákazníky pro obchod.']],
 ai:'Obchod: zboží a sklad pod minimem, objednávky se stavy, zákazníci a faktury, slevové kódy a marketing, případně více prodejen a směny prodavačů.'},
'Jiný obor':{
 nav:null,lab:{},jobNew:'Nová zakázka',jobAct:'Aktivní zakázky',statuses:['Nová','Probíhá','Hotovo'],tpl:'',svc:[['Konzultace',30],['Schůzka',60]],
 steps:[['Přidejte první zákazníky','zakaznici','cust'],['Založte první zakázku','zakazky','jobs'],['Naplánujte termín v kalendáři','kalendar','cal'],['Vystavte první fakturu','faktury','inv']],
 q:null,ai:''}
};
function obKey(x){var t=String(x||'').toLowerCase();if(!t)return 'Jiný obor';if(OB[x])return x;if(/auto|servis|pneu|mechanik/.test(t))return 'Autoservis';if(/řemesl|remesl|stav|instal|truhl|elektr|maliř|zedn|opravy/.test(t))return 'Řemeslník';if(/restaur|kavár|kavar|gastro|hospod|bar\b|bistro|cukrár/.test(t))return 'Restaurace';if(/kadeř|kader|krás|kras|kosmet|barber|salon|masáž|masaz|nehty/.test(t))return 'Kadeřnictví a krása';if(/obchod|shop|prodej|e-shop|eshop|prodejna/.test(t))return 'Obchod';if(/služb|sluzb|poraden|agentur|freelanc|konzult/.test(t))return 'Služby';return 'Jiný obor'}
function prof(){return OB[obKey(APP.ind)]||OB['Jiný obor']}
function tabLab(k){var P=prof();return (P.lab&&P.lab[k])||((NAV.filter(function(n){return n[0]===k})[0]||[0,k])[1])}
function jobNewL(){return prof().jobNew||'Nová zakázka'}
function jobActL(){return prof().jobAct||'Aktivní zakázky'}
function navBtn(k){return '<button type="button" data-tab="'+k+'">'+ico(k)+'<span>'+esc(tabLab(k))+'</span></button>'}
var APGRP=['aitym','autopilot','marketing','ceo','ucetni','weby','automatizace'];
function apGroupHtml(){if(APP.role==='employee')return '';var open=APD.menu===null?(APGRP.concat(['pripady','nabidky']).indexOf(APP.tab)>=0):APD.menu,
 it=[['aitym','AI tým (přehled)','autopilot'],['autopilot','AI Marketing','marketing'],['pripady','AI Obchodník','zakaznici'],['ceo','AI CEO','ceo'],['ucetni','AI Účetnictví','ucetni'],['weby','AI Weby a e-shopy','weby'],['automatizace','AI Automatizace','automatizace']];
 it=it.filter(function(x){return !off(x[0])});if(!it.filter(function(x){return x[0]!=='pripady'}).length)return '';
 return '<div class="apg'+(open?' vxd-open':'')+'"><button type="button" class="vxd-hdr" data-apgrp="1" aria-expanded="'+(open?'true':'false')+'">'+ico('autopilot',20)+'<span>AI Autopilot</span><span class="vxd-chv">'+ico('chev',16)+'</span></button><div class="vxd-sub">'+it.map(function(x){return '<button type="button" data-tab="'+x[0]+'">'+ico(x[2],16)+'<span>'+x[1]+'</span></button>'}).join('')+'</div></div>'}
function navHtml(){var all=NAV.map(function(n){return n[0]}).filter(function(k){return APGRP.indexOf(k)<0&&!off(k)}),P=prof(),ord=P.nav?P.nav.filter(function(k){return all.indexOf(k)>=0}):all,rest=all.filter(function(k){return ord.indexOf(k)<0}),first=ord.indexOf('prehled')===0;
 return (first?navBtn('prehled'):'')+apGroupHtml()+(first?ord.slice(1):ord).map(navBtn).join('')+(rest.length?'<details class="more"'+(rest.indexOf(APP.tab)>=0?' open':'')+'><summary>'+ico('menu',18)+'<span>Další moduly</span></summary>'+rest.map(navBtn).join('')+'</details>':'')}
function renderNav(){var n=document.querySelector('#vxside nav');if(!n)return;n.innerHTML=navHtml();var gsf=A('gsForm');if(gsf&&off('ceo'))gsf.style.display='none';[].forEach.call(document.querySelectorAll('#vxapp [data-tab]'),function(b){b.setAttribute('aria-pressed',b.dataset.tab===APP.tab||(b.dataset.tab==='autopilot'&&APP.tab==='marketing'))})}
function stepDone(k){var d=APP.d||{},n=function(x){return x&&x.rows?x.rows.length:0};
 return k==='cust'?n(d.customers)>0:k==='jobs'?n(d.jobs)>0:k==='svc'?n(d.booking_services)>0:k==='prod'?n(d.products)>0:k==='team'?(n(d.shifts)>0||n(d.time_entries)>0||(APP.team&&APP.team.length>1)):k==='inv'?n(d.invoices)>0:k==='cal'?n(d.reservations)>0:k==='shop'?!!(d.shop_settings&&d.shop_settings.rows&&d.shop_settings.rows[0]&&d.shop_settings.rows[0].enabled):false}
function stepsCard(){if(APP.role==='employee')return '';var P=prof(),sk='vxsteps_'+(APP.cid||'x');try{if(localStorage.getItem(sk)==='1')return ''}catch(e){}
 var st=(P.steps||[]).filter(function(s){return !off(s[1])}).map(function(s){return {t:s[0],go:s[1],done:stepDone(s[2])}}),dn=st.filter(function(x){return x.done}).length;if(!st.length||dn===st.length)return '';
 return '<section class="card2 steps"><div class="bar2"><div><h3>Začínáme: '+esc(obKey(APP.ind))+'</h3><p class="mut">Postup přizpůsobený vašemu oboru. Hotovo '+dn+' z '+st.length+'.</p></div><button type="button" class="btn btn-ghost btn-sm" data-app="stepsoff">Skrýt</button></div><ul class="stl">'+st.map(function(x){return '<li class="'+(x.done?'ok':'')+'"><button type="button" data-tab="'+x.go+'"><i aria-hidden="true">'+(x.done?'✓':'')+'</i><span>'+esc(x.t)+'</span></button></li>'}).join('')+'</ul></section>'}
function ceoQs(){var P=prof();return P.q||CEOQ}
var NAV=[['prehled','Přehled'],['aitym','AI tým'],['ceo','AI CEO'],['ucetni','AI Účetní'],['zakaznici','CRM a zákazníci'],['pripady','Obchodní případy'],['nabidky','Nabídky'],['zakazky','Zakázky a projekty'],['ukoly','Úkoly'],['faktury','Fakturace'],['finance','Finance'],['kalendar','Kalendář a rezervace'],['online','Online rezervace'],['weby','Jednoduchý web'],['marketing','Marketing'],['reporty','Reporty'],['automatizace','Automatizace'],['sklad','Sklad a produkty'],['eshop','E-shop'],['pobocky','Pobočky'],['zamestnanci','Zaměstnanci'],['firmaprofil','Profil firmy'],['autopilot','Autopilot']];
var SOON={};
var PLANN={start:'START',starter:'START',accountant:'AI Účetní',ucetni:'AI Účetní',pro:'Vexaronet PRO',business:'Vexaronet BUSINESS',enterprise:'ENTERPRISE'},STATN={demo:'ukázka',trial:'zkušební období',active:'aktivní',past_due:'po splatnosti',canceled:'zrušeno',expired:'vypršelo'};
var PLANLIM={start:'CRM max. 50 zákazníků, 10 zakázek, 10 faktur měsíčně, 1 uživatel. Bez AI CEO.',accountant:'1 uživatel, 100 AI vytěžených dokladů měsíčně.',pro:'3 uživatelé, 150 AI dokladů měsíčně, 1 web, 1 firma. AI akce zatím nepočítáme.',business:'10 uživatelů, 500 AI dokladů měsíčně, 1 web, 1 firma. AI akce zatím nepočítáme.',enterprise:'Individuální limity podle dohody.'};
function effPlan(){if(VX_ED==='source'||VX_ED==='local')return 'enterprise';var s=APP.sub;if(!s)return 'start';var p=String(s.plan||'').toLowerCase();if(p==='starter')p='start';if(p==='ucetni')p='accountant';if(p==='start')return p;var ended=(s.status==='trial'&&s.trial_end&&new Date(s.trial_end)<new Date())||s.status==='expired'||s.status==='canceled';return ended?'start':p}
function hasCeo(){return ['pro','business','enterprise'].indexOf(effPlan())>=0}
var TEAMLIM={start:1,accountant:2,pro:3,business:10,enterprise:1000},ROLEN={owner:'Majitel',admin:'Správce',employee:'Zaměstnanec'};
function off(k){return VX_OFF.indexOf(k)>=0}
function allowed(t){if(off(t))return false;var p=effPlan();if(APP.role==='employee'&&['prehled','zakaznici','zakazky','ukoly','kalendar','zamestnanci','profil'].indexOf(t)<0)return false;if(p==='start')return ['prehled','zakaznici','pripady','nabidky','zakazky','ukoly','faktury','finance','kalendar','online','reporty','automatizace','firmaprofil','autopilot','profil'].indexOf(t)>=0;if(p==='accountant')return ['prehled','ucetni','faktury','finance','reporty','zamestnanci','firmaprofil','autopilot','profil'].indexOf(t)>=0;return true}
function limitMsg(k){if(effPlan()!=='start')return '';var d=APP.d;if(k==='customers'&&d.customers.rows.length>=50)return 'Tarif START umožňuje nejvýše 50 zákazníků.';if(k==='jobs'&&d.jobs.rows.length>=10)return 'Tarif START umožňuje evidovat nejvýše 10 zakázek.';if(k==='invoices'){var m=new Date(new Date().getFullYear(),new Date().getMonth(),1);if(d.invoices.rows.filter(function(x){return new Date(x.issued_on||x.created_at)>=m}).length>=10)return 'Tarif START umožňuje nejvýše 10 faktur měsíčně.'}return ''}
function fD(s,t){if(!s)return '–';var d=new Date(s);if(isNaN(d))return esc(s);return t?d.toLocaleString('cs-CZ',{day:'numeric',month:'numeric',year:'numeric',hour:'2-digit',minute:'2-digit'}):d.toLocaleDateString('cs-CZ')}
function fM(n,cur){if(n==null||n==='')return '–';cur=cur||(typeof APP!=='undefined'&&APP.cur)||'CZK';return Number(n).toLocaleString('cs-CZ',{maximumFractionDigits:2})+' '+esc(cur==='CZK'?'Kč':cur)}
function custName(r){if(!r)return '';return r.name||r.company_name||[r.first_name,r.last_name].filter(Boolean).join(' ')||r.full_name||r.email||'(bez jména)'}
function loc(s){var d=new Date(s);if(isNaN(d))return '';d=new Date(d-d.getTimezoneOffset()*6e4);return d.toISOString().slice(0,16)}
function locD(s){var d=new Date(s);if(isNaN(d))return '';d=new Date(d-d.getTimezoneOffset()*6e4);return d.toISOString().slice(0,10)}
function A(id){return document.getElementById(id)}
function toast(t,c){var e=A('appToast');if(!e)return;e.textContent=t;e.className='toast on '+(c||'');clearTimeout(toast.t);toast.t=setTimeout(function(){e.className='toast'},4200)}
function dayStart(o){var d=new Date();d.setHours(0,0,0,0);d.setDate(d.getDate()+(o||0));return d}
var DONE=/done|hotov|dokon|complet|closed|cancel|zruš|zaplac|paid/i;
/* Stav zakázky: v databázi je jen 5 kódů (new, progress, waiting, done, canceled), podrobný název podle oboru je ve sloupci stage */
var STC={new:'Nová',progress:'Probíhá',waiting:'Čeká',done:'Hotovo',canceled:'Zrušeno'};
function stCanon(l){var t=String(l||'').trim();if(!t)return 'new';if(STC[t])return t;var low=t.toLowerCase(),L=(prof().statuses||[]),ix=L.indexOf(t);
 if(/zruš|zrus|cancel/.test(low))return 'canceled';if(/hotov|dokon|done|zaplac|vyříz|vyriz/.test(low)||(ix>=0&&ix===L.length-1&&L.length>1))return 'done';
 if(/čeká|ceka|waiting|schvál|schval/.test(low))return 'waiting';if(ix===0||/^(nov|přijat|prijat|poptáv|poptav|objedn)/.test(low))return 'new';return 'progress'}
function stLab(r){if(!r)return '';return r.stage||STC[r.status]||r.status||''}


/* ===== Ukázka bez registrace (DEMO) ===== */
var DEMO=false,DS=null,DD=null,LOCAL=false;
function demoData(){var D0=demoData0();if(!LOCAL)return D0;
 try{var sv=JSON.parse(localStorage.getItem('vxlocal1')||'null');if(sv&&sv.companies)return sv}catch(e){}
 Object.keys(D0).forEach(function(k){if(Array.isArray(D0[k]))D0[k]=[]});
 D0.companies=[{id:'demo',name:'Moje firma',industry:'Jiný obor'}];D0.company_members=[{company_id:'demo',user_id:'demo-user',role:'owner'}];D0.subscriptions=[{company_id:'demo',plan:'business',status:'local'}];D0.__created=new Date().toISOString();return D0}
function demoData0(){
 var n=Date.now(),D86=864e5,iso=function(o){return new Date(n+o*D86).toISOString()},day=function(o){return iso(o).slice(0,10)},at=function(o,h){var d=new Date(n+o*D86);d.setHours(h,0,0,0);return d.toISOString()};
 var C='demo',cs=[['u1','Novák Auto s.r.o.','info@novakauto.cz','602 111 222',-200],['u2','Stavby Dvořák','dvorak@stavbydvorak.cz','603 222 333',-170],['u3','Kavárna U Lípy','kavarna@ulipy.cz','604 333 444',-120],['u4','Pekárna Svoboda','svoboda@pekarna.cz','605 444 555',-80],['u5','Eva Horáková','eva.horakova@email.cz','606 555 666',-30],['u6','Truhlářství Marek','marek@truhlarstvi.cz','607 666 777',-9]].map(function(x){return {id:x[0],company_id:C,name:x[1],email:x[2],phone:x[3],created_at:iso(x[4]),status:x[0]==='u6'?'lead':'active',country_code:x[0]==='u3'?'SK':'CZ',tags:x[0]==='u1'?'flotila, VIP':(x[0]==='u3'?'kavárna':''),source:x[0]==='u5'?'Doporučení':'Web',next_contact_on:x[0]==='u2'?day(-2):(x[0]==='u6'?day(3):null),website:'',billing_address:'',ico:'',dic:'',notes:''}});
 var js=[['j1','Pravidelný servis flotily (5 vozidel)','u1',48500,3,'rozpracováno'],['j2','Výměna brzd a kotoučů','u5',9800,1,'rozpracováno'],['j3','Diagnostika a oprava elektroinstalace','u2',15200,6,'nové'],['j4','Sezónní přezutí pneumatik','u3',3600,-4,'hotovo'],['j5','Výměna rozvodů','u4',22400,10,'nové'],['j6','Příprava vozu k STK','u6',4200,-12,'hotovo'],['j7','Výměna spojky','u2',18900,-17,'hotovo'],['j8','Pravidelná kontrola brzd','u1',6400,14,'nové'],['j9','Oprava klimatizace','u3',7800,19,'nové']].map(function(x){return {id:x[0],company_id:C,title:x[1],customer_id:x[2],price:x[3],due_at:at(x[4],12),status:x[5],created_at:iso(-20)}});
 var rs=[['r1','Prohlídka vozu – Eva Horáková','u5',0,9],['r2','Přezutí – Kavárna U Lípy','u3',0,13],['r3','Servis dodávky – Stavby Dvořák','u2',1,8],['r4','Diagnostika – Novák Auto','u1',2,10],['r5','Příjem vozu – Pekárna Svoboda','u4',4,11],['r6','Přezutí – Truhlářství Marek','u6',-9,10],['r7','Výměna oleje – Eva Horáková','u5',-5,14],['r8','Diagnostika – Stavby Dvořák','u2',6,9],['r9','Prohlídka vozu – Kavárna U Lípy','u3',8,15],['r10','Servis flotily – Novák Auto','u1',9,8],['r11','Přezutí – Pekárna Svoboda','u4',12,13],['r12','Servis dodávky – Stavby Dvořák','u2',-22,9],['r13','Diagnostika – Novák Auto','u1',-18,11],['r14','Přezutí – Kavárna U Lípy','u3',-15,14],['r15','Výměna oleje – Pekárna Svoboda','u4',-13,10],['r16','Prohlídka vozu – Truhlářství Marek','u6',-2,15],['r17','Servis – Eva Horáková','u5',15,9],['r18','Přezutí – Stavby Dvořák','u2',17,13],['r19','Diagnostika – Novák Auto','u1',20,10]].map(function(x){return {id:x[0],company_id:C,title:x[1],customer_id:x[2],starts_at:at(x[3],x[4]),ends_at:at(x[3],x[4]+1),canceled:false,created_at:iso(-3)}});
 var ts=[['t1','Zavolat Novák Auto ohledně termínu servisu flotily',1,false],['t2','Objednat brzdové kotouče',0,false],['t3','Poslat nabídku Truhlářství Marek',3,false],['t4','Připomenout neuhrazenou fakturu Kavárně U Lípy',-2,false],['t5','Zkontrolovat sklad olejů',-5,true]].map(function(x){return {id:x[0],company_id:C,title:x[1],due_at:at(x[2],16),completed:x[3],created_at:iso(-6)}});
 var sup={legal_name:'Autoservis Novotný s.r.o.',ico:'12345678',dic:'CZ12345678',address_text:'Dlouhá 12, 110 00 Praha 1',bank_account:'123456789/0100',iban:'CZ1801000000000123456789',vat_payer:true,email:'info@autoservis-novotny.cz',country_code:'CZ',default_due_days:14,default_currency:'CZK'};
 var iv=[[18400,150,1,'Novák Auto s.r.o.'],[24500,120,1,'Stavby Dvořák'],[31200,95,1,'Kavárna U Lípy'],[19800,70,1,'Novák Auto s.r.o.'],[42600,45,1,'Stavby Dvořák'],[27900,25,1,'Pekárna Svoboda'],[38400,16,0,'Kavárna U Lípy'],[15200,6,0,'Pekárna Svoboda']].map(function(x,i){var d=x[1];return {id:'v'+i,company_id:C,number:'2026'+('000'+(i+1)).slice(-3),total:x[0],currency:'CZK',issued_on:day(-d),due_on:day(-d+14),paid_at:x[2]?iso(-d+9):null,customer_snapshot:{name:x[3],email:"fakturace@"+x[3].toLowerCase().replace(/[^a-z]/g,"")+".cz",ico:"2"+(1000000+i*137).toString().slice(0,7),billing_address:"Praha"},supplier_snapshot:sup,items:[{description:'Servisní práce',quantity:1,unit:'ks',unit_gross:Math.round(x[0]*0.6),vat_rate:21},{description:'Náhradní díly a materiál',quantity:1,unit:'ks',unit_gross:x[0]-Math.round(x[0]*0.6),vat_rate:21}],created_at:iso(-d)}});
 var fe=[];[[-150,'Servisní zakázky','income',48200],[-120,'Servisní zakázky','income',52400],[-95,'Servisní zakázky','income',61300],[-70,'Servisní zakázky','income',57800],[-45,'Servisní zakázky','income',64900],[-12,'Servisní zakázky','income',58400]].forEach(function(x,i){fe.push({id:'f'+i,company_id:C,title:x[1],amount:x[3],kind:x[2],entry_date:day(x[0]),created_at:iso(x[0])})});
 [[-150,'Nájem dílny',-18000],[-120,'Náhradní díly – Autodíly CZ',-21400],[-95,'Nájem dílny',-18000],[-70,'Náhradní díly – Autodíly CZ',-24300],[-45,'Energie a pojištění',-9800],[-30,'Nájem dílny',-18000],[-14,'Náhradní díly – Autodíly CZ',-19600],[-8,'Pohonné hmoty',-4200]].forEach(function(x,i){fe.push({id:'g'+i,company_id:C,title:x[1],amount:Math.abs(x[2]),kind:'expense',entry_date:day(x[0]),created_at:iso(x[0])})});
 var DSH=[];[['Petr Mechanik',8,16],['Jana Recepční',8,16],['Michal Novotný',9,17]].forEach(function(p,pi){for(var o=-28;o<=28;o++){var dd=new Date(n+o*D86),w=dd.getDay();if(w===0||w===6)continue;if(pi===1&&(o%2))continue;if(pi===2&&w!==2&&w!==4)continue;DSH.push({id:'sh'+pi+'_'+o,company_id:C,person:p[0],starts_at:at(o,p[1]),ends_at:at(o,p[2]),note:'',created_at:iso(-20)})}});
 var PR=[['p1','Motorový olej 5W-30 (1 l)','OIL-5W30','l',180,260,20,-60,64],['p2','Olejový filtr','FIL-OIL','ks',95,160,10,-60,26],['p3','Brzdové destičky přední','BRK-FR','sada',640,980,4,-60,9],['p4','Stěrače 600 mm','WIP-600','ks',120,220,6,-60,5],['p5','Chladicí kapalina (5 l)','COOL-5','ks',210,340,3,-60,12]],SP=[],SM=[];
 PR.forEach(function(x,i){SP.push({id:x[0],company_id:C,name:x[1],sku:x[2],unit:x[3],cost:x[4],price:x[5],min_qty:x[6],active:true,shop_visible:true,description:'Skladem u nás v Praze. Rádi poradíme s výběrem.',vat_rate:21,created_at:iso(x[7])});SM.push({id:'m'+i+'a',company_id:C,product_id:x[0],qty:x[8],kind:'in',note:'Počáteční stav',created_at:iso(-58)})});
 [['p1',-30,'Servis zakázky',-30],['p1',-10,'Servis zakázky',-12],['p2',-8,'Výměny oleje',-20],['p3',-3,'Servis zakázky',-9],['p4',-4,'Prodej',-15],['p5',-2,'Servis zakázky',-7]].forEach(function(m,i){SM.push({id:'m'+i+'b',company_id:C,product_id:m[0],qty:m[1],kind:'out',note:m[2],created_at:iso(m[3])})});
 js.forEach(function(x,i){x.location_id=i%3===1?'l2':'l1'});rs.forEach(function(x,i){x.location_id=i%2?'l2':'l1'});DSH.forEach(function(x,i){x.location_id=i%2?'l2':'l1'});
 var TE=[];for(var o=-14;o<=-1;o++){var wd=new Date(n+o*D86).getDay();if(wd===0||wd===6)continue;TE.push({id:'te'+o,company_id:C,user_id:'u-demo2',person:'mechanik@autoservis-novotny.cz',started_at:at(o,8),ended_at:at(o,16),created_at:at(o,8)})}TE.push({id:'te_open',company_id:C,user_id:'u-demo2',person:'mechanik@autoservis-novotny.cz',started_at:new Date(n-2.5*36e5).toISOString(),ended_at:null,created_at:iso(0)});
 return {company_members:[{company_id:C,user_id:'demo-user',role:'owner'}],company_invites:[],member_rates:[{company_id:C,user_id:'u-demo2',hourly_rate:300}],time_entries:TE,companies:[{id:C,name:'Autoservis Novotný',industry:'Autoservis'}],subscriptions:[{company_id:C,plan:'business',status:'demo'}],customers:cs,deals:[{id:'d1',company_id:C,customer_id:'u2',title:'Servisní smlouva pro vozový park',value:120000,stage:'negotiation',probability:75,expected_close:day(12),created_at:iso(-20),updated_at:iso(-2)},{id:'d2',company_id:C,customer_id:'u3',title:'Pravidelné čištění klimatizací',value:36000,stage:'offer',probability:50,expected_close:day(25),created_at:iso(-9),updated_at:iso(-3)},{id:'d3',company_id:C,customer_id:'u6',title:'Zimní přezutí pro firmu',value:18500,stage:'new',probability:10,expected_close:day(40),created_at:iso(-2),updated_at:iso(-2)},{id:'d4',company_id:C,customer_id:'u1',title:'Roční servis flotily',value:84000,stage:'won',probability:100,expected_close:day(-5),created_at:iso(-40),updated_at:iso(0)}],quotes:[{id:'q1',company_id:C,customer_id:'u3',deal_id:'d2',number:'N2026-0001',title:'Čištění klimatizací',valid_until:day(20),items:[{description:'Čištění klimatizace',quantity:3,unit:'ks',unit_gross:4500,vat_rate:21},{description:'Dezinfekce',quantity:3,unit:'ks',unit_gross:1500,vat_rate:21}],total:18000,currency:'CZK',status:'sent',created_at:iso(-8)}],client_notes:[{id:'n1',company_id:C,customer_id:'u2',kind:'call',body:'Telefonát: zájem o roční smlouvu, pošleme kalkulaci.',created_at:iso(-6)}],jobs:js,reservations:rs,tasks:ts,invoices:iv,financial_entries:fe.concat([{id:'fm1',company_id:C,title:'Reklama na Facebooku',amount:1800,kind:'expense',entry_date:day(-9),created_at:iso(-9)},{id:'fm2',company_id:C,title:'Marketing: letáky do schránek',amount:1200,kind:'expense',entry_date:day(-4),created_at:iso(-4)}]),
  marketing_posts:[['mp1','Příspěvek: Přezutí bez čekání','Instagram','done',-2,'Zimní pneumatiky přezujeme na počkání. Termín si vyberete online na našem webu.'],['mp2','Video: Jak poznat opotřebené brzdy','Facebook','done',-1,'Krátké video z dílny: tři znaky, že brzdy potřebují kontrolu.'],['mp3','Příspěvek: Servis klimatizace před zimou','Facebook','planned',0,'Zamlžená skla? Vyčistíme a doplníme klimatizaci, objednejte se online.'],['mp4','Novinka na web: Zimní prohlídka vozu','Web nebo blog','planned',2,'Zimní prohlídka: baterie, brzdy, světla a kapaliny. Objednání online.'],['mp5','Marketingové video: nová služba','Instagram','draft',1,'Scénář krátkého videa o vyzvednutí a přistavení vozu.'],['mp6','Příspěvek na Instagram a Facebook','Facebook','draft',3,'Proč se vyplatí pravidelný servis flotily: méně prostojů, jasné náklady.'],['mp7','Reklama: Přezutí pneumatik online','Reklama','draft',4,'Nadpis: Přezutí bez čekání. Popis: Vyberte si termín online, hotovo do hodiny.']].map(function(x){return {id:x[0],company_id:C,title:x[1],channel:x[2],status:x[3],planned_on:day(x[4]),body:x[5],created_by:'demo-user',created_at:iso(-6)}}),plan_requests:[],ai_usage:[],shifts:DSH,booking_profiles:[{company_id:C,slug:'autoservis-novotny',enabled:true,title:'Autoservis Novotný – online rezervace',description:'Objednejte se na servis, pneuservis nebo prohlídku vozu. Vyberte službu a volný termín.',address:'Dlouhá 12, Praha 1',phone:'602 000 000',hours:{1:{o:'08:00',c:'17:00'},2:{o:'08:00',c:'17:00'},3:{o:'08:00',c:'17:00'},4:{o:'08:00',c:'17:00'},5:{o:'08:00',c:'16:00'},6:{o:'09:00',c:'12:00'}},slot_minutes:30,capacity:2}],products:SP,shop_settings:[{company_id:C,slug:'autoservis-novotny',enabled:true,title:'Autoservis Novotný – e-shop',description:'Díly a doplňky pro vaše auto. Objednávku vyřídíme do 2 pracovních dnů.',contact_email:'novotny@autoservis-novotny.cz',contact_phone:'602 000 000',shipping_fee:99,pickup_enabled:true,pickup_text:'Osobní odběr v dílně v pracovní dny 8 až 17 hodin.',shipping_text:'Zboží odesíláme do 2 pracovních dnů.',payment_text:'Platba bankovním převodem podle faktury.'}],shop_orders:[],shop_order_items:[],stock_moves:SM,locations:[{id:'l1',company_id:C,name:'Plzeň – centrum',address:'Americká 12',city:'Plzeň',phone:'377 111 222',email:'centrum@autoservis-novotny.cz',hours:'Po–Pá 8–17',note:'Hlavní provozovna',active:true,created_at:iso(-300)},{id:'l2',company_id:C,name:'Plzeň – Slovany',address:'Slovanská alej 40',city:'Plzeň',phone:'377 333 444',email:'slovany@autoservis-novotny.cz',hours:'Po–Pá 8–16',note:'Pneuservis a přezouvání',active:true,created_at:iso(-200)}],digest_settings:[],booking_services:[{id:'s1',company_id:C,name:'Prohlídka vozu',duration_min:30,price:0,active:true},{id:'s2',company_id:C,name:'Výměna oleje a filtrů',duration_min:60,price:1290,active:true},{id:'s3',company_id:C,name:'Přezutí pneumatik',duration_min:45,price:790,active:true},{id:'s4',company_id:C,name:'Diagnostika závad',duration_min:90,price:1490,active:true}]};
}
function demoSb(){
 if(DS)return DS;DD=demoData();var D=DD,seq=D.__seq||100;
 function lsave(){if(!LOCAL)return;D.__seq=seq;try{localStorage.setItem('vxlocal1',JSON.stringify(D))}catch(e){try{toast('Data se nepodařilo uložit do prohlížeče. Stáhněte si zálohu a zkontrolujte, že prohlížeč neblokuje ukládání.','err')}catch(x){}}}
 function supS(){return (D.user_business_profiles&&D.user_business_profiles[0])||(D.invoices[0]||{}).supplier_snapshot||{}}
 function qb(t){var q={op:'sel',f:[],pl:null,cnt:false,head:false};
  var o={select:function(c,opt){if(opt&&opt.count)q.cnt=true;if(opt&&opt.head)q.head=true;return o},eq:function(k,v){q.f.push(function(r){return r[k]===v});return o},is:function(k,v){q.f.push(function(r){return v===null?r[k]==null:r[k]===v});return o},gte:function(k,v){q.f.push(function(r){return String(r[k]||'')>=String(v)});return o},order:function(){return o},limit:function(){return o},
   upsert:function(r,opt){q.op='ups';q.pl=r;q.k=(opt&&opt.onConflict)||'id';return o},insert:function(r){q.op='ins';q.pl=r;return o},update:function(r){q.op='upd';q.pl=r;return o},delete:function(){q.op='del';return o},
   then:function(res,rej){return Promise.resolve().then(function(){var tb=D[t]||(D[t]=[]),m=function(r){return q.f.every(function(f){return f(r)})},data=null;
    if(q.op==='ins'){var a=Array.isArray(q.pl)?q.pl:[q.pl];data=a.map(function(r){var x=Object.assign({id:'n'+(++seq),created_at:new Date().toISOString()},r);tb.push(x);return x})}
    else if(q.op==='ups'){var ex=tb.filter(function(r){return r[q.k]===q.pl[q.k]})[0];if(ex){Object.assign(ex,q.pl)}else tb.push(Object.assign({id:'n'+(++seq)},q.pl));data=[q.pl]}
    else if(q.op==='upd'){data=tb.filter(m);data.forEach(function(r){Object.assign(r,q.pl)})}
    else if(q.op==='del'){D[t]=tb.filter(function(r){return !m(r)})}
    else{data=tb.filter(m);if(q.head)return {data:null,count:data.length,error:null}}
    if(q.op!=='sel')lsave();return {data:data,error:null,count:data?data.length:0}}).then(res,rej)}};
  return o}
 function ds(){var d=new Date(),m0=new Date(d.getFullYear(),d.getMonth(),1),t0=new Date();t0.setHours(0,0,0,0);var t1=new Date(t0.getTime()+864e5),fe=D.financial_entries,inc=0,ex=0;
  fe.forEach(function(r){if(new Date(r.entry_date)>=m0){if(r.kind==='income')inc+=Number(r.amount)||0;else ex+=Math.abs(Number(r.amount)||0)}});
  D.invoices.forEach(function(r){if(r.paid_at&&new Date(r.paid_at)>=m0)inc+=Number(r.total)||0});
  return {income:inc,expenses:ex,customers:D.customers.length,active_jobs:D.jobs.filter(function(j){return !/hotov|done|zruš/i.test(j.status||'')}).length,reservations_today:D.reservations.filter(function(r){var s=new Date(r.starts_at);return !r.canceled&&s>=t0&&s<t1}).length}}
 function rpc(n,a){return Promise.resolve().then(function(){
  if(n==='dashboard_summary')return {data:ds(),error:null};
  if(n==='public_booking_info'){var pr=D.booking_profiles.filter(function(x){return x.slug===a.p_slug&&x.enabled})[0];if(!pr)return {data:null,error:null};return {data:{name:D.companies[0].name,title:pr.title,description:pr.description,address:pr.address,phone:pr.phone,hours:pr.hours,services:D.booking_services.filter(function(x){return x.active!==false}).map(function(x){return {id:x.id,name:x.name,duration_min:x.duration_min,price:x.price}})},error:null}}
  if(n==='public_slots')return {data:dslots(a.p_service,a.p_day),error:null};
  if(n==='public_book'){var st=new Date(a.p_start),dy=st.getFullYear()+'-'+(st.getMonth()+1)+'-'+st.getDate(),ok=dslots(a.p_service,dy).some(function(x){return new Date(x).getTime()===st.getTime()});if(!ok)return {data:null,error:{message:'slot_taken'}};
   var sv=D.booking_services.filter(function(x){return x.id===a.p_service})[0],cu=D.customers.filter(function(x){return String(x.email).toLowerCase()===String(a.p_email).toLowerCase()})[0];if(!cu){cu={id:'n'+(++seq),company_id:'demo',name:a.p_name,email:a.p_email,phone:a.p_phone,created_at:new Date().toISOString()};D.customers.push(cu)}
   var en=new Date(st.getTime()+sv.duration_min*6e4);D.reservations.push({id:'n'+(++seq),company_id:'demo',title:'Online: '+sv.name+' - '+a.p_name,customer_id:cu.id,starts_at:st.toISOString(),ends_at:en.toISOString(),canceled:false,created_at:new Date().toISOString()});return {data:{ok:true,start:st.toISOString(),end:en.toISOString(),service:sv.name,business:D.companies[0].name},error:null}}
  if(n==='public_shop'){var ss=(D.shop_settings||[]).filter(function(x){return x.slug===a.p_slug&&x.enabled})[0];if(!ss)return {data:null,error:null};
   return {data:{name:D.companies[0].name,title:ss.title,description:ss.description,contact_email:ss.contact_email,contact_phone:ss.contact_phone,payment_text:ss.payment_text,shipping_text:ss.shipping_text,shipping_fee:ss.shipping_fee,pickup_enabled:!!ss.pickup_enabled,pickup_text:ss.pickup_text,products:D.products.filter(function(p){return p.active!==false&&p.shop_visible&&Number(p.price)>0}).map(function(p){var av=0;D.stock_moves.forEach(function(m){if(m.product_id===p.id)av+=Number(m.qty)||0});return {id:p.id,name:p.name,description:p.description,image_url:p.image_url,price:p.price,unit:p.unit,available:Math.max(0,Math.min(50,av))}})},error:null}}
  if(n==='public_shop_order'){var so=(D.shop_settings||[]).filter(function(x){return x.slug===a.p_slug&&x.enabled})[0];if(!so)return {data:null,error:{message:'Obchod není dostupný.'}};if(a.p_hp)return {data:null,error:{message:'Objednávku se nepodařilo odeslat.'}};
   var by=a.p_buyer||{},its=a.p_items||[],tot=0,lines=[];if(!its.length)return {data:null,error:{message:'Košík je prázdný.'}};
   for(var ii=0;ii<its.length;ii++){var pp=D.products.filter(function(p){return p.id===its[ii].product_id&&p.shop_visible&&p.active!==false})[0];if(!pp)return {data:null,error:{message:'Některé zboží už není v nabídce.'}};var av2=0;D.stock_moves.forEach(function(m){if(m.product_id===pp.id)av2+=Number(m.qty)||0});if(av2<its[ii].qty)return {data:null,error:{message:'Zboží „'+pp.name+'“ už není v požadovaném množství skladem (zbývá '+Math.max(0,av2)+').'}};lines.push([pp,its[ii].qty]);tot+=pp.price*its[ii].qty}
   var fee=(a.p_delivery==='pickup'&&so.pickup_enabled)?0:(Number(so.shipping_fee)||0);tot+=fee;var on=(D.shop_orders.length)+1,cu2=D.customers.filter(function(x){return String(x.email).toLowerCase()===String(by.email).toLowerCase()})[0];if(!cu2){cu2={id:'n'+(++seq),company_id:'demo',name:by.name,email:by.email,phone:by.phone,billing_address:by.address,created_at:new Date().toISOString()};D.customers.push(cu2)}
   var jb={id:'n'+(++seq),company_id:'demo',customer_id:cu2.id,title:'E-shop objednávka č. '+on,description:lines.map(function(l){return l[0].name+' × '+l[1]}).join('\n'),price:tot,status:'new',stage:'Nová',created_at:new Date().toISOString()};D.jobs.push(jb);
   var no2=new Date().getFullYear()+('000'+(D.invoices.length+1)).slice(-3),sp3=supS(),due=new Date(Date.now()+14*864e5).toISOString().slice(0,10),itv=lines.map(function(l){return {description:l[0].name,quantity:l[1],unit_gross:l[0].price}});if(fee>0)itv.push({description:'Doprava',quantity:1,unit_gross:fee});
   var iv2={id:'v'+(++seq),company_id:'demo',number:no2,total:tot,currency:'CZK',issued_on:new Date().toISOString().slice(0,10),due_on:due,paid_at:null,job_id:jb.id,customer_snapshot:{name:by.name},supplier_snapshot:sp3,items:itv,created_at:new Date().toISOString()};D.invoices.push(iv2);
   var od={id:'o'+(++seq),company_id:'demo',order_no:on,customer_id:cu2.id,job_id:jb.id,invoice_id:iv2.id,status:'new',buyer:by,note:a.p_note,shipping_fee:fee,total:tot,invoice_error:null,created_at:new Date().toISOString()};D.shop_orders.push(od);
   lines.forEach(function(l){D.shop_order_items.push({id:'i'+(++seq),order_id:od.id,company_id:'demo',product_id:l[0].id,name:l[0].name,qty:l[1],unit_price:l[0].price});D.stock_moves.push({id:'m'+(++seq),company_id:'demo',product_id:l[0].id,qty:-l[1],kind:'out',note:'E-shop objednávka č. '+on,created_at:new Date().toISOString()})});
   return {data:{order_no:on,total:tot,currency:'CZK',invoice_number:no2,invoice_ok:true,iban:sp3.iban||'',bank_account:sp3.bank_account||'',due_on:due,payment_text:so.payment_text,email:by.email},error:null}}
  if(n==='shop_cancel_order'){var oc=D.shop_orders.filter(function(x){return x.id===a.p_order})[0];if(!oc)return {data:null,error:{message:'Objednávka nenalezena.'}};if(oc.status==='canceled')return {data:true,error:null};D.shop_order_items.filter(function(x){return x.order_id===oc.id}).forEach(function(l){D.stock_moves.push({id:'m'+(++seq),company_id:'demo',product_id:l.product_id,qty:l.qty,kind:'in',note:'Zrušení e-shop objednávky č. '+oc.order_no,created_at:new Date().toISOString()})});oc.status='canceled';return {data:true,error:null}}
  if(n==='company_team')return LOCAL?{data:[{user_id:'demo-user',email:'firma@vexaronet.local',role:'owner',is_me:true}],error:null}:{data:[{user_id:'demo-user',email:'novotny@autoservis-novotny.cz',role:'owner',is_me:true},{user_id:'u-demo2',email:'mechanik@autoservis-novotny.cz',role:'employee',is_me:false}],error:null};
  if(n==='clock_in'){var me='demo-user';if(D.time_entries.some(function(x){return x.user_id===me&&!x.ended_at}))return {data:null,error:{message:'already online'}};D.time_entries.push({id:'n'+(++seq),company_id:'demo',user_id:me,person:'novotny@autoservis-novotny.cz',shift_id:a.sid,started_at:new Date().toISOString(),ended_at:null,created_at:new Date().toISOString()});return {data:true,error:null}}
  if(n==='clock_out'){var tu=a.target||'demo-user';D.time_entries.forEach(function(x){if(x.user_id===tu&&!x.ended_at)x.ended_at=new Date().toISOString()});return {data:true,error:null}}
  if(n==='cancel_invite'){D.company_invites=D.company_invites.filter(function(x){return x.id!==a.invite_id});return {data:true,error:null}}
  if(n==='remove_member'||n==='accept_company_invites')return {data:0,error:null};
  if(n==='invoice_action'){var doc=a.doc||{};
   if(a.action==='start'){var sp0=supS(),dr={id:'draft-'+(++seq),company_id:'demo',job_id:doc.job_id,lifecycle:'draft',number:null,total:0,currency:'CZK',paid_at:null,supplier_snapshot:sp0,customer_snapshot:{},items:[],created_at:new Date().toISOString()};D.invoices.push(dr);return {data:{id:dr.id,job_id:doc.job_id,lifecycle:'draft'},error:null}}
   if(a.action==='save'){var d1=D.invoices.filter(function(x){return x.id===doc.id&&x.lifecycle==='draft'})[0];if(!d1)return {data:null,error:{message:'Koncept nenalezen.'}};var t1=0;(doc.items||[]).forEach(function(i){t1+=(i.quantity||0)*(i.unit_gross||0)});Object.assign(d1,{total:Math.round(t1*100)/100,currency:doc.currency||'CZK',issued_on:doc.issued_on,due_on:doc.due_on,taxable_supply_on:doc.taxable_supply_on,customer_snapshot:doc.customer||{},items:doc.items});return {data:{ok:true,id:d1.id},error:null}}
   if(a.action==='paid'){D.invoices.forEach(function(x){if(x.id===doc.id)x.paid_at=new Date().toISOString()});return {data:{ok:true},error:null}}
   if(a.action==='profile'){var sp=Object.assign({},doc);D.invoices.forEach(function(x){x.supplier_snapshot=sp});if(LOCAL)D.user_business_profiles=[Object.assign({company_id:'demo'},sp)];return {data:{ok:true},error:null}}
   if(a.action==='issue'&&doc.id&&D.invoices.some(function(x){return x.id===doc.id&&x.lifecycle==='draft'})){var d2=D.invoices.filter(function(x){return x.id===doc.id})[0],t2=0;(doc.items||[]).forEach(function(i){t2+=(i.quantity||0)*(i.unit_gross||0)});var no3=new Date().getFullYear()+('0000'+(D.invoices.filter(function(x){return x.number}).length+1)).slice(-4);Object.assign(d2,{lifecycle:'issued',number:no3,variable_symbol:no3,total:Math.round(t2*100)/100,currency:doc.currency||'CZK',issued_on:doc.issued_on,due_on:doc.due_on,taxable_supply_on:doc.taxable_supply_on,customer_snapshot:doc.customer||{},items:doc.items});return {data:{number:no3},error:null}}
   if(a.action==='issue'){var tot=0;(doc.items||[]).forEach(function(i){tot+=(i.quantity||0)*(i.unit_gross||0)});var no=new Date().getFullYear()+('000'+(D.invoices.length+1)).slice(-3),sp2=supS();
    D.invoices.push({id:'v'+(++seq),company_id:'demo',number:no,total:Math.round(tot*100)/100,currency:doc.currency||'CZK',issued_on:doc.issued_on,due_on:doc.due_on,paid_at:null,customer_snapshot:{name:(doc.customer||{}).name},supplier_snapshot:sp2,items:doc.items,created_at:new Date().toISOString()});return {data:{number:no},error:null}}}
  return {data:null,error:null}})}
 function dslots(sid,day){var pr=D.booking_profiles[0],sv=D.booking_services.filter(function(x){return x.id===sid})[0],out=[];if(!pr||!sv||!pr.enabled)return out;var p=String(day).split('-'),d0=new Date(+p[0],+p[1]-1,+p[2]),dw=d0.getDay()||7,h=pr.hours[dw];if(!h)return out;var o=h.o.split(':'),c=h.c.split(':'),t=new Date(d0);t.setHours(+o[0],+o[1],0,0);var lim=new Date(d0);lim.setHours(+c[0],+c[1],0,0);var dur=sv.duration_min*6e4,st=pr.slot_minutes*6e4;while(t.getTime()+dur<=lim.getTime()){if(t.getTime()>Date.now()+72e5){var busy=D.reservations.filter(function(r){return !r.canceled&&new Date(r.starts_at)<t.getTime()+dur&&new Date(r.ends_at)>t.getTime()}).length;if(busy<pr.capacity)out.push(t.toISOString())}t=new Date(t.getTime()+st)}return out}
 var meta={full_name:LOCAL?'Uživatel':'Michal Novotný',onboarded:true,features:['zakaznici','zakazky','kalendar','faktury','ai','zamestnanci'],country:'Česko'};
 DS={from:qb,rpc:function(n,a){return rpc(n,a).then(function(r){lsave();return r})},auth:{getSession:function(){return Promise.resolve({data:{session:{access_token:'demo'}}})},getUser:function(){return Promise.resolve({data:{user:{id:'demo-user',email:LOCAL?'firma@vexaronet.local':'novotny@autoservis-novotny.cz',user_metadata:meta}}})},onAuthStateChange:function(){},updateUser:function(x){Object.assign(meta,x.data||{});return Promise.resolve({data:{user:{user_metadata:meta}},error:null})},signOut:function(){return Promise.resolve()}}};
 return DS}
function dresp(o,st){return Promise.resolve(new Response(JSON.stringify(o),{status:st||200,headers:{'content-type':'application/json'}}))}
function dfetch(u,o){
 if(!DEMO)return fetch(u,o);
 var b={};try{b=JSON.parse(o.body)}catch(e){}
 if(String(u).indexOf('/api/digest')>=0){return dresp({ok:true,mail:'sent',to:b.email||'novotny@autoservis-novotny.cz',n:5})}
 if(String(u).indexOf('/api/invite')>=0){DD.company_invites.push({id:'i'+Date.now(),company_id:'demo',email:b.email,role:b.role,created_at:new Date().toISOString(),accepted_at:null});return dresp({ok:true,mail:'demo'})}
 if(String(u).indexOf('/api/advisor')>=0){var q=((b.messages||[]).slice(-1)[0]||{}).content||'',s=b.summary||{};return new Promise(function(r){setTimeout(r,700)}).then(function(){return dresp({reply:'Ukázková odpověď (v ostrém účtu odpovídá AI podle vašich skutečných dat).\n\nPodle dat v ukázce máte '+(s.neuhrazene_faktury!=null?s.neuhrazene_faktury+' neuhrazených faktur. ':'rozpracované zakázky a neuhrazené faktury. ')+'Doporučuji: 1) připomenout se Kavárně U Lípy, faktura je po splatnosti, 2) potvrdit termín servisu flotily s Novák Auto, 3) objednat díly na výměnu brzd. Chcete, abych k tomu připravil úkoly? (Akce vždy provedu až po vašem potvrzení.)'})})}
 if(String(u).indexOf('/api/marketing')>=0){var T={social:'Zimní pneumatiky? Objednejte přezutí online a ušetřete si čekání. Stačí vybrat termín a my se postaráme o zbytek. [doplnit cenu]\n\nRezervace na našem webu. #servis #pneuservis #přezutí',email:'Předmět: Je čas přezout? Objednejte se online\n\nDobrý den,\nblíží se zima a s ní i čas na zimní pneumatiky. Termín si můžete vybrat online na našem webu, a to během pár kliknutí.\n\nTěšíme se na vás,\n[doplnit jméno]',ad:'Nadpisy:\n1) Přezutí online\n2) Objednejte si termín\n3) Servis bez čekání\n\nPopisy:\n1) Vyberte volný termín online. [doplnit cenu]\n2) Zimní pneumatiky? Postaráme se o ně rychle a férově.',plan:'Po: Příspěvek (Instagram) – tip na kontrolu pneumatik\nSt: Příspěvek (Facebook) – před a po z dílny\nPá: Newsletter – připomenutí přezutí',review:'Dobrý den, děkujeme za zpětnou vazbu. Mrzí nás, že jste nebyl(a) úplně spokojen(a), a rádi věc společně vyřešíme. Ozvěte se nám prosím na [doplnit kontakt].'};return new Promise(function(r){setTimeout(r,800)}).then(function(){return dresp({demo:true,text:T[b.kind]||T.social})})}
 if(String(u).indexOf('/api/web-ai')>=0){var nm0=b.name||'Naše firma';return new Promise(function(r){setTimeout(r,900)}).then(function(){return dresp({demo:true,site:{hero:{title:nm0+': spolehlivý servis bez zbytečných starostí',subtitle:'Postaráme se o vaše auto rychle, férově a s jasným vysvětlením, co a proč děláme.',cta:'Objednat se'},about:{title:'O nás',text:'Jsme malá provozovna, která se věnuje servisu vozidel pro místní řidiče i firmy. Víme, že auto je pro vás nástroj, a proto klademe důraz na jasnou domluvu a dodržení termínů.'},services:[{name:'Servis a opravy',desc:'Běžné opravy, výměna dílů a kontrola stavu vozu.'},{name:'Pneuservis',desc:'Přezutí, vyvážení a uskladnění pneumatik.'},{name:'Diagnostika',desc:'Zjištění příčiny závady a návrh řešení.'}]}})})}
 if(String(u).indexOf('/api/accountant')>=0){
  if(b.mode==='ask'){var m=b.summary||{};return new Promise(function(r){setTimeout(r,600)}).then(function(){return dresp({reply:'Ukázková odpověď z čísel v evidenci: tento měsíc máte příjmy '+(m.prijmy_tento_mesic_kc||0).toLocaleString('cs-CZ')+' Kč a výdaje '+(m.vydaje_tento_mesic_kc||0).toLocaleString('cs-CZ')+' Kč. Minulý měsíc to bylo '+(m.prijmy_minuly_mesic_kc||0).toLocaleString('cs-CZ')+' Kč příjmů a '+(m.vydaje_minuly_mesic_kc||0).toLocaleString('cs-CZ')+' Kč výdajů. Nejde o účetní ani daňovou radu.'})})}
  return new Promise(function(r){setTimeout(r,1200)}).then(function(){return dresp({doc:{document_type:'received_invoice',supplier_name:'Autodíly CZ s.r.o.',supplier_ico:'87654321',document_number:'FA-2026-0418',issue_date:new Date().toISOString().slice(0,10),total_amount:12100,vat_amount:2100,vat_rate:21,currency:'CZK',description:'Brzdové kotouče a destičky',category:'material',confidence:'high',warnings:['Ukázka: nahraný soubor se nezpracovává, jde o vzorový doklad. V ostrém účtu AI vytěží údaje z vašeho souboru.']},used:1,limit:500})})}
 return dresp({error:'demo'},400)}
window.addEventListener('load',function(){try{if(document.documentElement.classList.contains('appmode')){var sp=A('appSplash');if(sp)sp.hidden=false;var sl=A('splashLogin');if(sl)sl.addEventListener('click',function(){openApp()});setTimeout(function(){try{openApp()}catch(e){}},400)}}catch(e){}var rq=null;try{rq=new URLSearchParams(location.search).get('r')}catch(e){}if(rq&&/^[a-zA-Z0-9-]{3,41}$/.test(rq))bookOpen(rq.toLowerCase(),false);var wq=null;try{wq=new URLSearchParams(location.search).get('w')}catch(e){}if(wq&&/^[a-zA-Z0-9-]{3,41}$/.test(wq))webOpen(wq.toLowerCase(),false);var sq=null;try{sq=new URLSearchParams(location.search).get('s')}catch(e){}if(sq&&/^[a-zA-Z0-9-]{3,41}$/.test(sq))shopOpen(sq.toLowerCase(),false)});
function localBox(){var lb='';try{lb=localStorage.getItem('vxlocal_bak')||''}catch(e){}
 return '<div class="lbox"><b>Lokální verze</b><small>Data jsou jen v tomto prohlížeči a počítači. Pravidelně stahujte zálohu.</small><small>Poslední záloha: '+(lb?new Date(lb).toLocaleString('cs-CZ'):'zatím žádná')+'</small><button type="button" class="btn btn-ghost btn-sm" data-app="lbak">Stáhnout zálohu</button><button type="button" class="btn btn-ghost btn-sm" data-app="lres">Obnovit ze zálohy</button><input type="file" id="lresf" accept="application/json,.json" hidden></div>'}
function localBackup(){try{var raw=localStorage.getItem('vxlocal1')||JSON.stringify(DD||{}),b=new Blob([raw],{type:'application/json'}),a=document.createElement('a'),d=new Date(),nm='vexaronet-zaloha-'+d.getFullYear()+'-'+('0'+(d.getMonth()+1)).slice(-2)+'-'+('0'+d.getDate()).slice(-2)+'.json';a.href=URL.createObjectURL(b);a.download=nm;document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},500);localStorage.setItem('vxlocal_bak',d.toISOString());toast('Záloha se stáhla do souboru '+nm+'. Uložte ji mimo tento počítač, např. na USB nebo do cloudu.','ok');renderNav()}catch(e){toast('Zálohu se nepodařilo vytvořit.','err')}}
document.addEventListener('change',function(e){if(!e.target||e.target.id!=='lresf')return;var f=e.target.files&&e.target.files[0];if(!f)return;var r=new FileReader();r.onload=function(){try{var o=JSON.parse(r.result);if(!o||!Array.isArray(o.companies)||!Array.isArray(o.customers))throw new Error('x');if(!confirm('Obnovit data ze zálohy? Současná data v tomto prohlížeči budou nahrazena.'))return;localStorage.setItem('vxlocal1',JSON.stringify(o));location.reload()}catch(x){toast('Soubor není záloha Vexaronetu.','err')}};r.readAsText(f)});
function startDemo(){DEMO=true;DS=null;APP.betaHidden=true;openApp()}

async function openApp(){
 var c=getSb();if(!c)return;closeDlg();
 var u=(await c.auth.getUser()).data.user;if(!u){showAuth('login');return}
 var cid;try{cid=DEMO?'demo':await ensureCompany(c,u)}catch(e){openD('<h2 id="dT">Aplikace</h2><div class="draft">'+esc(niceErr(e))+'</div>');return}
 if(!cid){openD('<h2 id="dT">Aplikace</h2><div class="draft">K účtu zatím není přiřazená žádná firma. Pokud jste pozvaní, požádejte majitele firmy, ať vám pozvánku pošle na přesně tento e-mail, a pak se znovu přihlaste. Jinak se odhlaste a založte si vlastní účet.</div><div class="dact"><button class="btn btn-ghost" type="button" id="logout">Odhlásit se</button></div>');return}
 APP.cid=cid;APP.user=u;APP.meta=u.user_metadata||{};
 var R=await Promise.all([c.from('companies').select('*').eq('id',cid).limit(1),c.from('company_members').select('*').eq('company_id',cid).eq('user_id',u.id).limit(1),c.from('subscriptions').select('*').eq('company_id',cid).limit(1)]);
 var cr=R[0].data&&R[0].data[0]||{};APP.co=cr.name||'Moje firma';APP.cur=cr.currency||'CZK';APP.ind=APP.meta.ui_industry||cr.industry||APP.meta.industry||'';
 APP.role=R[1].data&&R[1].data[0]&&R[1].data[0].role||null;APP.sub=R[2].data&&R[2].data[0]||null;
 var el=A('vxapp');if(el)el.remove();
 el=document.createElement('div');el.id='vxapp';el.className='vxapp';
 var nm=(APP.meta.full_name||u.email||'').trim(),ini=nm.split(/\s+/).map(function(w){return w.charAt(0)}).join('').slice(0,2).toUpperCase()||'V';
 function nb(t){return '<button type="button" data-tab="'+t[0]+'">'+ico(t[0])+'<span>'+t[1]+'</span></button>'}
 el.innerHTML='<aside id="vxside"><div class="vlogo"><svg viewBox="0 0 32 32" width="34" height="34" aria-hidden="true"><path d="M5 7l11 19L27 7" fill="none" stroke="#8b6cff" stroke-width="4" stroke-linejoin="round" stroke-linecap="round"/></svg><div><b>VEXARONET</b><small>'+(off('ceo')?'Řízení malé firmy':'AI CEO')+' <span class="beta">BETA</span></small></div></div><nav>'+navHtml()+Object.keys(SOON).map(function(k){return '<button type="button" data-tab="'+k+'" class="soon">'+ico(k)+'<span>'+SOON[k][0]+'</span><em>brzy</em></button>'}).join('')+'</nav><div class="sfoot">'+(typeof apAgentsHtml==='function'&&!off('aitym')?apAgentsHtml():'')+(LOCAL?localBox():'<button type="button" data-app="fb">'+ico('fb')+'<span>Něco nefunguje?</span></button>')+'<button type="button" data-tab="profil">'+ico('profil')+'<span>Nastavení</span></button><div class="subc" id="subCard"></div></div></aside><div class="scrim" data-app="side"></div>'
 +'<div class="vxmain"><header><button type="button" class="ib burger" data-app="side" aria-label="Menu">'+ico('menu')+'</button><form class="gs" id="gsForm" autocomplete="off"><span class="si">'+ico('search',18)+'</span><input id="gsIn" placeholder="Zeptejte se AI CEO nebo napište, co potřebujete…" maxlength="400" aria-label="Zeptat se AI CEO"><kbd>Ctrl + K</kbd></form><div class="bellw"><button type="button" class="ib" data-app="bell" aria-label="Notifikace">'+ico('bell')+'<i class="bdg" id="appBdg"></i></button><div class="pop" id="appBell"></div></div><button type="button" class="ib" data-app="theme" aria-label="Světlý a tmavý režim">'+ico('sun')+'</button><button type="button" class="usr" data-tab="profil"><span class="ib av">'+esc(ini)+'</span><span class="un"><b>'+esc(nm.split('@')[0])+'</b><small>'+esc(APP.co)+'</small></span></button><button type="button" class="btn btn-ghost btn-sm webb" data-app="close">Web</button></header><main id="appMain"></main></div><div class="toast" id="appToast" role="status"></div>';
 if(DEMO&&!LOCAL)el.insertAdjacentHTML('beforeend','<div class="demobar" role="region" aria-label="Ukázka aplikace"><span><b>DEMO</b><i class="demot2"> ukázková data, nic se neukládá</i></span><button type="button" class="btn btn-ghost btn-sm demot" aria-expanded="false" aria-controls="demoOb">Obor</button><label class="demoob">Obor: <select id="demoOb" aria-label="Zobrazit aplikaci pro obor">'+Object.keys(OB).map(function(k){return '<option'+(k===obKey(APP.ind)?' selected':'')+'>'+esc(k)+'</option>'}).join('')+'</select></label><button type="button" class="btn btn-main btn-sm" data-demo-signup="1">Založit účet zdarma</button><button type="button" class="btn btn-ghost btn-sm" data-app="close">Ukončit ukázku</button></div>');document.body.appendChild(el);document.documentElement.style.overflow='hidden';
 var gsf0=A('gsForm');if(gsf0&&off('ceo'))gsf0.style.display='none';
 await refresh(true);if(!allowed(APP.tab))APP.tab='profil';appTab(APP.tab)}
function closeApp(){DEMO=false;var el=A('vxapp');if(el)el.remove();document.documentElement.style.overflow=''}
function subCard(){var s=APP.sub,e=A('subCard');if(!e)return;if(VX_ED==='source'||VX_ED==='local'){e.innerHTML=VX_ED==='local'?'<b>Lokální verze</b><small>Data jsou jen v tomto počítači · verze '+esc(VX_VERSION)+'</small>':'<b>Edice zdrojového kódu</b><small>Verze '+esc(VX_VERSION)+'</small>';return}if(!s){e.innerHTML='';return}
 var nm=PLANN[(s.plan||'').toLowerCase()]||s.plan,t=STATN[s.status]||s.status,x='';
 if(s.status==='trial'&&s.trial_end){var d=Math.ceil((new Date(s.trial_end)-new Date())/864e5);x=d>0?'Zbývá '+d+' '+(d===1?'den':(d<5?'dny':'dní'))+' zdarma':'Zkušební období skončilo'}else if(s.paid_until)x='Platné do '+fD(s.paid_until);
 e.innerHTML='<b>'+esc(nm)+'</b><small>'+esc(t.charAt(0).toUpperCase()+t.slice(1))+'</small><small>'+esc(x)+'</small><button type="button" data-tab="profil">Správa předplatného</button>'}
async function qt(t){var r=await getSb().from(t).select('*').eq('company_id',APP.cid);return r.error?{err:r.error.message,rows:[]}:{rows:r.data||[]}}
async function refresh(first){
 var c=getSb(),R=await Promise.all([qt('customers'),qt('jobs'),qt('reservations'),qt('tasks'),qt('invoices'),c.rpc('dashboard_summary',{cid:APP.cid}),qt('financial_entries'),qt('shifts'),qt('booking_profiles'),qt('booking_services'),qt('sites'),qt('marketing_posts'),qt('automation_rules'),qt('products'),qt('stock_moves'),qt('locations'),qt('digest_settings'),qt('time_entries'),qt('shop_settings'),qt('shop_orders'),qt('invoice_items'),qt('user_business_profiles'),qt('deals'),qt('quotes'),qt('client_notes')]);
 R[0].rows=R[0].rows.filter(function(x){return !x.archived});
 APP.d={customers:R[0],jobs:R[1],reservations:R[2],tasks:R[3],invoices:R[4],ds:R[5].error?{err:R[5].error.message}:(R[5].data||{}),fe:R[6],shifts:R[7],booking_profiles:R[8],booking_services:R[9],sites:R[10],marketing_posts:R[11],automation_rules:R[12],products:R[13],stock_moves:R[14],locations:R[15],digest_settings:R[16],time_entries:R[17],shop_settings:R[18],shop_orders:R[19],profile:R[21],deals:R[22],quotes:R[23],client_notes:R[24]};
 var itb={};(R[20].rows||[]).forEach(function(i){(itb[i.invoice_id]=itb[i.invoice_id]||[]).push(i)});APP.d.invoices.rows.forEach(function(f){if(itb[f.id])f.items=itb[f.id].sort(function(a,b){return a.position-b.position})});
 if(!DEMO)await crmProbe();
 if(!DEMO&&VX_FEED&&!APP.updChecked){APP.updChecked=1;try{var fr=await fetch(VX_FEED,{cache:'no-store',credentials:'omit'});var fj=await fr.json();var nv=String(fj.version||'').split('.').map(Number),cv=String(VX_VERSION).split('.').map(Number);if(nv.length===3&&nv.every(isFinite)&&(nv[0]>cv[0]||(nv[0]===cv[0]&&(nv[1]>cv[1]||(nv[1]===cv[1]&&nv[2]>cv[2])))))APP.upd={version:nv.join('.')}}catch(e){}}else APP.crm2={cust:true,task:true,deal:true};
 if(A('vxapp')){subCard();renderBell()}}
function appTab(t){
 APP.tab=t;var el=A('vxapp');if(!el)return;el.classList.remove('side');
 [].forEach.call(el.querySelectorAll('[data-tab]'),function(b){b.setAttribute('aria-pressed',b.dataset.tab===t)});
 var m=A('appMain');try{m.innerHTML=!allowed(t)?lockView(t):(VIEWS[t]?VIEWS[t]():soonView(t))}catch(e){m.innerHTML='<div class="draft">Stránku se nepodařilo zobrazit: '+esc(e.message)+'</div>'}
 m.scrollTop=0;if(allowed(t)&&AFTER[t])AFTER[t]();if(typeof apBar==='function')apBar();if(typeof apNavSync==='function')apNavSync()}
function lockView(t){if(document.documentElement.classList.contains('appmode'))return '<div class="card2 soonc"><span class="eyebrow">Váš tarif: '+esc(PLANN[effPlan()]||effPlan())+'</span><h2>Tato část není součástí vašeho tarifu</h2><p>Tarif a předplatné se spravují na webu vexaronet.com. Po změně tarifu se tato část v aplikaci odemkne.</p></div>';return '<div class="card2 soonc"><span class="eyebrow">Váš tarif: '+esc(PLANN[effPlan()]||effPlan())+'</span><h2>Tato část není součástí vašeho tarifu</h2><p>AI CEO a rozšířené moduly jsou ve Vexaronet PRO (699 Kč měsíčně bez DPH) a vyšších tarifech.</p><div class="dact"><a class="btn btn-main btn-sm" href="/cenik">Zobrazit ceník</a><button class="btn btn-ghost btn-sm" type="button" data-app="plan">Změnit tarif</button></div><p class="mut fine">Platební brána zatím není připojená. Žádost o vyšší tarif vyřídíme ručně.</p></div>'}
function errBox(x){return x.err?'<div class="draft">Data se nepodařilo načíst: '+esc(x.err)+'</div>':''}
function soonView(t){var s=SOON[t];return '<div class="card2 soonc"><span class="eyebrow">Etapa '+s[2]+' · připravujeme</span><h2>'+esc(s[0])+'</h2><p>'+esc(s[1])+'</p><div class="draft">Tento modul zatím není hotový ani připojený. Nic zde neukládáme ani nepředstíráme. Ozveme se, až bude k dispozici.</div></div>'}

/* ---- notifikace z reálných dat ---- */
function notes(){
 var d=APP.d,n=[],now=new Date(),t0=dayStart(0),t1=dayStart(1),t2=dayStart(2);
 d.tasks.rows.forEach(function(x){if(x.completed||!x.due_at)return;var s=new Date(x.due_at);if(s<t0)n.push(['bad','Úkol po termínu: '+x.title,'ukoly']);else if(s<t1)n.push(['warn','Úkol na dnes: '+x.title,'ukoly'])});
 d.reservations.rows.forEach(function(x){if(x.canceled)return;var s=new Date(x.starts_at);if(s>=now&&s<t2)n.push(['info','Rezervace '+(s<t1?'dnes':'zítra')+' '+fD(x.starts_at,1)+': '+(x.title||''),'kalendar'])});
 d.invoices.rows.forEach(function(x){if(x.paid_at||!x.due_on)return;if(new Date(x.due_on)<t0)n.push(['bad','Faktura po splatnosti: '+(x.number||'')+' ('+fM(x.total,x.currency)+')','faktury'])});
 d.jobs.rows.forEach(function(x){if(!x.due_at||DONE.test(x.status||''))return;var s=new Date(x.due_at);if(s<t0)n.push(['bad','Zakázka po termínu: '+x.title,'zakazky'])});
 if(APP.upd)n.unshift(['info','Je dostupná nová verze Vexaronetu '+APP.upd.version+' (vaše verze: '+VX_VERSION+'). Postup najdete v AKTUALIZACE.md.','profil']);
 return n.slice(0,25)}
function renderBell(){var n=notes(),b=A('appBdg'),p=A('appBell');if(!b)return;b.textContent=n.length>9?'9+':n.length;b.style.display=n.length?'':'none';p.innerHTML='<h4>Notifikace</h4>'+(n.length?n.map(function(x){return '<button type="button" class="nt '+x[0]+'" data-tab="'+x[2]+'">'+esc(x[1])+'</button>'}).join(''):'<p class="mut">Nic zásadního. Vše je v pořádku.</p>')}

/* ---- grafy (SVG, vlastní kód) ---- */
var CHN=0,CHC={b1:['#8aa6ff','#4a68e8'],b2:['#4be3a5','#1fa97a'],b3:['#ff8a9b','#e0455d']};
function chK(v){v=Number(v)||0;var a=Math.abs(v);if(a>=1e6)return (v/1e6).toFixed(a>=1e7?0:1).replace('.',',')+' M';if(a>=1e3)return Math.round(v/1e3)+' tis.';return String(Math.round(v))}
function chNice(mx){if(mx<=0)return [1,1];var e=Math.pow(10,Math.floor(Math.log10(mx))),f=mx/e,nf=f<=1?1:f<=2?2:f<=5?5:10,top=nf*e,st=top/(nf===1?4:nf===2?4:nf===5?5:5);return [top,st]}
function barChart(labels,sa,sb2,na,nb,c1,c2,cmp){c1=CHC[c1]?c1:'b2';c2=CHC[c2]?c2:'b3';var id=++CHN;
 var W=cmp?330:600,H=cmp?280:260,L=cmp?44:54,B=30,T=22,n=Math.max(1,labels.length),mx=Math.max.apply(null,sa.concat(sb2).concat([0])),nc=chNice(mx),top=nc[0],h=H-B-T,gw=(W-L-8)/n,bw=Math.max(8,Math.min(30,gw/2.7)),g='',lbl=n<=7&&!cmp;
 g+='<defs>'+[c1,c2].map(function(c,k){return '<linearGradient id="cg'+id+k+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="'+CHC[c][0]+'"/><stop offset="1" stop-color="'+CHC[c][1]+'"/></linearGradient>'}).join('')+'</defs>';
 for(var v=0;v<=top+1e-9;v+=nc[1]){var y=T+h-h*v/top;g+='<line x1="'+L+'" x2="'+(W-4)+'" y1="'+y+'" y2="'+y+'" class="gl'+(v===0?' gl0':'')+'"/><text x="'+(L-8)+'" y="'+(y+4)+'" text-anchor="end" class="ax">'+chK(v)+'</text>'}
 labels.forEach(function(lb,i){var x=L+gw*i+gw/2,A1=sa[i]||0,B1=sb2[i]||0,ha=Math.max(A1>0?3:0,h*A1/top),hb=Math.max(B1>0?3:0,h*B1/top);
  g+='<g class="cgrp"><rect x="'+(x-gw/2+2)+'" y="'+T+'" width="'+(gw-4)+'" height="'+h+'" class="chov"/>'
   +'<rect class="cbar" style="animation-delay:'+(i*70)+'ms" x="'+(x-bw-1.5)+'" y="'+(T+h-ha)+'" width="'+bw+'" height="'+ha+'" rx="5" fill="url(#cg'+id+'0)"><title>'+esc(lb)+' · '+esc(na)+': '+fM(A1)+'</title></rect>'
   +'<rect class="cbar" style="animation-delay:'+(i*70+40)+'ms" x="'+(x+1.5)+'" y="'+(T+h-hb)+'" width="'+bw+'" height="'+hb+'" rx="5" fill="url(#cg'+id+'1)"><title>'+esc(lb)+' · '+esc(nb)+': '+fM(B1)+'</title></rect>'
   +(lbl&&A1>0?'<text x="'+(x-bw/2-1.5)+'" y="'+(T+h-ha-5)+'" text-anchor="middle" class="cv">'+chK(A1)+'</text>':'')+(lbl&&B1>0?'<text x="'+(x+bw/2+1.5)+'" y="'+(T+h-hb-5)+'" text-anchor="middle" class="cv">'+chK(B1)+'</text>':'')
   +'<text x="'+x+'" y="'+(H-9)+'" text-anchor="middle" class="ax">'+esc(lb)+'</text></g>'});
 var ta=sa.reduce(function(p,q){return p+(q||0)},0),tb=sb2.reduce(function(p,q){return p+(q||0)},0);
 return '<svg viewBox="0 0 '+W+' '+H+'" class="chart" role="img" aria-label="Graf: '+esc(na)+' a '+esc(nb)+' podle měsíců">'+g+'</svg><div class="leg"><span><i style="background:linear-gradient('+CHC[c1][0]+','+CHC[c1][1]+')"></i>'+esc(na)+' <b>'+fM(Math.round(ta))+'</b></span><span><i style="background:linear-gradient('+CHC[c2][0]+','+CHC[c2][1]+')"></i>'+esc(nb)+' <b>'+fM(Math.round(tb))+'</b></span></div>'+((ta+tb)?'':'<p class="mut fine">Za toto období zatím nejsou žádná data.</p>')}
var PAL=['#6e8cff','#a278ff','#3ddc97','#ffb347','#ff6b81','#59c8ff'];
function donut(items,center,sub){
 var tot=items.reduce(function(s,x){return s+x[1]},0);if(!tot)return '<p class="mut">Zatím žádná data.</p>';
 var C=2*Math.PI*52,off=0,seg='';
 items.forEach(function(x,i){var len=C*x[1]/tot,gap=items.length>1?Math.min(3,len/3):0;seg+='<circle class="seg" r="52" cx="70" cy="70" fill="none" stroke="'+PAL[i%PAL.length]+'" stroke-width="20" stroke-dasharray="'+Math.max(0,len-gap)+' '+(C-len+gap)+'" stroke-dashoffset="'+(-off)+'" transform="rotate(-90 70 70)" style="animation-delay:'+(i*120)+'ms"><title>'+esc(x[0])+': '+(x[2]||x[1])+'</title></circle>';off+=len});
 return '<div class="dn"><svg viewBox="0 0 140 140" width="150" height="150" role="img" aria-label="Rozdělení: '+esc(items.map(function(x){return x[0]}).join(', '))+'">'+seg+'<text x="70" y="72" text-anchor="middle" class="dnt">'+(center||tot)+'</text><text x="70" y="88" text-anchor="middle" class="dns">'+esc(sub||'celkem')+'</text></svg><ul class="leg2">'+items.map(function(x,i){return '<li><i style="background:'+PAL[i%PAL.length]+'"></i><span>'+esc(x[0])+'</span> <b>'+(x[2]||x[1])+'</b></li>'}).join('')+'</ul></div>'}
function monthsBack(n){var o=[],d=new Date();d.setDate(1);d.setHours(0,0,0,0);for(var i=n-1;i>=0;i--){var m=new Date(d.getFullYear(),d.getMonth()-i,1);o.push(m)}return o}
function onboard(){
 if(APP.meta.onboarded)return '';
 return '<div class="card2 onb"><h3>Dokončete nastavení firmy</h3><p class="mut">Podle odpovědí vám přizpůsobíme rychlé akce na přehledu.</p><form id="onbForm"><div class="fg"><div class="f"><label for="oC">Stát</label><select id="oC">'+COUNTRIES.map(function(x){return '<option>'+x+'</option>'}).join('')+'</select></div></div><fieldset><legend>Které funkce budete používat?</legend><div class="chks">'+FEATS.map(function(f){return '<label class="chk"><input type="checkbox" name="ft" value="'+f[0]+'"><span>'+f[1]+'</span></label>'}).join('')+'</div></fieldset><button class="btn btn-main btn-sm" type="submit">Uložit nastavení</button></form></div>'}
function plural(n,a,b,c){return n===1?a:(n>=2&&n<=4?b:c)}
function mkey(d){return d.getFullYear()*12+d.getMonth()}
function finSeries(ms){
 var rows=APP.d.fe&&APP.d.fe.rows||[],inc=ms.map(function(){return 0}),exp=inc.slice(),src='faktury';
 if(rows.length){var k=Object.keys(rows[0]),pick=function(a){return a.filter(function(x){return k.indexOf(x)>=0})[0]},am=pick(['amount','total','value','amount_czk']),dt=pick(['entry_date','occurred_on','booked_on','date','paid_at','issued_on','created_at']),ty=pick(['type','kind','direction','entry_type']);
  if(am&&dt&&ty){var ok=false;rows.forEach(function(r){var d=new Date(r[dt]);if(isNaN(d))return;var i=ms.map(function(m){return mkey(m)}).indexOf(mkey(d));if(i<0)return;var v=Math.abs(Number(r[am])||0),t=String(r[ty]);
    if(/inc|přij|prij|^in$|revenue|výnos/i.test(t)){inc[i]+=v;ok=true}else if(/exp|výd|vyd|out|cost|náklad/i.test(t)){exp[i]+=v;ok=true}});
   if(ok)return {inc:inc,exp:exp,src:'záznamy financí'}}}
 APP.d.invoices.rows.forEach(function(x){if(!x.paid_at)return;var d=new Date(x.paid_at),i=ms.map(function(m){return mkey(m)}).indexOf(mkey(d));if(i>=0)inc[i]+=Number(x.total||0)});
 return {inc:inc,exp:exp,src:'zaplacené faktury (výdaje zatím nejsou k dispozici)'}}
function trend(cur,prev){if(!prev)return '';var p=Math.round((cur-prev)/prev*100);return '<em class="'+(p>=0?'up':'dn2')+'">'+(p>=0?'↗ +':'↘ ')+p+' %</em>'}
function spark(a,cls){var m=Math.max.apply(null,a.concat([1]));return '<span class="spk">'+a.map(function(v,i){return '<i class="'+cls+'" style="height:'+Math.max(8,Math.round(v/m*100))+'%;animation-delay:'+(i*60)+'ms"></i>'}).join('')+'</span>'}
function byMonth(rows,f,ms){var o=ms.map(function(){return 0}),keys=ms.map(function(m){return mkey(m)});rows.forEach(function(r){var d=f(r);if(!d)return;d=new Date(d);if(isNaN(d))return;var i=keys.indexOf(mkey(d));if(i>=0)o[i]+=(r.__v==null?1:r.__v)});return o}
function recs(){
 var d=APP.d,s=summary(),R=[],t0=dayStart(0);
 var over=d.invoices.rows.filter(function(x){return !x.paid_at&&x.due_on&&new Date(x.due_on)<t0}),osum=over.reduce(function(a,x){return a+Number(x.total||0)},0);
 if(over.length)R.push({c:'bad',ic:'warn',t:over.length+' '+plural(over.length,'faktura','faktury','faktur')+' po splatnosti',x:'Celkem '+fM(osum)+'. Mohu připravit texty upomínek a úkoly k urgenci.',go:'faktury',act:'reminders',lab:'Připravit upomínky'});
 var oj=d.jobs.rows.filter(function(x){return x.due_at&&!DONE.test(x.status||'')&&new Date(x.due_at)<t0});
 if(oj.length)R.push({c:'blue',ic:'zakazky',t:oj.length+' '+plural(oj.length,'zakázka','zakázky','zakázek')+' po termínu',x:'Doporučuji kontaktovat zákazníky a domluvit nový termín. Mohu vytvořit úkoly.',go:'zakazky',act:'jobtasks',lab:'Vytvořit úkoly'});
 if(s.vydaje_kc>s.prijmy_kc&&s.vydaje_kc>0)R.push({c:'warn',ic:'warn',t:'Výdaje převyšují příjmy',x:'Rozdíl '+fM(s.vydaje_kc-s.prijmy_kc)+' podle údajů v databázi. Zkontrolujte výdaje a nezaplacené pohledávky ('+fM(s.pohledavky_kc)+'). Přesnou předpověď cash flow umožní až modul Finance.',go:'faktury',act:null});
 else if(s.pohledavky_kc>0&&!over.length)R.push({c:'warn',ic:'faktury',t:'Nezaplacené pohledávky '+fM(s.pohledavky_kc),x:'Žádná není po splatnosti. Hlídejte data splatnosti.',go:'faktury',act:null});
 var withJob={};d.jobs.rows.forEach(function(j){if(j.customer_id)withJob[j.customer_id]=1});
 var idle=d.customers.rows.filter(function(x){return !withJob[x.id]});
 if(idle.length)R.push({c:'ok',ic:'tr',t:'Příležitost k růstu',x:idle.length+' '+plural(idle.length,'zákazník nemá','zákazníci nemají','zákazníků nemá')+' žádnou zakázku. Zvažte nabídnout jim službu.',go:'zakaznici',act:'offer',lab:'Připravit nabídku'});
 if(s.ukoly_po_terminu)R.push({c:'warn',ic:'ukoly',t:s.ukoly_po_terminu+' '+plural(s.ukoly_po_terminu,'úkol','úkoly','úkolů')+' po termínu',x:'Projděte úkoly a dokončete nebo přesuňte termíny.',go:'ukoly',act:null});
 if(!d.customers.rows.length)R.push({c:'blue',ic:'zakaznici',t:'Začněte prvním zákazníkem',x:'Po přidání zákazníků a zakázek bude AI CEO doporučovat konkrétnější kroky.',go:'zakaznici',act:null});
 try{var M=ceoModel(),g=goalKc();
  if(M.top.share>=.4&&M.k>=2&&M.C[4].v!=null)R.push({c:'warn',ic:'tr',t:'Příliš velká závislost na jednom zákazníkovi',x:(M.top.name||'Jeden zákazník')+' tvoří '+Math.round(M.top.share*100)+' % vaší fakturace za 12 měsíců. Pomohlo by získat další zákazníky, aby výpadek jednoho nebyl problém.',go:'zakaznici',act:'grow',lab:'Poradit, jak růst'});
  var l90=new Date(dayStart(0).getTime()-90*864e5),last={};d.jobs.rows.forEach(function(j){var q=new Date(j.due_at||j.created_at);if(j.customer_id&&!isNaN(q)&&(!last[j.customer_id]||q>last[j.customer_id]))last[j.customer_id]=q});
  var sleep=d.customers.rows.filter(function(c){return last[c.id]&&last[c.id]<l90});
  if(sleep.length)R.push({c:'blue',ic:'zakaznici',t:sleep.length+' '+plural(sleep.length,'zákazník','zákazníci','zákazníků')+' se neozval 90 dní',x:'Dřívější zákazníci, kteří u vás delší dobu nic neobjednali: '+sleep.slice(0,3).map(function(c){return custName(c)}).join(', ')+(sleep.length>3?' a další':'')+'. Připomenutí bývá nejlevnější cesta k další zakázce.',go:'zakaznici',act:'winback',lab:'Připravit připomenutí'});
  var doneNoInv=d.jobs.rows.filter(function(j){return DONE.test(j.status||'')&&!/cancel|zruš/i.test(j.status||'')&&j.customer_id&&new Date(j.due_at||j.created_at)>=new Date(dayStart(0).getTime()-45*864e5)});
  var invC={},invN={};d.invoices.rows.forEach(function(x){var cu=x.customer_snapshot,nm=cu&&typeof cu==='object'?(cu.name||cu.company_name):'';if(nm&&x.issued_on&&new Date(x.issued_on)>=new Date(dayStart(0).getTime()-45*864e5))invN[String(nm).toLowerCase()]=1;if(x.customer_id&&x.issued_on&&new Date(x.issued_on)>=new Date(dayStart(0).getTime()-45*864e5))invC[x.customer_id]=1});
  var cn0={};d.customers.rows.forEach(function(c){cn0[c.id]=String(custName(c)).toLowerCase()});var nf=d.invoices.rows.length?doneNoInv.filter(function(j){return !invC[j.customer_id]&&!invN[cn0[j.customer_id]]}):[];
  if(nf.length)R.push({c:'warn',ic:'faktury',t:nf.length+' '+plural(nf.length,'hotová zakázka','hotové zakázky','hotových zakázek')+' bez nové faktury',x:'U těchto zákazníků jsme za posledních 45 dní nenašli vystavenou fakturu: '+nf.slice(0,3).map(function(j){return j.title}).join(', ')+'. Ověřte, že nezapomínáte fakturovat (mohlo jít o zálohu nebo platbu jinde).',go:'faktury',act:null});
  var f12=teRows().filter(function(x){return !x.ended_at&&(Date.now()-new Date(x.started_at))>12*36e5});
  if(f12.length&&APP.role!=='employee')R.push({c:'warn',ic:'zamestnanci',t:f12.length+' '+plural(f12.length,'směna běží','směny běží','směn běží')+' déle než 12 hodin',x:'Zaměstnanec se možná zapomněl odhlásit. Zkontrolujte docházku, aby se nezkreslily odpracované hodiny.',go:'zamestnanci',act:null});
  if(g){var now=new Date(),dm=new Date(now.getFullYear(),now.getMonth()+1,0).getDate(),dn=now.getDate(),cur=s.fakturovano_tento_mesic_kc,ex=g*dn/dm;
   if(dn>=10&&cur<ex*.7)R.push({c:'warn',ic:'tr',t:'Měsíční cíl je ohrožen',x:'Fakturováno '+fM(cur)+' z cíle '+fM(g)+'. K dnešku by mělo být zhruba '+fM(Math.round(ex))+'. Zvažte vystavit hotové faktury nebo oslovit zákazníky.',go:'prehled',act:'grow',lab:'Poradit, jak růst'});
   else if(cur>=g)R.push({c:'ok',ic:'tr',t:'Měsíční cíl splněn',x:'Fakturováno '+fM(cur)+' z cíle '+fM(g)+'. Dobrá práce.',go:null,act:null})}
 }catch(e){}
 if(!R.length)R.push({c:'ok',ic:'ukoly',t:'Vše je v pořádku',x:'Žádné faktury ani zakázky po termínu.',go:null,act:null});
 return R}
function summary(){
 var d=APP.d,now=new Date(),t0=dayStart(0),t8=dayStart(7),ms=new Date(now.getFullYear(),now.getMonth(),1);
 var unpaid=d.invoices.rows.filter(function(x){return !x.paid_at}),over=unpaid.filter(function(x){return x.due_on&&new Date(x.due_on)<t0});
 var open=d.tasks.rows.filter(function(x){return !x.completed});
 return {firma:APP.co,obor:APP.ind,zeme:APP.meta.country||'',zakaznici:d.customers.rows.length,zakazky_celkem:d.jobs.rows.length,zakazky_aktivni:d.jobs.rows.filter(function(x){return !DONE.test(x.status||'')}).length,
  zakazky_po_terminu:d.jobs.rows.filter(function(x){return x.due_at&&!DONE.test(x.status||'')&&new Date(x.due_at)<t0}).length,
  ukoly_otevrene:open.length,ukoly_po_terminu:open.filter(function(x){return x.due_at&&new Date(x.due_at)<t0}).length,
  rezervace_dnes:d.reservations.rows.filter(function(x){var s=new Date(x.starts_at);return !x.canceled&&s>=t0&&s<dayStart(1)}).length,
  rezervace_7_dni:d.reservations.rows.filter(function(x){var s=new Date(x.starts_at);return !x.canceled&&s>=t0&&s<t8}).length,
  faktury_nezaplacene:unpaid.length,pohledavky_kc:unpaid.reduce(function(s,x){return s+Number(x.total||0)},0),faktury_po_splatnosti:over.length,
  fakturovano_tento_mesic_kc:d.invoices.rows.filter(function(x){return x.issued_on&&new Date(x.issued_on)>=ms}).reduce(function(s,x){return s+Number(x.total||0)},0),
  prijmy_kc:d.ds.income,vydaje_kc:d.ds.expenses,skore_zdravi_firmy:(function(){try{var m=ceoModel();return m.score==null?'malo_dat':m.score}catch(e){return 'neznamo'}})(),cil_mesic_kc:goalKc(),
  zakaznik_nejvetsi_podil_pct:(function(){try{return Math.round(ceoModel().top.share*100)}catch(e){return 0}})(),neaktivni_zakaznici_90d:(function(){try{var l=new Date(dayStart(0).getTime()-90*864e5),r={};d.jobs.rows.forEach(function(j){var q=new Date(j.due_at||j.created_at);if(j.customer_id&&!isNaN(q)&&q>=l)r[j.customer_id]=1});return d.customers.rows.filter(function(c){return !r[c.id]}).length}catch(e){return 0}})(),
  obor_profil:prof().ai||'',odpracovane_hodiny_7dni:(function(){try{var f=new Date(dayStart(0).getTime()-7*864e5),h=0;teRows().forEach(function(x){if(new Date(x.started_at)<f)return;h+=Math.max(0,((x.ended_at?new Date(x.ended_at):new Date())-new Date(x.started_at))/36e5)});return Math.round(h*10)/10}catch(e){return 0}})()}}
function goalKc(){var g=Number(APP.meta&&APP.meta.goal_kc);if(g>0)return g;try{g=Number(localStorage.getItem('vxgoal_'+APP.cid));if(g>0)return g}catch(e){}return 0}
function ceoModel(){
 var d=APP.d,t0=dayStart(0),now=new Date(),D=86400000,custKey=function(x){var cu=x.customer_snapshot,nm=cu&&typeof cu==='object'?(cu.name||cu.company_name):'';return x.customer_id||nm||''};
 var inv=d.invoices.rows,unpaid=inv.filter(function(x){return !x.paid_at}),over=unpaid.filter(function(x){return x.due_on&&new Date(x.due_on)<t0});
 var sum=function(a){return a.reduce(function(s,x){return s+Number(x.total||0)},0)};
 var lim180=new Date(t0.getTime()-180*D),inv180=inv.filter(function(x){return x.issued_on&&new Date(x.issued_on)>=lim180});
 var C=[];
 // 1 platby
 var base=sum(inv180);C.push({k:'Platby od zákazníků',w:25,v:inv180.length&&base>0?Math.max(0,100-Math.min(100,Math.round(sum(over)/base*250))):null,n:over.length?over.length+' '+plural(over.length,'faktura','faktury','faktur')+' po splatnosti ('+fM(sum(over))+')':'Nic po splatnosti'});
 // 2 zakázky
 var act=d.jobs.rows.filter(function(x){return !DONE.test(x.status||'')}),oj=act.filter(function(x){return x.due_at&&new Date(x.due_at)<t0});
 C.push({k:'Zakázky v termínu',w:20,v:d.jobs.rows.length?(act.length?Math.max(0,100-Math.round(oj.length/act.length*100)):100):null,n:oj.length?oj.length+' z '+act.length+' aktivních po termínu':(act.length?'Aktivní zakázky jsou v termínu':'Žádná aktivní zakázka')});
 // 3 úkoly
 var ot=d.tasks.rows.filter(function(x){return !x.completed}),ov=ot.filter(function(x){return x.due_at&&new Date(x.due_at)<t0});
 C.push({k:'Úkoly pod kontrolou',w:10,v:ot.length?Math.max(0,100-Math.round(ov.length/ot.length*100)):null,n:ot.length?(ov.length?ov.length+' z '+ot.length+' po termínu':'Žádný otevřený úkol po termínu'):'Žádné otevřené úkoly'});
 // 4 aktivita zákazníků
 var l90=new Date(t0.getTime()-90*D),recent={};d.jobs.rows.forEach(function(j){var dt=new Date(j.due_at||j.created_at);if(j.customer_id&&!isNaN(dt)&&dt>=l90)recent[j.customer_id]=1});
 var nc=d.customers.rows.length,na=d.customers.rows.filter(function(c){return recent[c.id]}).length;
 C.push({k:'Aktivní zákazníci (90 dní)',w:15,v:nc?Math.round(na/nc*100):null,n:nc?na+' z '+nc+' zákazníků má zakázku za 90 dní':'Zatím žádní zákazníci'});
 // 5 koncentrace
 var by={},tot=0,l365=new Date(t0.getTime()-365*D);inv.forEach(function(x){if(!x.issued_on||new Date(x.issued_on)<l365)return;var k=custKey(x)||'?',v=Number(x.total||0);by[k]=(by[k]||0)+v;tot+=v});
 var ks=Object.keys(by).sort(function(a,b){return by[b]-by[a]}),top=ks.length?by[ks[0]]/tot:0,topName=ks.length?(function(){var c=d.customers.rows.filter(function(q){return q.id===ks[0]})[0];return c?custName(c):ks[0]})():'';
 C.push({k:'Rozložení tržeb',w:10,v:ks.length>=2&&tot>0?Math.max(0,Math.min(100,Math.round(100-Math.max(0,top*100-30)*1.5))):null,n:ks.length>=2&&tot>0?'Největší zákazník tvoří '+Math.round(top*100)+' % fakturace':'Málo faktur na vyhodnocení'});
 // 6 trend
 var ms=monthsBack(6),fs=finSeries(ms),a3=fs.inc.slice(3).reduce(function(p,q){return p+q},0),b3=fs.inc.slice(0,3).reduce(function(p,q){return p+q},0),pc=b3>0?Math.round((a3-b3)/b3*100):null;
 C.push({k:'Vývoj příjmů',w:20,v:pc==null?null:Math.max(0,Math.min(100,50+Math.round(pc/2))),n:pc==null?'Chybí údaje za předchozí období':'Posledních 3 měsíce '+(pc>=0?'+':'')+pc+' % proti předchozím 3'});
 var W=0,S=0,k=0;C.forEach(function(c){if(c.v!=null){W+=c.w;S+=c.v*c.w;k++}});
 var score=k>=2?Math.round(S/W):null;
 return {C:C,score:score,k:k,top:{name:topName,share:top},ms:ms,fs:fs,over:over,oj:oj}}
function scoreLab(s){return s==null?'Málo dat':(s>=75?'Dobrá kondice':(s>=50?'Ke zlepšení':'Potřebuje pozornost'))}
function scoreCls(s){return s==null?'':(s>=75?'g':(s>=50?'o':'r'))}
function healthHtml(){
 var M=ceoModel(),s=M.score,R=34,Cc=2*Math.PI*R;
 var ring='<svg viewBox="0 0 80 80" width="96" height="96" class="hring '+scoreCls(s)+'" role="img" aria-label="Zdraví firmy: '+(s==null?'málo dat':s+' ze 100')+'"><circle cx="40" cy="40" r="'+R+'" class="hr0"/><circle cx="40" cy="40" r="'+R+'" class="hr1" stroke-dasharray="'+(s==null?0:Cc*s/100)+' '+Cc+'" transform="rotate(-90 40 40)"/><text x="40" y="46" text-anchor="middle" class="hrt">'+(s==null?'–':s)+'</text></svg>';
 return '<div class="hlt"><div class="hlt-h">'+ring+'<div><h3>Zdraví firmy</h3><b class="hlab '+scoreCls(s)+'">'+scoreLab(s)+'</b><p class="mut fine">Orientační ukazatel z vašich dat v aplikaci, ne účetní ani právní hodnocení. Nezahrnuje údaje, které Vexaronet nezná.</p></div></div>'
  +'<ul class="hbars">'+M.C.map(function(c){return '<li><div><b>'+c.k+'</b><small>'+esc(c.n)+'</small></div>'+(c.v==null?'<span class="mut fine">málo dat</span>':'<span class="hb"><i class="'+scoreCls(c.v)+'" style="width:'+c.v+'%"></i></span><em>'+c.v+'</em>')+'</li>'}).join('')+'</ul></div>'}
function outlook(){
 var d=APP.d,t0=dayStart(0),D=86400000,wk=[0,0,0,0,0],lab=['Po splatnosti','1. týden','2. týden','3. týden','4. týden'];
 d.invoices.rows.forEach(function(x){if(x.paid_at)return;var du=x.due_on?new Date(x.due_on):null;if(!du||isNaN(du))return;var dd=Math.floor((du-t0)/D),v=Number(x.total||0);if(dd<0)wk[0]+=v;else if(dd<30)wk[1+Math.floor(dd/7.5)]+=v});
 var ms=monthsBack(4),fs=finSeries(ms),ex=fs.exp.slice(0,3).reduce(function(p,q){return p+q},0)/3,has=ex>0,out=[0,ex/4,ex/4,ex/4,ex/4].map(function(v){return Math.round(v)});
 var tin=wk.reduce(function(p,q){return p+q},0);
 if(!tin&&!has)return '<p class="mut">Pro výhled zatím chybí nezaplacené faktury s termínem splatnosti ani záznamy výdajů.</p>';
 return barChart(lab,wk.map(Math.round),out,'Očekávané platby','Průměrné výdaje','b2','b3',true)+'<p class="mut fine">Orientační výhled na 30 dní: faktury podle data splatnosti (platba může přijít později) a průměr výdajů za poslední 3 měsíce '+(has?'ze záznamů financí':'— výdaje zatím nejsou k dispozici')+'. Neznáme zůstatek na účtu, proto nejde o předpověď stavu peněz.</p>'}
function goalHtml(){
 var g=goalKc(),now=new Date(),dm=new Date(now.getFullYear(),now.getMonth()+1,0).getDate(),dn=now.getDate(),ms=new Date(now.getFullYear(),now.getMonth(),1);
 var cur=APP.d.invoices.rows.filter(function(x){return x.issued_on&&new Date(x.issued_on)>=ms}).reduce(function(s,x){return s+Number(x.total||0)},0);
 var h='<form class="goalf" id="goalForm"><label for="goalIn">Měsíční cíl fakturace (Kč)</label><div class="goalr"><input id="goalIn" type="number" min="0" step="1000" inputmode="numeric" value="'+(g||'')+'" placeholder="např. 150000"><button class="btn btn-ghost btn-sm" type="submit">Uložit cíl</button></div></form>';
 if(!g)return h+'<p class="mut fine">Nastavte si cíl a AI CEO bude hlídat, jestli ho stíháte.</p>';
 var pct=Math.min(100,Math.round(cur/g*100)),exp=Math.round(g*dn/dm),fc=Math.round(cur/dn*dm),ok=cur>=exp;
 return h+'<div class="goalb"><span class="hb"><i class="'+(ok?'g':'o')+'" style="width:'+pct+'%"></i><u style="left:'+Math.round(dn/dm*100)+'%" title="Kde byste měli být dnes"></u></span><div class="goalt"><b>'+fM(cur)+'</b> z '+fM(g)+' ('+pct+' %)</div></div><p class="mut fine">'+(ok?'Jste v plánu.':'K dnešnímu dni je potřeba kolem '+fM(exp)+', chybí '+fM(exp-cur)+'.')+' Při stejném tempu skončíte měsíc zhruba na '+fM(fc)+' (hrubý odhad, počítá se fakturovanými částkami).</p>'}
function weekFacts(){
 var d=APP.d,t0=dayStart(0),from=new Date(t0.getTime()-7*86400000),inR=function(v){if(!v)return false;var x=new Date(v);return !isNaN(x)&&x>=from};
 var s=summary(),M=ceoModel(),iss=d.invoices.rows.filter(function(x){return inR(x.issued_on)}),paid=d.invoices.rows.filter(function(x){return inR(x.paid_at)});
 var sm=function(a){return a.reduce(function(p,x){return p+Number(x.total||0)},0)};
 var hrs=0;teRows().forEach(function(x){if(!inR(x.started_at))return;var e=x.ended_at?new Date(x.ended_at):new Date();hrs+=Math.max(0,(e-new Date(x.started_at))/36e5)});
 var L=['Období: posledních 7 dní','Nových zákazníků: '+d.customers.rows.filter(function(x){return inR(x.created_at)}).length,'Nových zakázek: '+d.jobs.rows.filter(function(x){return inR(x.created_at)}).length,'Vystavených faktur: '+iss.length+' za '+fM(sm(iss)),'Uhrazených faktur: '+paid.length+' za '+fM(sm(paid)),'Nezaplacené pohledávky celkem: '+fM(s.pohledavky_kc)+(s.faktury_po_splatnosti?', z toho po splatnosti '+s.faktury_po_splatnosti+' '+plural(s.faktury_po_splatnosti,'faktura','faktury','faktur'):''),'Zakázky aktivní: '+s.zakazky_aktivni+', po termínu: '+s.zakazky_po_terminu,'Úkoly otevřené: '+s.ukoly_otevrene+', po termínu: '+s.ukoly_po_terminu];
 if(hrs>0)L.push('Odpracované hodiny týmu: '+(Math.round(hrs*10)/10).toLocaleString('cs-CZ')+' h');
 L.push('Zdraví firmy (orientačně): '+(M.score==null?'málo dat':M.score+' ze 100 – '+scoreLab(M.score)));
 var g=goalKc();if(g)L.push('Cíl měsíce: '+fM(g)+', fakturováno '+fM(s.fakturovano_tento_mesic_kc));
 var rr=recs().filter(function(r){return r.c!=='ok'}).slice(0,3);if(rr.length)L.push('Na co dát pozor: '+rr.map(function(r){return r.t}).join('; '));
 return L}
function ceoPanel(){if(!hasCeo())return '<div class="ceop"><h3>Váš AI CEO</h3><p class="mut">AI CEO není součástí tarifu '+esc(PLANN[effPlan()]||'')+'. Je ve Vexaronet PRO a vyšších.</p></div>';
 var Q=[['Připravit přehled financí','Připrav stručný přehled financí mé firmy podle čísel.'],['Zkontrolovat zakázky','Zkontroluj stav zakázek a termínů a řekni, co hoří.'],['Navrhnout nabídku','Připrav krátkou obchodní nabídku pro stávající zákazníky mé firmy.'],['Najít nové zákazníky','Navrhni 3 způsoby, jak získat nové zákazníky pro můj obor.'],['Navrhnout marketing','Doporuč jednoduchou marketingovou kampaň pro můj obor.']];
 return '<div class="ceop"><div class="orb" aria-hidden="true"><svg viewBox="0 0 64 64" width="64" height="64"><defs><linearGradient id="og" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stop-color="#7fa0ff"/><stop offset="1" stop-color="#b07cff"/></linearGradient></defs><circle cx="32" cy="32" r="30" fill="url(#og)" opacity=".25"/><path d="M16 20l16 26 16-26" fill="none" stroke="url(#og)" stroke-width="6" stroke-linejoin="round" stroke-linecap="round"/></svg></div><h3>Váš AI CEO</h3><p class="mut">Analyzuje data vaší firmy, hlídá důležité věci a radí. Důležité kroky provede až po vašem potvrzení.</p><div class="chatl" id="ceoLog">'+ceoMsgs()+'</div><div class="qp">'+ceoQs().map(function(q,i){return '<button type="button" data-q="'+i+'">'+esc(q[0])+'</button>'}).join('')+'</div><form class="aif" id="ceoForm"><input id="ceoIn" placeholder="Napište mi, co potřebujete…" maxlength="500" autocomplete="off" aria-label="Zpráva pro AI CEO"><button class="sendb" type="submit" aria-label="Odeslat">'+ico('send')+'</button></form></div>'}
var CEOQ=[['Připravit přehled financí','Připrav stručný přehled financí mé firmy podle čísel.'],['Zkontrolovat zakázky','Zkontroluj stav zakázek a termínů a řekni, co hoří.'],['Navrhnout nabídku','Připrav krátkou obchodní nabídku pro stávající zákazníky mé firmy.'],['Najít nové zákazníky','Navrhni 3 způsoby, jak získat nové zákazníky pro můj obor.'],['Navrhnout marketing','Doporuč jednoduchou marketingovou kampaň pro můj obor.']];
function ceoMsgs(){return (APP.chat.length?APP.chat:[{role:'assistant',content:'Dobrý den. Co pro vás mohu dnes udělat? Zeptejte se na finance, zakázky nebo zákazníky.'}]).map(function(m){return '<div class="msg '+(m.role==='user'?'me':'bot')+'">'+esc(m.content)+'</div>'}).join('')}
async function ceoAsk(q){
 if(!hasCeo()){toast('AI CEO je součástí tarifu Vexaronet PRO a vyšších.','err');return}
 if(APP.busy)return;APP.busy=true;APP.chat.push({role:'user',content:q});
 ['ceoLog'].forEach(function(id){var lg=A(id);if(lg){lg.innerHTML=ceoMsgs()+'<div class="msg bot" id="aiWait">Píšu odpověď…</div>';lg.scrollTop=lg.scrollHeight}});
 var rep=await askAI(APP.chat.slice(-10),function(t){var w=A('aiWait');if(w)w.textContent=t});
 if(rep)APP.chat.push({role:'assistant',content:rep});else APP.chat.pop();
 APP.busy=false;var lg=A('ceoLog');if(lg){lg.innerHTML=ceoMsgs();if(!rep)lg.insertAdjacentHTML('beforeend','<div class="msg bot err">AI CEO teď není dostupný. Zkuste to později.</div>');lg.scrollTop=lg.scrollHeight}}
function greet(){var h=new Date().getHours(),n=LOCAL?'':(APP.meta.full_name||'').trim().split(/\s+/)[0]||'';return (h<10?'Dobré ráno':(h<18?'Dobrý den':'Dobrý večer'))+(n?', '+esc(n):'')+'!'}
function tile2(c,ic,l,v,sub,go,extra){if(go&&off(go))go=null;return '<'+(go?'button type="button" data-tab="'+go+'"':'div')+' class="kpi"><span class="ki '+c+'">'+ico(ic,22)+'</span><div class="kt"><small>'+l+'</small><b>'+v+'</b></div><div class="ks">'+(sub||'')+'</div>'+(extra||'')+'</'+(go?'button':'div')+'>'}
function events(){
 var d=APP.d,now=new Date(),E=[];
 d.reservations.rows.forEach(function(r){if(!r.canceled&&new Date(r.ends_at||r.starts_at)>=now)E.push([new Date(r.starts_at),r.title||'Rezervace','kalendar','calendar'])});
 d.tasks.rows.forEach(function(r){if(!r.completed&&r.due_at&&new Date(r.due_at)>=dayStart(0))E.push([new Date(r.due_at),'Úkol: '+r.title,'ukoly','ukoly'])});
 d.jobs.rows.forEach(function(r){if(r.due_at&&!DONE.test(r.status||'')&&new Date(r.due_at)>=dayStart(0))E.push([new Date(r.due_at),'Termín zakázky: '+r.title,'zakazky','zakazky'])});
 return E.sort(function(a,b){return a[0]-b[0]}).slice(0,4)}
function dayLbl(d){var a=dayStart(0),k=Math.round((new Date(d.getFullYear(),d.getMonth(),d.getDate())-a)/864e5);return k===0?'Dnes':(k===1?'Zítra':d.toLocaleDateString('cs-CZ',{day:'numeric',month:'numeric'}))}

/* ---- dnes ve firmě, ranní přehled, pobočky ---- */
function todayData(){
 var d=APP.d,t0=dayStart(0),t1=dayStart(1),o={tasks:[],late:[],res:[],jobs:[],inv:[]};
 d.tasks.rows.forEach(function(x){if(x.completed||!x.due_at)return;var s=new Date(x.due_at);if(s<t0)o.late.push('Úkol po termínu: '+x.title);else if(s<t1)o.tasks.push('Úkol: '+x.title)});
 d.reservations.rows.forEach(function(x){if(x.canceled)return;var s=new Date(x.starts_at);if(s>=t0&&s<t1)o.res.push([s,hmm(x.starts_at)+' '+(x.title||'Rezervace')+(x.location_id&&locName(x.location_id)?' ('+locName(x.location_id)+')':'')])});
 o.res.sort(function(a,b){return a[0]-b[0]});o.res=o.res.map(function(x){return x[1]});
 d.jobs.rows.forEach(function(x){if(!x.due_at||DONE.test(x.status||''))return;var s=new Date(x.due_at);if(s<t1)o.jobs.push((s<t0?'Zakázka po termínu: ':'Zakázka s termínem dnes: ')+x.title)});
 d.invoices.rows.forEach(function(x){if(x.paid_at||!x.due_on)return;if(new Date(x.due_on)<t0)o.inv.push('Faktura po splatnosti: '+(x.number||'')+' ('+fM(x.total,x.currency)+')')});
 return o}
function digRow(){var r=(APP.d.digest_settings||{rows:[]}).rows;return r[0]||null}
/* ===== Docházka: online / offline, odpracované hodiny ===== */
function isMg(){return APP.role==='owner'||APP.role==='admin'}
function teRows(){return (APP.d.time_entries&&APP.d.time_entries.rows)||[]}
function teErr(){return APP.d.time_entries&&APP.d.time_entries.err}
function myUid(){return APP.user&&APP.user.id}
function openOf(uid){return teRows().filter(function(x){return x.user_id===uid&&!x.ended_at})[0]||null}
function fH(ms){var m=Math.round(ms/6e4),h=Math.floor(m/60);return h+' h '+('0'+(m%60)).slice(-2)+' min'}
function teMs(x){return Math.max(0,(x.ended_at?new Date(x.ended_at):new Date())-new Date(x.started_at))}
function teSum(uid,from){var t=0;teRows().forEach(function(x){if(x.user_id===uid&&(!from||new Date(x.started_at)>=from))t+=teMs(x)});return t}
function rateOf(uid){var r=((APP.d.rates&&APP.d.rates.rows)||[]).filter(function(x){return x.user_id===uid})[0];return r?Number(r.hourly_rate):null}
function earned(uid,from){var r=rateOf(uid);return r==null?null:teSum(uid,from)/36e5*r}
function monthStart(){var d=new Date();return new Date(d.getFullYear(),d.getMonth(),1)}
function myShiftNow(){var me=[String(APP.user&&APP.user.email||'').toLowerCase(),String(APP.meta&&APP.meta.full_name||'').toLowerCase()].filter(Boolean),now=Date.now(),best=null;
 ((APP.d.shifts&&APP.d.shifts.rows)||[]).forEach(function(x){if(me.indexOf(String(x.person||'').trim().toLowerCase())<0)return;var a=new Date(x.starts_at).getTime(),b=new Date(x.ends_at).getTime();if(b<now||a>now+14*36e5)return;if(!best||a<new Date(best.starts_at).getTime())best=x});return best}
function clockCard(){
 if(teErr())return '<section class="card2" id="clockCard"><h3>Docházka</h3><p class="mut">Docházka zatím není zapnutá. V databázi je potřeba jednou spustit soubor schema_dochazka.sql.</p></section>';
 var uid=myUid(),op=openOf(uid),sh=myShiftNow(),h='<section class="card2 clk" id="clockCard"><div class="bar2"><div><h3>Moje docházka</h3><p class="mut">';
 if(op)h+='<span class="pres on"></span>Jste <b>online</b> od '+hmm(op.started_at)+' (již '+fH(teMs(op))+').';
 else h+='<span class="pres"></span>Jste <b>offline</b>. '+(sh?'Vaše směna: '+fD(sh.starts_at)+', '+hmm(sh.starts_at)+'–'+hmm(sh.ends_at)+'.':'Žádná další směna vám zatím není vyznačená.');
 h+='</p></div>'+(op?'<button type="button" class="btn btn-ghost btn-sm" data-clock="out">Odejít (offline)</button>':'<button type="button" class="pri sm" data-clock="in">'+(sh?'Přijít na směnu (online)':'Přijít do práce (online)')+'</button>')+'</div>'
 +'<ul class="rows"><li><b>Tento měsíc</b><span>'+fH(teSum(uid,monthStart()))+'</span></li><li><b>Celkem odpracováno</b><span>'+fH(teSum(uid))+'</span></li>';
 if(isMg()){var on=teRows().filter(function(x){return !x.ended_at}).map(function(x){return String(x.person||'').split('@')[0]});h+='<li><b>Online teď</b><span>'+(on.length?esc(on.join(', ')):'nikdo')+'</span></li>'}
 return h+'</ul></section>'}
function attHtml(){
 if(teErr())return '<p class="mut">Docházka zatím není zapnutá (schema_dochazka.sql).</p>';
 var mg=isMg(),mo=monthStart(),team=(APP.team||[]).slice(),ids={};team.forEach(function(x){ids[x.user_id]=1});
 teRows().forEach(function(x){if(!ids[x.user_id]){ids[x.user_id]=1;team.push({user_id:x.user_id,email:x.person||'?',role:'employee'})}});
 if(!mg)team=team.filter(function(x){return x.user_id===myUid()});
 var tot=0,tm=0,pay=0,hasPay=false;team.forEach(function(x){tot+=teSum(x.user_id);tm+=teSum(x.user_id,mo);var e=earned(x.user_id,mo);if(e!=null){pay+=e;hasPay=true}});
 var h='<ul class="rows big">'+team.map(function(x){var op=openOf(x.user_id);return '<li><div><b><span class="pres'+(op?' on':'')+'"></span>'+esc(x.email)+(x.user_id===myUid()?' (vy)':'')+'</b><small>'+(op?'Online od '+hmm(op.started_at)+' ('+fH(teMs(op))+')':'Offline')+'</small></div><div class="hh"><b>'+fH(teSum(x.user_id,mo))+'</b><small>tento měsíc</small></div>'+(rateOf(x.user_id)!=null?'<div class="hh"><b>'+fM(Math.round(earned(x.user_id,mo)),'CZK')+'</b><small>výdělek tento měsíc</small></div>':'')+'<div class="hh"><b>'+fH(teSum(x.user_id))+'</b><small>celkem</small></div>'+(mg&&op&&x.user_id!==myUid()?'<button class="btn btn-ghost btn-sm" type="button" data-clock="force" data-uid="'+esc(x.user_id)+'">Ukončit</button>':'')+'</li>'}).join('')+'</ul>';
 if(mg&&team.length>1)h+='<p class="mut fine">Celkem za tým: <b>'+fH(tm)+'</b> tento měsíc, <b>'+fH(tot)+'</b> od začátku evidence'+(hasPay?'. Výdělek týmu tento měsíc: <b>'+fM(Math.round(pay),'CZK')+'</b>':'')+'.</p>';
 if(mg){if(APP.d.rates&&APP.d.rates.err)h+='<p class="mut fine">Hodinové sazby zatím nejsou zapnuté. V databázi je potřeba jednou spustit soubor schema_sazby.sql.</p>';else h+='<h4>Hodinové sazby</h4><p class="mut fine">Zadejte hodinovou sazbu (Kč/h) u zaměstnance. Na konci měsíce uvidíte, kolik si odpracovanými hodinami vydělal. Sazbu vidíte jen vy a zaměstnanec u sebe.</p><ul class="rows">'+team.map(function(x){var v=rateOf(x.user_id);return '<li><div><b>'+esc(x.email)+'</b></div><span><input type="number" min="0" step="any" class="rtin" data-rate="'+esc(x.user_id)+'" value="'+(v==null?'':v)+'" placeholder="Kč/h" aria-label="Hodinová sazba v Kč za hodinu: '+esc(x.email)+'" style="width:96px"> Kč/h</span></li>'}).join('')+'</ul>'}
 var rc=teRows().filter(function(x){return mg||x.user_id===myUid()}).sort(function(a,b){return new Date(b.started_at)-new Date(a.started_at)}).slice(0,10);
 if(rc.length)h+='<h4>Poslední záznamy</h4><ul class="rows">'+rc.map(function(x){return '<li><div><b>'+esc(String(x.person||'').split('@')[0])+'</b><small>'+fD(x.started_at)+', '+hmm(x.started_at)+' – '+(x.ended_at?hmm(x.ended_at):'probíhá')+'</small></div><span>'+fH(teMs(x))+'</span></li>'}).join('')+'</ul>';
 return h}
function repaintClock(){var c=A('clockCard');if(c)c.outerHTML=clockCard();var b=A('attBox');if(b)b.innerHTML=attHtml()}
async function loadAtt(){
 try{if(!APP.team){var T=await getSb().rpc('company_team',{cid:APP.cid});if(T&&T.data)APP.team=T.data}}catch(e){}
 APP.d.time_entries=await qt('time_entries');APP.d.rates=await qt('member_rates');var sh=await qt('shifts');if(!sh.err)APP.d.shifts=sh;repaintClock()}
async function clockDo(kind,uid){
 var c=getSb(),r;
 if(kind==='in'){var sh=myShiftNow();r=await c.rpc('clock_in',{cid:APP.cid,sid:sh?sh.id:null})}
 else r=await c.rpc('clock_out',{cid:APP.cid,target:kind==='force'?uid:null});
 if(r.error){toast(/already|jste online|online/i.test(r.error.message||'')?'Už jste online.':'Docházku se nepodařilo uložit: '+(r.error.message||''),'err');return}
 toast(kind==='in'?'Jste online. Dobrou práci!':(kind==='force'?'Směna ukončena.':'Jste offline. Děkujeme za dnešek.'),'ok');
 APP.d.time_entries=await qt('time_entries');repaintClock()}
function dnesCard(){
 var t=todayData(),n=t.tasks.length+t.late.length+t.res.length+t.jobs.length+t.inv.length,all=t.res.concat(t.tasks,t.jobs,t.late,t.inv),ds=APP.d.digest_settings||{rows:[]},dg=digRow(),on=dg&&dg.enabled;
 var h='<section class="card2" id="dnesCard"><div class="bar2"><div><h3>Dnes ve firmě</h3><p class="mut">'+(n?n+' '+plural(n,'věc','věci','věcí')+' k řešení.':'Na dnešek nemáte nic naplánováno ani po termínu.')+'</p></div><button type="button" class="btn btn-ghost btn-sm" data-app="digmodal">'+(on?'Ranní e-mail: '+esc(String(dg.send_hour).padStart(2,'0'))+':00':'Zapnout ranní e-mail')+'</button></div>';
 h+=all.length?'<ul class="rows">'+all.slice(0,7).map(function(x){return '<li><div><b>'+esc(x)+'</b></div></li>'}).join('')+'</ul>'+(all.length>7?'<p class="mut fine">… a dalších '+(all.length-7)+'.</p>':''):'';
 return h+'</section>'}
function digModal(){
 var ds=APP.d.digest_settings;if(ds&&ds.err){toast('Ranní e-mail vyžaduje dokončit nastavení databáze (SQL schema_prehled_pobocky).','err');return}
 var dg=digRow()||{},hr=dg.send_hour==null?7:dg.send_hour,on=dg.enabled!==false&&!!dg.company_id||(!dg.company_id&&false);
 var opts='';for(var i=5;i<=11;i++)opts+='<option value="'+i+'"'+(i===hr?' selected':'')+'>'+(i<10?'0':'')+i+':00</option>';if(hr<5||hr>11)opts+='<option value="'+hr+'" selected>'+hr+':00</option>';
 modal('<h3>Ranní přehled do e-mailu</h3><p class="mut">Každé ráno vám pošleme e-mail (přijde i na mobil): co je dnes naplánováno, úkoly a zakázky po termínu, faktury po splatnosti a zboží pod minimem. U tarifu PRO a vyšších přidáme krátké shrnutí od AI, vždy jen z vašich dat.</p><div class="fg"><div class="f full"><label class="chk"><input type="checkbox" id="dgOn"'+(dg.company_id&&dg.enabled!==false?' checked':'')+'><span>Posílat mi ranní přehled</span></label></div><div class="f"><label for="dgH">Hodina (český čas)</label><select id="dgH">'+opts+'</select></div><div class="f"><label for="dgE">E-mail (nepovinné)</label><input id="dgE" type="email" placeholder="'+esc(APP.user.email||'')+'" value="'+esc(dg.email||'')+'"></div></div><div class="st" id="entSt" role="status"></div><div class="dact"><button type="button" class="btn btn-main" data-app="digsave">Uložit</button><button type="button" class="btn btn-ghost" data-app="digtest">Poslat zkušební teď</button><button type="button" class="btn btn-ghost" data-app="mclose">Zavřít</button></div><p class="mut fine">Pravidelné odesílání se spouští automaticky ze serveru. Zkušební e-mail pošleme hned.</p>')}
async function digSave(){
 var on=A('dgOn').checked,hr=parseInt(A('dgH').value,10),em=A('dgE').value.trim();
 if(em&&!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)){entMsg('Zadejte platný e-mail.');return}
 var row={company_id:APP.cid,user_id:APP.user.id,enabled:on,send_hour:hr,email:em||null};
 var r=await getSb().from('digest_settings').upsert(row,{onConflict:DEMO?'company_id':'company_id,user_id'});
 if(r.error){entMsg('Nepodařilo se uložit: '+r.error.message);return}
 closeModal();await refresh();appTab(APP.tab);toast(on?'Ranní přehled zapnut.':'Ranní přehled vypnut.','ok')}
async function digTest(){
 var ses=(await getSb().auth.getSession()).data.session;if(!ses){entMsg('Přihlášení vypršelo.');return}
 var em=A('dgE').value.trim();entMsg('Odesílám…');
 try{var r=await dfetch('/api/digest',{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+ses.access_token},body:JSON.stringify({cid:APP.cid,email:em||undefined})});
  var d=await r.json().catch(function(){return {}});
  if(r.ok&&d.ok){closeModal();toast('Zkušební přehled odeslán na '+d.to+'.','ok');return}
  if(d.mail==='not_configured'||r.status===503)entMsg('Odesílání e-mailů zatím není na serveru nastavené.');
  else if(r.status===429)entMsg('Příliš mnoho pokusů. Zkuste to za chvíli.');
  else entMsg('E-mail se nepodařilo odeslat. '+(d.mail||''))}catch(e){entMsg('E-mail se nepodařilo odeslat.')}}
function pobView(){
 var L=APP.d.locations;if(L.err)return '<div class="draft">Pobočky vyžadují dokončit nastavení databáze (SQL schema_prehled_pobocky). Detail: '+esc(L.err)+'</div>';
 var mg=APP.role==='owner'||APP.role==='admin',now=new Date(),d=APP.d,rs=L.rows.slice().sort(function(a,b){return String(a.name).localeCompare(String(b.name),'cs')});
 function st(id){var j=d.jobs.rows.filter(function(x){return x.location_id===id&&!DONE.test(x.status||'')}).length,r=d.reservations.rows.filter(function(x){return x.location_id===id&&!x.canceled&&new Date(x.starts_at)>=now}).length,s=d.shifts.rows.filter(function(x){return x.location_id===id&&new Date(x.starts_at)>=dayStart(0)}).length;return {j:j,r:r,s:s}}
 var h='<div class="card2 note"><b>Pobočky a místa.</b> Zapište provozovny, sklady nebo místa, kde pracujete. Pobočku pak vybíráte u zakázek, rezervací a směn a vidíte, co kde běží. Ranní e-mail ji uvádí u rezervací a zakázek.</div><div class="bar2"><span></span>'+(mg?'<button type="button" class="btn btn-main btn-sm" data-new="locations">+ Nová pobočka</button>':'<span></span>')+'</div>';
 if(!rs.length)return h+'<p class="mut">Zatím žádná pobočka. Přidejte první tlačítkem výše.</p>';
 h+='<div class="two" style="grid-template-columns:repeat(auto-fill,minmax(280px,1fr))">'+rs.map(function(l){var q=st(l.id);return '<section class="card2"'+(mg?' data-edit="locations:'+esc(l.id)+'" style="cursor:pointer"':'')+'><h3>'+esc(l.name)+(l.active===false?' <small class="mut">(mimo provoz)</small>':'')+'</h3><p class="mut">'+esc([l.address,l.city].filter(Boolean).join(', ')||'Adresa neuvedena')+'</p><ul class="rows">'+(l.phone?'<li><b>Telefon</b><span>'+esc(l.phone)+'</span></li>':'')+(l.hours?'<li><b>Otevřeno</b><span>'+esc(l.hours)+'</span></li>':'')+'<li><b>Rozpracované zakázky</b><span>'+q.j+'</span></li><li><b>Nadcházející rezervace</b><span>'+q.r+'</span></li><li><b>Naplánované směny</b><span>'+q.s+'</span></li></ul>'+(l.note?'<p class="mut fine">'+esc(l.note)+'</p>':'')+'</section>'}).join('')+'</div>';
 var un=d.jobs.rows.filter(function(x){return !x.location_id&&!DONE.test(x.status||'')}).length;
 if(un)h+='<p class="mut fine">Zakázky bez přiřazené pobočky: '+un+'.</p>';
 return h}
/*ESHOP*/
/* ===== E-shop: nastavení, objednávky a veřejný obchod ===== */
var SHST={new:'Nová',paid:'Zaplaceno',shipped:'Odesláno',done:'Vyřízeno',canceled:'Zrušeno'};
function shopCfg(){var r=APP.d.shop_settings;return r&&r.rows&&r.rows[0]||null}
function shopUrl(sl){return (location.protocol==='file:'||DEMO?'https://vexaronet.com':location.origin)+'/?s='+sl}
function shopSlugGuess(){return String(APP.co||'obchod').normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,30)||'obchod'}
function shopInvOf(o){return o&&o.invoice_id?APP.d.invoices.rows.filter(function(x){return x.id===o.invoice_id})[0]:null}
function shopView(){
 var S=APP.d.shop_settings,O=APP.d.shop_orders;
 if((S&&S.err)||(O&&O.err))return '<div class="draft">E-shop vyžaduje dokončit nastavení databáze (SQL schema_eshop). Detail: '+esc((S&&S.err)||(O&&O.err))+'</div>';
 var c=shopCfg()||{},sl=c.slug||shopSlugGuess(),vis=APP.d.products.rows.filter(function(p){return p.shop_visible&&p.active!==false&&Number(p.price)>0}),st=skStock();
 var h='<div class="card2 note"><b>E-shop.</b> Zákazník nakoupí na veřejné stránce vašeho obchodu bez registrace. Objednávka se uloží, zboží se hned odepíše ze skladu, založí se zákazník a zakázka a vystaví se faktura s platebními údaji. Platba kartou zatím není připojená: zákazník platí převodem podle faktury a vy ji pak v objednávce označíte jako zaplacenou. Fakturu zákazníkovi zatím posíláte sami, e-mailem se neodesílá automaticky.</div>';
 h+='<section class="card2"><h3>Nastavení obchodu</h3><div id="shopProf"></div><form id="shopForm"><div class="fg">'
  +'<div class="f full"><label class="chk"><input type="checkbox" id="sh_enabled"'+(c.enabled?' checked':'')+'> Obchod je zapnutý (veřejně dostupný na adrese níže)</label></div>'
  +'<div class="f full"><label for="sh_slug">Adresa obchodu <i>*</i></label><input id="sh_slug" required pattern="[a-z0-9\\-]{3,40}" maxlength="40" value="'+esc(sl)+'"><small class="mut">Odkaz: '+esc(shopUrl(sl))+'</small></div>'
  +'<div class="f full"><label for="sh_title">Název obchodu</label><input id="sh_title" maxlength="120" value="'+esc(c.title||APP.co||'')+'"></div>'
  +'<div class="f full"><label for="sh_desc">Krátký popis</label><textarea id="sh_desc" rows="2" maxlength="600">'+esc(c.description||'')+'</textarea></div>'
  +'<div class="f"><label for="sh_mail">Kontaktní e-mail</label><input id="sh_mail" type="email" maxlength="120" value="'+esc(c.contact_email||'')+'"></div>'
  +'<div class="f"><label for="sh_tel">Kontaktní telefon</label><input id="sh_tel" type="tel" maxlength="40" value="'+esc(c.contact_phone||'')+'"></div>'
  +'<div class="f"><label for="sh_fee">Doprava (cena v Kč, 0 = zdarma)</label><input id="sh_fee" type="number" min="0" step="1" value="'+esc(c.shipping_fee==null?0:c.shipping_fee)+'"></div>'
  +(('pickup_enabled' in c)?'<div class="f full"><label class="chk"><input type="checkbox" id="sh_pick"'+(c.pickup_enabled?' checked':'')+'><span>Nabízet osobní odběr zdarma (zákazník si vybere doprava nebo osobní odběr)</span></label></div><div class="f full"><label for="sh_pickt">Osobní odběr: kde a kdy (text pro zákazníka)</label><textarea id="sh_pickt" rows="2" maxlength="400">'+esc(c.pickup_text||'')+'</textarea></div>':'')
  +'<div class="f full"><label for="sh_ship">Doprava a dodání (text pro zákazníka)</label><textarea id="sh_ship" rows="2" maxlength="600" placeholder="Např. Zboží odesíláme do 3 pracovních dnů Zásilkovnou.">'+esc(c.shipping_text||'')+'</textarea></div>'
  +'<div class="f full"><label for="sh_pay">Platba (text pro zákazníka)</label><textarea id="sh_pay" rows="2" maxlength="600" placeholder="Např. Platba bankovním převodem podle faktury. Zboží odešleme po připsání platby.">'+esc(c.payment_text||'')+'</textarea></div>'
  +'</div><div class="st" id="shopSt" role="status"></div><div class="dact"><button class="pri" type="submit">Uložit nastavení</button>'+(c.slug?'<button type="button" class="btn btn-ghost" data-shop="open">Prohlédnout obchod</button><button type="button" class="btn btn-ghost" data-shop="copy">Kopírovat odkaz</button>':'')+'</div></form></section>';
 h+='<section class="card2"><div class="bar2"><h3>Zboží v e-shopu ('+vis.length+')</h3><button type="button" class="btn btn-ghost btn-sm" data-tab="sklad">Otevřít sklad</button></div><p class="mut fine">Zboží se v obchodě zobrazí, když je ve skladu zaškrtnuté „Zobrazit v e-shopu“ a má prodejní cenu. Zákazník vidí jen dostupné množství (nejvýše 50 ks).</p>'
  +(vis.length?'<ul class="rows">'+vis.map(function(p){var q=st[p.id]||0;return '<li data-edit="products:'+esc(p.id)+'"><div><b>'+esc(p.name)+'</b><small>'+(q>0?'skladem '+skN(q)+' '+esc(p.unit||'ks'):'vyprodáno')+'</small></div><span>'+fM(p.price)+'</span></li>'}).join('')+'</ul>':'<p class="mut">Zatím žádné zboží v obchodě. Ve skladu otevřete kartu zboží, vyplňte prodejní cenu a zaškrtněte „Zobrazit v e-shopu“.</p>')+'</section>';
 h+='<section class="card2"><h3>Import objednávek z jiného e-shopu (CSV)</h3><p class="mut fine">Máte e-shop jinde (Shoptet, WooCommerce a další)? Stáhněte z něj export objednávek jako CSV a nahrajte ho sem. Pro každou objednávku se založí zákazník (podle e-mailu), zakázka a faktura na celkovou částku. Položky objednávky se nepřenášejí a sklad se nemění. Nejde o automatické propojení, import spouštíte vy. Před vystavením uvidíte náhled.</p><div class="f full"><label for="eiFile">Export objednávek (CSV)</label><input id="eiFile" type="file" accept=".csv,.txt,text/csv"></div><div class="dact"><button class="pri" type="button" data-ei="load">Načíst a zobrazit náhled</button></div><div class="st" id="eiSt" role="status"></div><div id="eiRes">'+eiView()+'</div></section>';
 var os=(O&&O.rows||[]).slice().sort(function(a,b){return new Date(b.created_at)-new Date(a.created_at)});
 h+='<section class="card2"><h3>Objednávky ('+os.length+')</h3>'+(os.length?'<ul class="rows big">'+os.map(function(o){var iv=shopInvOf(o),b=o.buyer||{};return '<li data-shop="ord:'+esc(o.id)+'"><div><b>č. '+esc(o.order_no)+' · '+esc(b.name||'')+'</b><small>'+fD(o.created_at,1)+(iv&&iv.number?' · faktura '+esc(iv.number):(o.invoice_error?' · faktura se nevystavila':''))+'</small></div><span>'+fM(o.total)+' · <em class="stt">'+esc(SHST[o.status]||o.status)+'</em></span></li>'}).join('')+'</ul>':'<p class="mut">Zatím žádné objednávky.</p>')+'</section>';
 return h}
/* ===== Import objednávek z jiného e-shopu (CSV) ===== */
function eiSt(t,k){var e=A('eiSt');if(e){e.className='st'+(k?' '+k:'');e.textContent=t||''}}
function eiParse(text){
 text=String(text||'').replace(/^﻿/,'');var ls=text.split(/\r?\n/).filter(function(l){return l.trim()});
 if(ls.length<2)return {err:'Soubor je prázdný nebo v něm chybí řádky s objednávkami.'};
 var dl=';',bn=-1;[';',',','\t'].forEach(function(d){var n=bkSplit(ls[0],d).length;if(n>bn){bn=n;dl=d}});
 var H=bkSplit(ls[0],dl).map(bkNorm);
 function find(re,not){for(var i=0;i<H.length;i++)if(re.test(H[i])&&!(not&&not.test(H[i])))return i;return -1}
 function all(re){var o=[];H.forEach(function(h,i){if(re.test(h))o.push(i)});return o}
 var c={no:find(/^(cislo objednavky|c\. objednavky|cislo obj|order number|order id|order no|id objednavky|objednavka|order|cislo|number)$/),
  name:find(/(jmeno a prijmeni|^jmeno$|^name$|^zakaznik$|^customer$|billing name|fakturacni jmeno|billing full name|full name)/),
  fn:find(/^(jmeno|first name|billing first name)$/),ln:find(/^(prijmeni|last name|billing last name)$/),
  mail:find(/e-?mail/),
  total:find(/(celkem|total|castka|amount)/,/(bez dph|excl|tax|doprava|shipping|polozk|item|zbozi)/),
  cur:find(/^(mena|currency)/),date:find(/(datum|date)/)};
 var ad=all(/(ulice|street|address 1|^adresa|billing address)/).concat(all(/(^mesto|city)/),all(/(^psc|zip|postcode|postal)/));
 if(c.name<0&&c.fn<0)return {err:'Nepodařilo se najít sloupec se jménem zákazníka (např. „Jméno a příjmení“ nebo „Jméno“ a „Příjmení“).'};
 if(c.total<0)return {err:'Nepodařilo se najít sloupec s celkovou cenou objednávky (např. „Celkem“ nebo „Total“).'};
 var seen={},rows=[];
 for(var i=1;i<ls.length;i++){var p=bkSplit(ls[i],dl);function g(j){return j>=0&&j<p.length?String(p[j]).trim():''}
  var nm=c.name>=0?g(c.name):[g(c.fn),g(c.ln)].filter(Boolean).join(' '),no=g(c.no)||('r'+i),tt=bkNum(g(c.total)),
   cu=(g(c.cur)||'CZK').toUpperCase().slice(0,3),r={no:no,name:nm,email:g(c.mail).toLowerCase(),addr:ad.map(g).filter(Boolean).join(', '),total:tt,cur:/^(CZK|EUR)$/.test(cu)?cu:'CZK',skip:''};
  if(!nm)r.skip='chybí jméno';else if(!(tt>0))r.skip='chybí kladná částka';else if(r.email&&!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(r.email))r.skip='neplatný e-mail';
  else if(seen[no])r.skip='duplicitní číslo objednávky v souboru';
  else if(APP.d.jobs.rows.some(function(j){return j.title==='E-shop import č. '+no}))r.skip='už naimportováno dříve';
  seen[no]=1;rows.push(r)}
 return {rows:rows,cols:c}}
function eiView(){var E=APP.ei;if(!E||!E.rows)return '';
 var ok=E.rows.filter(function(r){return !r.skip}),sk=E.rows.length-ok.length,sum=ok.reduce(function(a,r){return a+r.total},0);
 return '<div class="draft"><b>Náhled importu.</b> K vystavení: <b>'+ok.length+'</b> faktur, celkem '+fM(sum)+(sk?', přeskočeno '+sk:'')+'. Zatím se nic neuložilo ani nevystavilo.</div>'
 +'<ul class="rows">'+E.rows.slice(0,50).map(function(r){return '<li'+(r.skip?' class="off"':'')+'><div><b>č. '+esc(r.no)+' · '+esc(r.name||'–')+'</b><small>'+esc(r.email||'bez e-mailu')+(r.skip?' · přeskočeno: '+esc(r.skip):'')+'</small></div><span>'+(r.total>0?fM(r.total):'–')+' '+esc(r.cur)+'</span></li>'}).join('')+'</ul>'+(E.rows.length>50?'<p class="mut fine">Zobrazeno prvních 50 z '+E.rows.length+' řádků.</p>':'')
 +(ok.length?'<div class="f"><label for="eiVat">Sazba DPH v cenách objednávek (ceny jsou s DPH)</label><select id="eiVat"><option>21</option><option>12</option><option>0</option></select></div><div class="dact"><button class="pri" type="button" data-ei="run">Vystavit '+ok.length+' faktur</button><button class="btn btn-ghost" type="button" data-ei="clear">Zrušit</button></div>':'<div class="dact"><button class="btn btn-ghost" type="button" data-ei="clear">Zavřít náhled</button></div>')}
async function eiLoad(){var fi=A('eiFile'),f=fi&&fi.files&&fi.files[0];if(!f){eiSt('Vyberte soubor CSV z exportu objednávek.','err');return}
 if(f.size>3e6){eiSt('Soubor je příliš velký (nejvýše 3 MB).','err');return}
 var t;try{t=await f.text()}catch(x){eiSt('Soubor se nepodařilo přečíst.','err');return}
 var r=eiParse(t);if(r.err){eiSt(r.err,'err');return}
 if(r.rows.length>200){eiSt('Soubor má '+r.rows.length+' řádků. Najednou lze naimportovat nejvýše 200 objednávek.','err');return}
 APP.ei=r;eiSt('','');A('eiRes').innerHTML=eiView()}
async function eiRun(){var E=APP.ei;if(!E)return;var ok=E.rows.filter(function(r){return !r.skip});if(!ok.length)return;
 var vat=parseFloat((A('eiVat')||{}).value);if(isNaN(vat))vat=21;
 if(!confirm('Vystavit '+ok.length+' faktur? Každé faktuře se přidělí číslo a vystavenou fakturu už nelze vzít zpět.'))return;
 var done=0,btn=document.querySelector('[data-ei=run]');if(btn)btn.disabled=true;
 for(var i=0;i<ok.length;i++){var o=ok[i],lm=limitMsg('invoices');if(lm){eiSt('Zastaveno po '+done+' fakturách: '+lm,'err');break}
  eiSt('Vystavuji '+(i+1)+' z '+ok.length+' ...','');
  try{var cu=o.email?APP.d.customers.rows.filter(function(x){return String(x.email||'').toLowerCase()===o.email})[0]:null;
   if(!cu){var cr=await getSb().from('customers').insert({company_id:APP.cid,name:o.name,email:o.email||null,billing_address:o.addr||null,notes:'Import z e-shopu'}).select('*');if(cr.error)throw cr.error;cu=cr.data[0];APP.d.customers.rows.push(cu)}
   var jr=await getSb().from('jobs').insert({company_id:APP.cid,customer_id:cu.id,title:'E-shop import č. '+o.no,price:Math.round(o.total*100)/100,status:'done',stage:'Hotovo'}).select('id');
   if(jr.error)throw jr.error;var jid=jr.data&&jr.data[0]&&jr.data[0].id;if(!jid)throw new Error('Nepodařilo se založit zakázku.');
   var sr=await rpcInv('start',{job_id:jid});if(sr.error)throw sr.error;var d0=sr.data||{};if(!d0.id)throw new Error('Nepodařilo se založit fakturu.');
   var td=locD(new Date()),du=locD(new Date(Date.now()+14*864e5));
   var ir=await rpcInv('issue',{id:d0.id,job_id:jid,customer:{id:cu.id,name:cu.name,email:cu.email||null,billing_address:cu.billing_address||null,address_text:cu.billing_address||o.addr||null,country_code:cu.country_code||null},items:[{description:'Objednávka č. '+o.no+' z e-shopu',quantity:1,unit:'ks',unit_gross:Math.round(o.total*100)/100,vat_rate:vat}],issued_on:td,taxable_supply_on:td,due_on:du,currency:o.cur,language:'cs'});
   if(ir.error)throw ir.error;done++;o.skip='vystaveno'}
  catch(ex){if(/fakturační údaje/i.test(ex.message||'')){toast('Nejdřív vyplňte fakturační údaje dodavatele (vaše firma) a import spusťte znovu.','err');profForm();return}
   eiSt('Zastaveno po '+done+' fakturách. Objednávka č. '+o.no+': '+(ex.message||ex),'err');break}}
 APP.ei=null;await refresh();appTab('eshop');if(done)toast('Vystaveno faktur: '+done+'.','ok')}
async function shopProfCheck(){var e=A('shopProf');if(!e)return;if(DEMO){e.innerHTML='';return}
 var r=await getSb().from('user_business_profiles').select('company_id').eq('company_id',APP.cid).limit(1);APP.hasProf=!!(r.data&&r.data[0]);
 e=A('shopProf');if(e)e.innerHTML=APP.hasProf?'':'<div class="draft">Nejdřív vyplňte <b>fakturační údaje</b> (část Fakturace). Bez nich se obchod veřejně nezobrazí, protože k objednávkám se vystavují faktury. <button type="button" class="btn btn-ghost btn-sm" data-shop="prof">Vyplnit údaje</button></div>'}
async function shopSave(f){
 var sl=A('sh_slug').value.trim().toLowerCase(),st=A('shopSt');
 if(!/^[a-z0-9-]{3,40}$/.test(sl)){st.className='st err';st.textContent='Adresa smí obsahovat malá písmena bez diakritiky, čísla a pomlčky (3 až 40 znaků).';return}
 var row={company_id:APP.cid,slug:sl,enabled:A('sh_enabled').checked,title:A('sh_title').value.trim()||null,description:A('sh_desc').value.trim()||null,contact_email:A('sh_mail').value.trim()||null,contact_phone:A('sh_tel').value.trim()||null,shipping_fee:Math.max(0,Number(A('sh_fee').value)||0),shipping_text:A('sh_ship').value.trim()||null,payment_text:A('sh_pay').value.trim()||null,updated_at:new Date().toISOString()};if(A('sh_pick')){row.pickup_enabled=A('sh_pick').checked;row.pickup_text=A('sh_pickt').value.trim()||null}
 var b=f.querySelector('button[type=submit]');b.disabled=true;
 var r=await getSb().from('shop_settings').upsert(row,{onConflict:DEMO?'company_id':'company_id'});b.disabled=false;
 if(r.error){st.className='st err';st.textContent=/duplicate|unique|23505/i.test(r.error.message+(r.error.code||''))?'Tuto adresu už používá jiný obchod, zvolte jinou.':'Nepodařilo se uložit: '+r.error.message;return}
 await refresh();appTab('eshop');toast(row.enabled?'Uloženo. Obchod je zapnutý.':'Uloženo. Obchod je zatím vypnutý.','ok')}
async function shopOrderModal(id){
 var o=(APP.d.shop_orders.rows||[]).filter(function(x){return x.id===id})[0];if(!o)return;
 var r=await getSb().from('shop_order_items').select('*').eq('order_id',id),it=(r&&r.data)||[],iv=shopInvOf(o),b=o.buyer||{};
 var bt=[];
 if(iv&&!iv.paid_at&&o.status==='new')bt.push('<button class="pri" type="button" data-shop="paid:'+esc(id)+'">Označit jako zaplaceno</button>');
 if(o.status==='new'||o.status==='paid')bt.push('<button class="btn btn-ghost" type="button" data-shop="st:'+esc(id)+':shipped">Označit jako odesláno</button>');
 if(o.status==='shipped')bt.push('<button class="btn btn-ghost" type="button" data-shop="st:'+esc(id)+':done">Označit jako vyřízeno</button>');
 if(o.status!=='canceled'&&o.status!=='done')bt.push('<button class="btn btn-ghost" type="button" data-shop="cancel:'+esc(id)+'">Zrušit a vrátit zboží na sklad</button>');
 modal('<h3>Objednávka č. '+esc(o.order_no)+'</h3><p class="mut">'+fD(o.created_at,1)+' · stav: <b>'+esc(SHST[o.status]||o.status)+'</b></p><ul class="rows"><li><b>Kupující</b><span>'+esc(b.name||'')+'</span></li><li><b>E-mail</b><span>'+esc(b.email||'')+'</span></li><li><b>Telefon</b><span>'+esc(b.phone||'–')+'</span></li><li><b>Adresa</b><span>'+esc(b.address||'')+'</span></li>'+(o.note?'<li><b>Poznámka</b><span>'+esc(o.note)+'</span></li>':'')+'</ul><h4>Zboží</h4><ul class="rows">'+it.map(function(x){return '<li><b>'+esc(x.name)+'</b><span>'+skN(x.qty)+' × '+fM(x.unit_price)+'</span></li>'}).join('')+(Number(o.shipping_fee)>0?'<li><b>Doprava</b><span>'+fM(o.shipping_fee)+'</span></li>':'')+'<li><b>Celkem</b><span><b>'+fM(o.total)+'</b></span></li></ul>'
  +(iv?'<p>Faktura <b>'+esc(iv.number||'')+'</b>'+(iv.paid_at?' · zaplacená '+fD(iv.paid_at):' · čeká na platbu, splatnost '+fD(iv.due_on))+'. Najdete ji v části Fakturace.</p>':'<div class="draft">Fakturu se nepodařilo vystavit automaticky'+(o.invoice_error?' ('+esc(o.invoice_error)+')':'')+'. Objednávka a odpis ze skladu proběhly. Fakturu vystavte ručně v části Fakturace.</div>')
  +'<div class="st" id="shopOSt" role="status"></div><div class="dact">'+bt.join('')+'<button class="btn btn-ghost" type="button" data-app="mclose">Zavřít</button></div>')}
async function shopOrderAct(act){
 var p=act.split(':'),k=p[0],id=p[1],o=(APP.d.shop_orders.rows||[]).filter(function(x){return x.id===id})[0],st=A('shopOSt');if(!o)return;
 function er(t){if(st){st.className='st err';st.textContent=t}else toast(t,'err')}
 try{
  if(k==='paid'){var iv=shopInvOf(o);if(!iv){er('K objednávce není faktura.');return}
   var r=await rpcInv('paid',{id:iv.id,payment_date:locD(new Date())});if(r.error){er('Nepodařilo se označit platbu: '+r.error.message);return}
   var u=await getSb().from('shop_orders').update({status:'paid'}).eq('id',id).eq('company_id',APP.cid);if(u.error){er(u.error.message);return}
   if(o.job_id)await getSb().from('jobs').update({status:'progress',stage:'Zaplaceno'}).eq('id',o.job_id).eq('company_id',APP.cid)}
  else if(k==='st'){var ns=p[2],u2=await getSb().from('shop_orders').update({status:ns}).eq('id',id).eq('company_id',APP.cid);if(u2.error){er(u2.error.message);return}
   if(o.job_id)await getSb().from('jobs').update(ns==='done'?{status:'done',stage:'Vyřízeno'}:{status:'progress',stage:'Odesláno'}).eq('id',o.job_id).eq('company_id',APP.cid)}
  else if(k==='cancel'){if(!confirm('Zrušit objednávku a vrátit zboží na sklad? Již vystavenou fakturu je potřeba stornovat ručně.'))return;
   var c=await getSb().rpc('shop_cancel_order',{p_order:id});if(c.error){er('Zrušení se nepodařilo: '+c.error.message);return}
   if(o.job_id)await getSb().from('jobs').update({status:'canceled',stage:'Zrušeno'}).eq('id',o.job_id).eq('company_id',APP.cid)}
 }catch(ex){er(ex.message||String(ex));return}
 closeModal();await refresh();appTab('eshop');toast('Objednávka upravena.','ok')}

/* --- veřejný obchod (otevírá se z odkazu ?s=adresa) --- */
var SH={slug:'',info:null,cart:{},view:'list',res:null,prev:false};
function shopCartN(){var n=0;Object.keys(SH.cart).forEach(function(k){n+=SH.cart[k]});return n}
function shopCartSum(){var s=0;(SH.info.products||[]).forEach(function(p){s+=(SH.cart[p.id]||0)*Number(p.price)});return s}
function shopHtml(){
 var I=SH.info,el=A('vxsite');if(!el||!I)return;
 var head='<div class="shh"><div><h1>'+esc(I.title||I.name||'Obchod')+'</h1>'+(I.description?'<p>'+esc(I.description)+'</p>':'')+'</div>'+(SH.prev?'<button type="button" class="shx" data-sh="close">Zavřít náhled</button>':'')+'</div>',b='';
 if(SH.view==='done'){var r=SH.res||{};
  b='<div class="shbox"><h2>Děkujeme za objednávku č. '+esc(r.order_no)+'</h2><p>Celkem k úhradě: <b>'+fM(r.total,r.currency)+'</b></p>'
   +(r.invoice_ok?'<p>Byla vystavena faktura <b>'+esc(r.invoice_number||'')+'</b>'+(r.due_on?' se splatností '+fD(r.due_on):'')+'.</p><div class="shpay"><h3>Údaje k platbě</h3><p>Číslo účtu: <b>'+esc(r.bank_account||'–')+'</b><br>IBAN: <b>'+esc(r.iban||'–')+'</b><br>Variabilní symbol: <b>'+esc(r.invoice_number||'')+'</b><br>Částka: <b>'+fM(r.total,r.currency)+'</b></p></div>':'<p>Objednávku jsme přijali. Údaje k platbě vám pošle prodejce.</p>')
   +(r.payment_text?'<p>'+esc(r.payment_text)+'</p>':'')+'<p class="mut">Potvrzení objednávky je uložené u prodejce. Případné dotazy pište na '+esc((I.contact_email||'kontaktní e-mail prodejce'))+'.</p><p><button type="button" class="shb" data-sh="again">Zpět do obchodu</button></p></div>'}
 else if(SH.view==='checkout'){
  var pk=!!I.pickup_enabled,pick=pk&&SH.delivery==='pickup',fee=pick?0:(Number(I.shipping_fee)||0),sv=SH.form||{};
  var lines=(I.products||[]).filter(function(p){return SH.cart[p.id]}).map(function(p){return '<li><span>'+esc(p.name)+' × '+SH.cart[p.id]+' '+esc(p.unit||'ks')+'</span><b>'+fM(SH.cart[p.id]*Number(p.price))+'</b></li>'}).join('');
  b='<div class="shbox"><h2>Objednávka</h2><ul class="shl">'+lines+'<li><span>'+(pick?'Osobní odběr':'Doprava')+'</span><b>'+(fee>0?fM(fee):'zdarma')+'</b></li><li class="tot"><span>Celkem k úhradě</span><b>'+fM(shopCartSum()+fee)+'</b></li></ul>'
   +'<form id="shopOrd" class="shf">'
   +(pk?'<fieldset class="shdl"><legend>Způsob dodání</legend><label><input type="radio" name="so_d" value="ship"'+(pick?'':' checked')+'> Doprava ('+(Number(I.shipping_fee)>0?fM(I.shipping_fee):'zdarma')+')</label><label><input type="radio" name="so_d" value="pickup"'+(pick?' checked':'')+'> Osobní odběr (zdarma)</label></fieldset>':'')
   +(pick?(I.pickup_text?'<p class="mut">'+esc(I.pickup_text)+'</p>':''):(I.shipping_text?'<p class="mut">'+esc(I.shipping_text)+'</p>':''))
   +'<p class="shpm"><b>Způsob platby:</b> bankovním převodem podle faktury, kterou po odeslání objednávky uvidíte. Platba kartou není k dispozici.'+(I.payment_text?' '+esc(I.payment_text):'')+'</p>'
   +'<label>Jméno a příjmení <i aria-hidden="true">*</i><input id="so_n" required aria-required="true" maxlength="200" autocomplete="name" value="'+esc(sv.n||'')+'"></label><label>E-mail <i aria-hidden="true">*</i><input id="so_e" type="email" inputmode="email" required aria-required="true" maxlength="200" autocomplete="email" value="'+esc(sv.e||'')+'"></label><label>Telefon<input id="so_t" type="tel" inputmode="tel" maxlength="40" autocomplete="tel" value="'+esc(sv.t||'')+'"></label><label>'+(pick?'Fakturační adresa':'Adresa doručení a fakturace')+' (ulice, město, PSČ) <i aria-hidden="true">*</i><input id="so_a" required aria-required="true" minlength="5" maxlength="500" autocomplete="street-address" value="'+esc(sv.a||'')+'"></label><label>Poznámka<textarea id="so_p" rows="2" maxlength="1000">'+esc(sv.p||'')+'</textarea></label><label class="shhp" aria-hidden="true">Web<input id="so_h" tabindex="-1" autocomplete="off"></label>'
   +'<p class="shc" id="so_i">Odesláním uzavíráte kupní smlouvu s prodejcem <b>'+esc(I.name||I.title||'')+'</b> a zavazujete se zaplatit <b>'+fM(shopCartSum()+fee)+'</b> převodem podle pokynů v potvrzení. Vaše údaje prodejce použije k vyřízení objednávky a vystavení faktury (plnění smlouvy). Vexaronet obchod jen technicky provozuje pro prodejce.'+(I.contact_email?' Kontakt na prodejce: '+esc(I.contact_email)+'.':'')+'</p><div class="sherr" id="so_x" role="alert"></div><div class="shact"><button type="submit" class="shb">Objednávka zavazující k platbě</button><button type="button" class="shg" data-sh="back">Zpět</button></div></form></div>'}
 else{
  b='<div class="shgrid">'+((I.products||[]).length?(I.products||[]).map(function(p){var q=SH.cart[p.id]||0,av=Number(p.available)||0,img=/^https:\/\//i.test(p.image_url||'')?'<img src="'+esc(p.image_url)+'" alt="" loading="lazy">':'<div class="shno"></div>';
   return '<article class="shp">'+img+'<h3>'+esc(p.name)+'</h3>'+(p.description?'<p>'+esc(p.description)+'</p>':'')+'<div class="shpr"><b>'+fM(p.price)+'</b><small>'+(av>0?'skladem '+(av>=50?'50+':av)+' '+esc(p.unit||'ks'):'vyprodáno')+'</small></div>'+(av>0?'<div class="shq"><button type="button" aria-label="Ubrat" data-sh="dec:'+esc(p.id)+'">−</button><span>'+q+'</span><button type="button" aria-label="Přidat" data-sh="inc:'+esc(p.id)+'">+</button></div>':'<div class="shq off">Nedostupné</div>')+'</article>'}).join(''):'<p class="mut">Obchod zatím nemá žádné zboží.</p>')+'</div>'
   +(shopCartN()?'<div class="shbar"><span>V košíku: <b>'+shopCartN()+' ks</b> · '+fM(shopCartSum())+'</span><button type="button" class="shb" data-sh="go">Pokračovat k objednávce</button></div>':'')}
 el.innerHTML='<div class="shw">'+head+b+'<div class="shf2">Obchod běží na platformě Vexaronet.'+(SH.info.contact_email?' Kontakt: '+esc(SH.info.contact_email)+(SH.info.contact_phone?', '+esc(SH.info.contact_phone):''):'')+'</div></div>'}
async function shopOpen(slug,prev){
 var old=A('vxsite');if(old)old.remove();
 var el=document.createElement('div');el.id='vxsite';el.className='vxshop';document.body.appendChild(el);document.documentElement.style.overflow='hidden';
 var lf0=document.activeElement;SH={slug:slug,info:null,cart:{},view:'list',res:null,prev:!!prev,lf:lf0,delivery:'ship',form:{}};
 el.innerHTML='<div class="shw"><p class="mut">Načítám obchod…</p></div>';
 var r=null;try{r=await getSb().rpc('public_shop',{p_slug:slug})}catch(e){}
 if(!r||r.error||!r.data){el.innerHTML='<div class="shw"><h1>Obchod nenalezen</h1><p>Obchod neexistuje nebo je vypnutý. Zkontrolujte odkaz.</p>'+(prev?'<p><button type="button" class="shg" data-sh="close">Zavřít</button></p>':'')+'</div>';return}
 SH.info=r.data;try{document.title=r.data.title||r.data.name||document.title}catch(e){}shopHtml()}
function shopClose(){var el=A('vxsite');if(el)el.remove();document.documentElement.style.overflow=A('vxapp')?'hidden':'';try{document.title=window.DOC_T||document.title}catch(e){}if(SH&&SH.lf&&SH.lf.focus&&document.contains(SH.lf))SH.lf.focus({preventScroll:true})}
async function shopSubmit(f){
 var x=A('so_x'),b=f.querySelector('button[type=submit]');x.textContent='';b.disabled=true;
 var items=Object.keys(SH.cart).map(function(k){return {product_id:k,qty:SH.cart[k]}});
 var args={p_slug:SH.slug,p_items:items,p_buyer:{name:A('so_n').value.trim(),email:A('so_e').value.trim(),phone:A('so_t').value.trim(),address:A('so_a').value.trim()},p_note:A('so_p').value.trim()||null,p_hp:A('so_h').value};if(SH.info&&SH.info.pickup_enabled)args.p_delivery=SH.delivery==='pickup'?'pickup':'ship';
 var r;try{r=await getSb().rpc('public_shop_order',args)}catch(ex){r={error:ex}}
 b.disabled=false;
 if(r.error){x.textContent=String(r.error.message||'Objednávku se nepodařilo odeslat.').replace(/^.*?:\s*(?=[A-ZÁ-Ž])/,'');return}
 SH.res=r.data;SH.view='done';SH.cart={};
 if(SH.prev&&DEMO){try{await refresh()}catch(e){}}
 shopHtml();var el=A('vxsite');if(el)el.scrollTop=0}
function shopClick(e){var t=e.target.closest('[data-sh]');if(!t||!A('vxsite')||!A('vxsite').contains(t))return false;var k=t.dataset.sh,p=k.split(':');
 if(k==='close'){shopClose();return true}
 if(k==='go'){SH.view='checkout';shopHtml();A('vxsite').scrollTop=0;return true}
 if(k==='back'||k==='again'){SH.view='list';shopHtml();return true}
 if(p[0]==='inc'||p[0]==='dec'){var pr=(SH.info.products||[]).filter(function(x){return x.id===p[1]})[0];if(!pr)return true;var q=(SH.cart[p[1]]||0)+(p[0]==='inc'?1:-1),mx=Math.min(Number(pr.available)||0,100);q=Math.max(0,Math.min(q,mx));if(q)SH.cart[p[1]]=q;else delete SH.cart[p[1]];var sc=A('vxsite').scrollTop;shopHtml();A('vxsite').scrollTop=sc;return true}
 return false}


var VIEWS={
 eshop:function(){return shopView()},
 pobocky:function(){return pobView()},
 prehled:function(){
  var d=APP.d,s=summary(),ms=monthsBack(6),h=trialBanner()+(APP.betaHidden?'':'<div class="betab"><span><b>Rozpracovaná beta verze.</b> Hotové části fungují se skutečnými daty, nehotové jsou označené „brzy“.</span><button type="button" class="lnk" data-app="hidebeta">Skrýt</button></div>');
  var errs=['customers','jobs','reservations','tasks','invoices'].filter(function(k){return d[k].err}).map(function(k){return k+': '+d[k].err});
  if(errs.length||d.ds.err)h+='<div class="draft">Část dat se nepodařilo načíst. '+esc(errs.concat(d.ds.err?['přehled: '+d.ds.err]:[]).join(' · '))+'</div>';
  var inv=d.invoices.rows.map(function(x){return {issued_on:x.issued_on,__v:Number(x.total||0),paid_at:x.paid_at}}),all=byMonth(inv,function(x){return x.issued_on},ms),
      unp=byMonth(inv.filter(function(x){return !x.paid_at}),function(x){return x.issued_on},ms),
      cu=byMonth(d.customers.rows,function(x){return x.created_at},ms),n=ms.length,
      active=s.zakazky_aktivni,tot=s.zakazky_celkem,pct=tot?Math.round(active/tot*100):0,newC=cu[n-1];
  var qa=[['jobs',jobNewL(),'zakazky'],['customers','Nový zákazník','zakaznici'],['reservations','Rezervace','kalendar'],['tasks','Nový úkol','ukoly']];
  h+='<div class="dgrid"><div class="dl"><div class="greet"><div><h2>'+greet()+'</h2><p class="mut">Zde je přehled vaší firmy.'+(off('ceo')?'':' AI CEO hlídá důležité věci a navrhuje kroky.')+'</p></div><div class="gd">'+new Date().toLocaleDateString('cs-CZ',{weekday:'long'}).replace(/^./,function(c){return c.toUpperCase()})+'<br>'+new Date().toLocaleDateString('cs-CZ',{day:'numeric',month:'long',year:'numeric'})+'</div><div class="qw"><button type="button" class="pri" data-app="quick">+ Rychlá akce ▾</button><div class="pop qpop" id="qPop">'+qa.map(function(q){return '<button type="button" data-new="'+q[0]+'">'+q[1]+'</button>'}).join('')+'</div></div></div>'
  +'<div class="kpis">'+tile2('g','tr','Tržby tento měsíc',fM(all[n-1]),trend(all[n-1],all[n-2])||'<small class="mut">vystavené faktury</small>','faktury',spark(all,'sg'))
  +tile2('r','faktury','Nezaplacené faktury',fM(s.pohledavky_kc),'<small class="mut">'+s.faktury_nezaplacene+' '+plural(s.faktury_nezaplacene,'faktura','faktury','faktur')+(s.faktury_po_splatnosti?', '+s.faktury_po_splatnosti+' po splatnosti':'')+'</small>','faktury',spark(unp,'sr'))
  +tile2('b','zakazky',jobActL(),active,'<small class="mut">z '+tot+' celkem</small><span class="prog"><i style="width:'+pct+'%"></i></span>','zakazky')
  +tile2('p','zakaznici','Noví zákazníci',newC,(trend(newC,cu[n-2])||'<small class="mut">tento měsíc</small>')+'<small class="mut"> · celkem '+s.zakaznici+'</small>','zakaznici',spark(cu,'sp'))+(hasCeo()&&APP.role!=='employee'?(function(){var sc=ceoModel().score;return tile2(scoreCls(sc)||'b','ceo','Zdraví firmy',sc==null?'málo dat':sc+' / 100','<small class="mut">'+scoreLab(sc)+'</small>','ceo')})():'')+'</div>'
  +(APP.role==='employee'?clockCard():'')+stepsCard()+dnesCard()+(off('ceo')?'':'<section class="card2 recs"><div class="rh"><span class="ki p">'+ico('ceo',22)+'</span><h3>AI CEO – dnešní doporučení</h3><button type="button" class="btn btn-ghost btn-sm" data-tab="ceo">Zobrazit všechny</button></div>'+recsHtml(4)+'<p class="mut fine">Doporučení vznikají z vašich skutečných dat podle pevných pravidel. Akce „Provést“ se vždy nejdřív zeptá na potvrzení.</p></section>')+'</div>'
  +(off('ceo')?'':'<aside class="dr card2">'+ceoPanel()+'</aside>')
  +'<div class="db4"><section class="card2"><h3>Příjmy a výdaje</h3><div id="chCash"></div></section><section class="card2"><h3>Tržby podle zákazníků</h3><div id="chCust"></div></section><section class="card2"><h3>Nejbližší události</h3>'+evHtml()+'</section><section class="card2"><h3>Rychlé akce</h3><div class="qg">'+qa.map(function(q){return '<button type="button" data-new="'+q[0]+'"><span class="ki b">'+ico(q[2],20)+'</span>'+q[1]+'</button>'}).join('')+'<button type="button" class="qs" data-newinv="1">'+'<span class="ki g">'+ico('faktury',20)+'</span>Nová faktura</button>'+(off('ucetni')?'':'<button type="button" data-tab="ucetni"><span class="ki p">'+ico('sklad',20)+'</span>Nahrát doklad (AI Účetní)</button>')+'</div></section></div></div>'+onboard();
  return h},
 ceo:function(){
  var top=hasCeo()?'<div class="two"><section class="card2">'+healthHtml()+'</section><section class="card2"><h3>Měsíční cíl</h3>'+goalHtml()+'<div class="dact"><button class="pri" type="button" data-act="report">Týdenní report</button></div></section></div><section class="card2"><h3>Výhled na 30 dní</h3>'+outlook()+'</section>':'';
  return top+'<div class="two"><section class="card2"><h3>Doporučení AI CEO</h3>'+recsHtml(10)+'<p class="mut fine">Pevná pravidla nad vašimi skutečnými daty, ne odhady AI. Akce vždy potvrzujete.</p></section><section class="card2 dr0">'+ceoPanel()+'</section></div><section class="card2"><h3>Co AI CEO umí a v jakém stavu</h3><ul class="rows">'+[['Analýza zakázek, zákazníků a faktur','funguje (rady od AI a pevná pravidla)'],['Upozornění na nezaplacené faktury a termíny','funguje'],['Příprava textů upomínek a nabídek','funguje (texty ke zkopírování)'],['Vytváření úkolů z doporučení','funguje po potvrzení'],['Odesílání e-mailů a zpráv','zatím není připojeno'],['Zdraví firmy (skóre ze 6 oblastí)','funguje, orientační, počítá se z vašich dat'],['Výhled plateb na 30 dní','funguje orientačně (faktury podle splatnosti a průměr výdajů), bez zůstatku na účtu'],['Měsíční cíl fakturace a týdenní report','funguje'],['Předpověď nedostatku peněz','jen orientační, přesná předpověď až s napojením banky'],['Automatizace opakovaných úkolů','připravujeme (etapa 5)'],['Marketingové kampaně','pouze rady, spouštění připravujeme']].map(function(x){return '<li><b>'+x[0]+'</b><span>'+x[1]+'</span></li>'}).join('')+'</ul></section>'},
 finance:function(){
  var x=APP.d.fe,rs=x.rows.slice().sort(function(a,b){return new Date(b.entry_date||b.created_at)-new Date(a.entry_date||a.created_at)}),inc=0,exp=0;
  rs.forEach(function(r){var v=Math.abs(Number(r.amount)||0);if(isInc(r.kind))inc+=v;else exp+=v});
  var h='<div class="kpis" style="margin:10px 0 14px">'+tile2('g','tr','Příjmy (záznamy)',fM(inc),'')+tile2('r','finance','Výdaje (záznamy)',fM(exp),'')+tile2(inc>=exp?'b':'o','faktury','Rozdíl',fM(inc-exp),'')+'</div>'+head('financial_entries','+ Nový záznam')+errBox(x);
  if(!rs.length)return h+'<p class="mut">Zatím žádné záznamy. Přidejte příjem nebo výdaj.</p>';
  return h+'<ul class="rows big">'+rs.map(function(r){return '<li data-edit="financial_entries:'+esc(r.id)+'"><div><b>'+esc(r.title||'Záznam')+'</b><small>'+fD(r.entry_date)+'</small></div><span class="'+(isInc(r.kind)?'inc':'')+'">'+(isInc(r.kind)?'+':'−')+fM(Math.abs(Number(r.amount)||0))+' · '+esc(KL(r.kind))+'</span></li>'}).join('')+'</ul><p class="mut fine">Jednoduchá evidence příjmů a výdajů. Nejde o účetnictví ani daňové přiznání.</p>'},
 ucetni:function(){
  var st=accStats(),ch=accChecks(),nowM=new Date().toISOString().slice(0,7),lim=ACCLIM[effPlan()]||0;
  var h='<div class="card2 note"><b>AI Účetní pomáhá s evidencí a doklady.</b> Nenahrazuje účetního ani daňového poradce. Údaje vytěžené z dokladů vždy zkontrolujte, do evidence se uloží až po vašem potvrzení. Účetnictví, DPH a daňové podklady jsou zatím jen plánované.</div>';
  h+='<div class="kpis" style="margin:12px 0">'+tile2('g','tr','Příjmy tento měsíc',fM(st.i0),'minulý měsíc '+fM(st.i1))+tile2('r','finance','Výdaje tento měsíc',fM(st.e0),'minulý měsíc '+fM(st.e1))+tile2(st.i0>=st.e0?'b':'o','faktury','Rozdíl tento měsíc',fM(st.i0-st.e0),'')+tile2('o','faktury','Nezaplacené faktury',fM(st.unp),st.unpN+' '+plural(st.unpN,'faktura','faktury','faktur')+(st.ovN?', po splatnosti '+st.ovN:''))+'</div>';
  h+='<div class="two"><section class="card2"><h3>Zpracovat doklad (AI)</h3><p class="mut">Nahrajte fotku nebo PDF faktury či účtenky. AI z něj vytáhne údaje a navrhne záznam, vy ho zkontrolujete a uložíte. Původní soubor se neukládá.</p><p class="mut fine" id="accUse">Počítám zpracované doklady…</p><div class="f full"><label for="accFile">Doklad (JPG, PNG, WebP, HEIC nebo PDF, do 6 MB)</label><input id="accFile" type="file" accept="image/*,application/pdf,.heic,.heif"></div><div class="dact"><button class="pri" type="button" data-acc="process">Zpracovat doklad</button></div><div class="st" id="accSt" role="status"></div><div id="accRes"></div></section>';
  h+='<section class="card2"><h3>Kontrola záznamů</h3><p class="mut fine">Jednoduchá kontrola vaší evidence podle pevných pravidel. Nejde o účetní audit.</p>'+(ch.length?'<ul class="rows">'+ch.map(function(x){return '<li><b>'+x[0]+'</b><span>'+x[1]+'</span></li>'}).join('')+'</ul>':'<p class="mut">Nic podezřelého jsme nenašli.</p>')+'</section></div>';
  h+='<div class="two"><section class="card2"><h3>Export pro účetního</h3><p class="mut">Stáhněte příjmy a výdaje nebo faktury jako soubor CSV (otevře Excel i účetní programy). Měsíc nechte prázdný pro vše.</p><div class="f full"><label for="accMon">Měsíc</label><input id="accMon" type="month" value="'+nowM+'"></div><div class="dact"><button class="btn btn-ghost btn-sm" type="button" data-acc="csv-ent">Příjmy a výdaje (CSV)</button><button class="btn btn-ghost btn-sm" type="button" data-acc="csv-inv">Faktury (CSV)</button></div></section>';
  h+='<section class="card2"><h3>Zeptejte se AI Účetní</h3><p class="mut fine">Odpovídá z čísel ve vaší evidenci. Nedává závazné rady k DPH, daním ani účtování, tam se obraťte na účetního.</p><div class="chatl" id="accLog" style="height:230px">'+accMsgs()+'</div><form class="aif" id="accForm"><input id="accIn" placeholder="Např. Kolik jsem tento měsíc utratil?" maxlength="500" autocomplete="off" aria-label="Zpráva pro AI Účetní"><button class="sendb" type="submit" aria-label="Odeslat">'+ico('send')+'</button></form></section></div>';
  h+='<section class="card2"><h3>Bankovní výpis a párování plateb</h3><p class="mut">Nahrajte CSV výpis z internetového bankovnictví (funguje s většinou českých bank i s exporty z platebních terminálů). AI Účetní spáruje platby s vašimi fakturami podle variabilního symbolu a částky. Faktury označí jako zaplacené až po vašem potvrzení. Soubor se nikam neukládá, zpracuje se jen ve vašem prohlížeči.</p><div class="f full"><label for="bkFile">Výpis (CSV)</label><input id="bkFile" type="file" accept=".csv,.txt,text/csv"></div><div class="dact"><button class="pri" type="button" data-acc="bk-file">Načíst výpis</button>'+(DEMO?'<button class="btn btn-ghost btn-sm" type="button" data-acc="bk-demo">Načíst ukázkový výpis</button>':'')+'</div><div class="st" id="bkSt" role="status"></div><div id="bkRes">'+bkView()+'</div></section>';
  h+='<section class="card2"><h3>Co je hotové a co se připravuje</h3><ul class="rows">'+[['Vytěžení údajů z faktur a účtenek (foto, PDF)','funguje, vždy po vaší kontrole'],['Evidence příjmů a výdajů','funguje'],['Kontrola záznamů (duplicity, budoucí data, po splatnosti)','funguje'],['Export CSV pro účetního','funguje'],['Dotazy na AI Účetní nad vaší evidencí','funguje'],['Podvojné účetnictví, deník a hlavní kniha','připravujeme, čeká na kontrolu odborníkem'],['DPH a daňové podklady','připravujeme, čeká na kontrolu odborníkem'],['Import bankovního výpisu (CSV) a párování plateb s fakturami','funguje, vždy po vašem potvrzení'],['Přímé napojení bankovního účtu (PSD2) a platebního terminálu','připravujeme, vyžaduje oficiální bankovní přístup'],['Účetní závěrky, mzdy a odvody','připravujeme']].map(function(x){return '<li'+(/^funguje/.test(x[1])?'':' class="off"')+'><b>'+x[0]+'</b><span>'+x[1]+'</span></li>'}).join('')+'</ul><p class="mut fine">Váš tarif: '+esc(PLANN[effPlan()]||'')+' · limit '+lim+' dokladů měsíčně.</p></section>';
  return h},
 zakaznici:function(){return csTools('customers')+listView('customers','Hledat zákazníka…','+ Nový zákazník',function(x){return '<div><b>'+esc(custName(x))+'</b><small>'+[x.email,x.phone].filter(Boolean).map(esc).join(' · ')+'</small></div>'},'Zatím žádní zákazníci.')},
 zakazky:function(){var cm=cmap();return csTools('jobs')+listView('jobs','Hledat zakázku…','+ '+jobNewL(),function(x){return '<div><b>'+esc(x.title)+'</b><small>'+esc(cm[x.customer_id]||'bez zákazníka')+(x.location_id&&locName(x.location_id)?' · '+esc(locName(x.location_id)):'')+(x.description?' · '+esc(x.description):'')+'</small></div><span>'+fM(x.price)+' · do '+fD(x.due_at)+(x.status?' · <em class="stt">'+esc(stLab(x))+'</em>':'')+'</span>'},'Zatím žádné zakázky.',function(a,b){return new Date(b.created_at)-new Date(a.created_at)})},
 kalendar:function(){
  if(!APP.calM){var n0=new Date();APP.calM=new Date(n0.getFullYear(),n0.getMonth(),1)}
  var M=APP.calM,mode=APP.calMode||'m',mg=APP.role==='owner'||APP.role==='admin',mn=M.toLocaleDateString('cs-CZ',{month:'long',year:'numeric'});mn=mn.charAt(0).toUpperCase()+mn.slice(1);
  var h='<div class="calbar"><div class="calnav"><button type="button" class="ib" data-calnav="-1" aria-label="Předchozí měsíc">‹</button><h3>'+esc(mn)+'</h3><button type="button" class="ib" data-calnav="1" aria-label="Další měsíc">›</button><button type="button" class="btn btn-ghost btn-sm" data-calnav="0">Dnes</button></div><div class="calact"><div class="calseg"><button type="button" data-calmode="m" aria-pressed="'+(mode==='m')+'">Měsíc</button><button type="button" data-calmode="l" aria-pressed="'+(mode==='l')+'">Seznam</button></div><button type="button" class="btn btn-main btn-sm" data-new="reservations">+ Rezervace</button>'+(mg?'<button type="button" class="btn btn-ghost btn-sm" data-new="shifts">+ Směna</button>':'')+'</div></div>'+errBox(APP.d.reservations);
  if(mode==='l')return h+calList();
  var first=new Date(M.getFullYear(),M.getMonth(),1),off=(first.getDay()+6)%7,st=new Date(first);st.setDate(1-off);
  var it=calItems(),tk=locD(new Date()),sel=APP.calSel||tk;
  var g='<div class="calg"><div class="calw">'+['Po','Út','St','Čt','Pá','So','Ne'].map(function(x){return '<span>'+x+'</span>'}).join('')+'</div><div class="calc">';
  for(var i=0;i<42;i++){var d=new Date(st);d.setDate(st.getDate()+i);if(i>=35&&d.getMonth()!==M.getMonth())break;var k=locD(d),li=it[k]||[];
   g+='<button type="button" class="cd'+(d.getMonth()!==M.getMonth()?' oth':'')+(k===tk?' td':'')+(k===sel?' sel':'')+'" data-calday="'+k+'"><span class="cdn">'+d.getDate()+'</span>'+li.slice(0,3).map(function(x){return '<span class="cchip c'+x.k+'">'+esc(x.lab)+'</span>'}).join('')+(li.length>3?'<span class="more">+'+(li.length-3)+' další</span>':'')+'</button>'}
  g+='</div></div><div class="calleg"><span><i class="cdot cr"></i>Rezervace</span><span><i class="cdot cj"></i>Termín zakázky</span><span><i class="cdot cs"></i>Směna</span><span><i class="cdot ct"></i>Úkol</span></div>';
  var di=it[sel]||[],sd=new Date(sel+'T12:00:00'),dt=sd.toLocaleDateString('cs-CZ',{weekday:'long',day:'numeric',month:'long'});
  g+='<section class="card2"><h3>'+esc(dt.charAt(0).toUpperCase()+dt.slice(1))+'</h3>'+(di.length?'<ul class="rows big">'+di.map(function(x){var ed=(x.ent!=='shifts'||mg);return '<li'+(ed?' data-edit="'+x.ent+':'+esc(x.id)+'"':'')+'><div><b>'+esc(x.t)+'</b><small>'+CALK[x.k]+'</small></div><span><i class="cdot c'+x.k+'"></i> '+esc(x.tm)+'</span></li>'}).join('')+'</ul>':'<p class="mut">V tento den nic není naplánováno.</p>')+'</section>';
  return h+g},
 online:function(){return onlineView()},
 weby:function(){return webView()},
 marketing:function(){return mkView()},
 reporty:function(){return reportyView()},
 automatizace:function(){return auView()},
 sklad:function(){return skladView()},
 ukoly:function(){
  var x=APP.d.tasks,ts=x.rows.slice().sort(function(a,b){return (a.completed-b.completed)||(new Date(a.due_at||'2999')-new Date(b.due_at||'2999'))});
  var h=head('tasks','+ Nový úkol')+errBox(x);if(!ts.length)return h+'<p class="mut">Zatím žádné úkoly.</p>';
  return h+'<ul class="rows big">'+ts.map(function(t){var late=!t.completed&&t.due_at&&new Date(t.due_at)<dayStart(0);return '<li'+(t.completed?' class="off"':'')+'><label class="chk"><input type="checkbox" data-task="'+esc(t.id)+'"'+(t.completed?' checked':'')+'><span>'+esc(t.title)+'</span></label><span'+(late?' class="late"':'')+'>'+fD(t.due_at)+'</span><button type="button" class="lnk" data-edit="tasks:'+esc(t.id)+'">Upravit</button></li>'}).join('')+'</ul>'},
 faktury:function(){return fakturyView()},
 faktury_stary:function(){
  var x=APP.d.invoices,fs=x.rows.slice().sort(function(a,b){return new Date(b.issued_on||b.created_at)-new Date(a.issued_on||a.created_at)});
  var h='<div class="card2 note"><b>Pozor:</b> '+(LOCAL?'v lokální verzi jsou faktury zjednodušené: číslují se podle roku a sčítají se částky položek, DPH se nepočítá a nekontroluje se návaznost číselné řady. Doklad vždy zkontrolujte, než ho pošlete zákazníkovi, a nepovažujte ho za účetně ověřený.':'faktury se vystavují přes pravidla ve vaší databázi (číslování, DPH).')+' Před ostrým používáním je musí zkontrolovat účetní. Odesílání faktur e-mailem a PDF zatím nejsou připojené.</div><div class="bar2"><button type="button" class="btn btn-ghost btn-sm" data-invprof="1">Fakturační údaje</button><button type="button" class="pri sm" data-newinv="1">+ Nová faktura</button></div>'+errBox(x);
  if(!fs.length)return h+'<p class="mut">Zatím žádné faktury. Nejdřív vyplňte Fakturační údaje, pak vystavte první fakturu.</p>';
  return h+'<ul class="rows big">'+fs.map(function(f){var cu=f.customer_snapshot,nm=cu&&typeof cu==='object'?(cu.name||cu.company_name||''):'',late=!f.paid_at&&f.due_on&&new Date(f.due_on)<dayStart(0);return '<li><div><b>'+esc(f.number||'bez čísla')+'</b><small>'+esc(nm)+' · vystaveno '+fD(f.issued_on)+' · splatnost '+fD(f.due_on)+(f.lifecycle?' · '+esc(f.lifecycle):'')+'</small></div><span'+(late?' class="late"':'')+'>'+fM(f.total,f.currency)+' · '+(f.paid_at?'zaplaceno '+fD(f.paid_at):(late?'po splatnosti':'nezaplaceno'))+'</span><button type="button" class="lnk" data-invview="'+esc(f.id)+'">Zobrazit fakturu</button>'+(f.paid_at?'':'<button type="button" class="lnk" data-pay="'+esc(f.id)+'">Označit jako zaplacenou</button>')+'</li>'}).join('')+'</ul>'},
 zamestnanci:function(){
  var lim=TEAMLIM[effPlan()]||1,mg=APP.role==='owner'||APP.role==='admin';
  return clockCard()+'<section class="card2"><h3>'+(mg?'Docházka a odpracované hodiny':'Moje odpracované hodiny')+'</h3><div id="attBox">'+attHtml()+'</div></section>'+(mg?'<div class="card2"><div class="bar2"><div><h3>Zaměstnanci a tým</h3><p class="mut">Tarif '+esc(PLANN[effPlan()]||effPlan())+': nejvýše '+lim+' '+plural(lim,'uživatel','uživatelé','uživatelů')+(effPlan()==='accountant'?' (vy a externí účetní)':'')+'. Do počtu se počítají i nevyřízené pozvánky.</p></div>'+(mg?'<button class="pri sm" type="button" data-invnew="1">+ Pozvat člena</button>':'')+'</div><div id="teamBox"><p class="mut">Načítám tým…</p></div></div><div class="draft">Po vytvoření pozvánky se e-mail odešle automaticky. Pozvaný se zaregistruje stejným e-mailem a po potvrzení e-mailu se automaticky přidá do vaší firmy. Zaměstnanec vidí zákazníky, zakázky, úkoly a kalendář a může přidávat zákazníky a zakázky. Na vyznačenou směnu se přihlásí tlačítkem Online a při odchodu dá Offline; odpracované hodiny se počítají automaticky. Faktury, finance a AI CEO nevidí.</div>':'')},
 profil:function(){
  var s=APP.sub,m=APP.meta,fs=m.features||[];
  return '<div class="two"><section class="card2"><h3>Firma a účet</h3><ul class="rows"><li><b>E-mail</b><span>'+esc(APP.user.email)+'</span></li><li><b>Jméno</b><span>'+esc(m.full_name||'–')+'</span></li><li><b>Firma</b><span>'+esc(APP.co)+'</span></li><li><b>Obor</b><span>'+esc(APP.ind||'–')+'</span></li><li><b>Stát</b><span>'+esc(m.country||'–')+'</span></li><li><b>Role</b><span>'+esc(APP.role||'–')+'</span></li></ul></section><section class="card2"><h3>Předplatné</h3>'+(s?'<ul class="rows"><li><b>Tarif</b><span>'+esc(PLANN[String(s.plan).toLowerCase()]||s.plan)+'</span></li><li><b>Stav</b><span>'+esc(STATN[s.status]||s.status)+'</span></li>'+(s.trial_end?'<li><b>Zkušební období do</b><span>'+fD(s.trial_end)+'</span></li>':'')+(effPlan()!==String(s.plan).toLowerCase()?'<li><b>Aktuálně platí</b><span>'+esc(PLANN[effPlan()])+'</span></li>':'')+'</ul><p class="mut">'+esc(PLANLIM[effPlan()]||'')+'</p><p class="mut fine">Ceny jsou měsíční bez DPH. Platební brána zatím není připojená, nic vám neúčtujeme a nic se automaticky nestrhává. Přechod na START je okamžitý, vyšší tarif nastavíme po vaší žádosti ručně.</p><div class="dact"><a class="btn btn-ghost btn-sm" href="/cenik">Zobrazit ceník</a><button class="pri sm" type="button" data-app="plan">Změnit tarif</button></div>':'<p class="mut">Předplatné nenalezeno.</p>')+'</section></div>'
  +(APP.role!=='employee'?fpSettingsCards():'')
  +'<section class="card2"><h3>Zaměření aplikace podle oboru</h3><p class="mut">Menu, názvy, šablony zakázek, doporučené služby i první kroky se přizpůsobí oboru. Žádná data se tím nemažou, ostatní moduly zůstávají v části Další moduly.</p><form id="obForm"><div class="f"><label for="obSel">Obor</label><select id="obSel">'+Object.keys(OB).map(function(k){return '<option'+(k===obKey(APP.ind)?' selected':'')+'>'+esc(k)+'</option>'}).join('')+'</select></div><button class="btn btn-main btn-sm" type="submit">Použít</button></form></section>'
  +'<section class="card2"><h3>Použité funkce</h3><form id="featForm"><div class="fg"><div class="f"><label for="pC">Stát</label><select id="pC">'+COUNTRIES.map(function(x){return '<option'+(x===m.country?' selected':'')+'>'+x+'</option>'}).join('')+'</select></div></div><div class="chks">'+FEATS.map(function(f){return '<label class="chk"><input type="checkbox" name="ft" value="'+f[0]+'"'+(fs.indexOf(f[0])>=0?' checked':'')+'><span>'+f[1]+'</span></label>'}).join('')+'</div><button class="btn btn-main btn-sm" type="submit">Uložit</button></form></section><div class="dact"><button class="btn btn-ghost" type="button" data-app="logout">Odhlásit se</button></div>'}
};
function trialBanner(){var x=APP.sub;if(!x||x.status!=='trial'||!x.trial_end)return '';var d=Math.ceil((new Date(x.trial_end)-new Date())/864e5);
 if(d<=0)return '<div class="betab"><span><b>Zkušební období skončilo.</b> Účet teď běží v tarifu START, vaše data zůstávají zachována. Pro plné funkce vyberte tarif.</span><button class="btn btn-ghost btn-sm" type="button" data-app="plan">Změnit tarif</button></div>';
 if(d<=7)return '<div class="betab"><span><b>Zkušební období končí za '+d+' '+(d===1?'den':(d<5?'dny':'dní'))+'.</b> Pak můžete vybrat placený tarif, nebo přejít na START. Nic se automaticky neúčtuje.</span><a class="btn btn-ghost btn-sm" href="/cenik">Ceník</a></div>';return ''}
function recsHtml(n){if(!hasCeo())return '<p class="mut">AI CEO (doporučení a chat nad vašimi daty) je součástí tarifu Vexaronet PRO a vyšších.</p><div class="dact"><a class="btn btn-ghost btn-sm" href="/cenik">Zobrazit ceník</a></div>';return '<div class="rl">'+recs().slice(0,n).map(function(r,i){return '<div class="rec"><span class="ki '+(r.c==='bad'?'r':r.c==='warn'?'o':r.c==='ok'?'g':'b')+'">'+ico(r.ic,22)+'</span><div class="rt"><b>'+esc(r.t)+'</b><small>'+esc(r.x)+'</small></div><div class="ra">'+(r.go?'<button type="button" class="btn btn-ghost btn-sm" data-tab="'+r.go+'">Zobrazit</button>':'')+(r.act?'<button type="button" class="pri sm" data-act="'+r.act+'">'+ico('send',16)+' '+esc(r.lab)+'</button>':'')+'</div></div>'}).join('')+'</div>'}
function evHtml(){var E=events();if(!E.length)return '<p class="mut">Žádné nadcházející události.</p>';return '<ul class="ev">'+E.map(function(e){var tm=e[0].getHours()||e[0].getMinutes()?e[0].toLocaleTimeString('cs-CZ',{hour:'2-digit',minute:'2-digit'}):'';return '<li><button type="button" data-tab="'+e[2]+'"><span class="evd"><b>'+dayLbl(e[0])+'</b><small>'+tm+'</small></span><span class="evt">'+esc(e[1])+'</span></button></li>'}).join('')+'</ul>'}
var AFTER={profil:function(){if(typeof VXDSA!=='undefined')VXDSA.mount()},eshop:function(){shopProfCheck()},weby:function(){webPrev()},kalendar:function(){try{getSb().rpc('company_team',{cid:APP.cid}).then(function(r){if(r&&r.data)APP.team=r.data})}catch(e){}},ucetni:function(){accUsage()},zamestnanci:function(){loadTeam();loadAtt()},prehled:function(){
  var d=APP.d,ms=monthsBack(6),lb=ms.map(function(m){return m.toLocaleDateString('cs-CZ',{month:'short'})}),f=finSeries(ms);
  A('chCash').innerHTML=(d.invoices.rows.length||d.ds.income)?barChart(lb,f.inc,f.exp,'Příjmy','Výdaje','b2','b3',true)+'<p class="mut fine">Zdroj: '+esc(f.src)+'.</p>':'<p class="mut">Zatím žádná data.</p>';
  var cn={},tot=0;d.invoices.rows.forEach(function(x){var cu=x.customer_snapshot,nm=cu&&typeof cu==='object'?(cu.name||cu.company_name):'';nm=nm||'Neznámý';var v=Number(x.total||0);cn[nm]=(cn[nm]||0)+v;tot+=v});
  var it=Object.keys(cn).map(function(k){return [k,cn[k]]}).sort(function(a,b){return b[1]-a[1]});if(it.length>4){var rest=it.slice(3).reduce(function(s,x){return s+x[1]},0);it=it.slice(0,3).concat([['Ostatní',rest]])}
  A('chCust').innerHTML=tot?donut(it.map(function(x){return [x[0]+' ('+Math.round(x[1]/tot*100)+' %)',Math.round(x[1]),fM(Math.round(x[1]))]}),chK(tot)+' Kč','fakturováno'):'<p class="mut">Zatím žádné faktury.</p>'}};

/* ---- Zaměstnanci: tým a pozvánky ---- */
function teamErr(m){m=String(m||'');var M={'Nemate opravneni zvat cleny tymu.':'Nemáte oprávnění zvát členy týmu.','Neplatna role.':'Neplatná role.','Spravce muze pridat jen majitel.':'Správce může přidat jen majitel.','Zadejte platny e-mail.':'Zadejte platný e-mail.','Tento clovek uz ve firme je.':'Tento člověk už ve firmě je.','Tento e-mail uz je pozvany.':'Tento e-mail už je pozvaný.','Nemate opravneni.':'Nemáte oprávnění.','Majitele firmy nelze odebrat.':'Majitele firmy nelze odebrat.','Sami sebe odebrat nelze.':'Sami sebe odebrat nelze.','Spravce muze odebrat jen majitel.':'Správce může odebrat jen majitel.'};if(M[m])return M[m];var x=/nejvyse (\d+) uzivatelu/.exec(m);if(x)return 'Váš tarif umožňuje nejvýše '+x[1]+' uživatelů (včetně nevyřízených pozvánek). Pro více členů přejděte na vyšší tarif.';return m}
async function loadTeam(){
 var box=A('teamBox');if(!box)return;var c=getSb(),mg=APP.role==='owner'||APP.role==='admin';
 var T=await c.rpc('company_team',{cid:APP.cid});
 if(T.error){box.innerHTML='<div class="draft">Tým se nepodařilo načíst: '+esc(T.error.message)+'. Pokud jste ještě nespustili SQL pro pozvánky, je potřeba ho dokončit v databázi.</div>';return}
 var I=mg?await c.from('company_invites').select('*').eq('company_id',APP.cid).is('accepted_at',null).order('created_at'):{data:[]};
 APP.team=T.data||[];APP.invs=I.data||[];
 var h='<ul class="rows big">'+APP.team.map(function(x){var can=mg&&x.role!=='owner'&&!x.is_me&&!(x.role==='admin'&&APP.role!=='owner');return '<li><div><b>'+esc(x.email)+(x.is_me?' (vy)':'')+'</b><small>'+esc(ROLEN[x.role]||x.role)+'</small></div>'+(can?'<button class="btn btn-ghost btn-sm" type="button" data-rmm="'+esc(x.user_id)+'">Odebrat</button>':'')+'</li>'}).join('')+'</ul>';
 if(mg){h+='<h4>Nevyřízené pozvánky</h4>'+(APP.invs.length?'<ul class="rows big">'+APP.invs.map(function(x){return '<li><div><b>'+esc(x.email)+'</b><small>'+esc(ROLEN[x.role]||x.role)+' · pozváno '+fD(x.created_at)+'</small></div><span><button class="btn btn-ghost btn-sm" type="button" data-invshow="'+esc(x.id)+'">Text pozvánky</button> <button class="btn btn-ghost btn-sm" type="button" data-invcancel="'+esc(x.id)+'">Zrušit</button></span></li>'}).join('')+'</ul>':'<p class="mut">Žádné nevyřízené pozvánky.</p>')}
 box.innerHTML=h}
function inviteModal(){
 var own=APP.role==='owner';
 modal('<h3>Pozvat člena týmu</h3><form id="inviteForm"><div class="fg"><div class="f full"><label for="ivE">E-mail pozvaného <i>*</i></label><input id="ivE" type="email" autocomplete="off" required></div><div class="f full"><label for="ivR">Role</label><select id="ivR"><option value="employee">Zaměstnanec (zákazníci, zakázky, úkoly, kalendář)</option>'+(own?'<option value="admin">Správce (vše včetně financí a týmu)</option>':'')+'</select></div></div><div class="st" id="entSt" role="status"></div><div class="dact"><button class="pri" type="submit">Vytvořit pozvánku</button><button class="btn btn-ghost" type="button" data-app="mclose">Zrušit</button></div></form>')}
function inviteText(email){
 var nm=(APP.meta.full_name||'').trim();
 return 'Dobrý den,\npozývám Vás do firmy '+APP.co+' ve Vexaronetu.\n\n1. Otevřete https://vexaronet.com a klikněte na Přihlášení, pak na Registrace.\n2. Zaškrtněte, že jste pozvaný/á do firmy zaměstnavatele.\n3. Registrujte se přesně tímto e-mailem: '+email+'\n4. Potvrďte e-mail (přijde Vám odkaz) a přihlaste se.\n\nPo přihlášení uvidíte firmu '+APP.co+'.\n\nS pozdravem\n'+(nm||APP.co)}
function inviteDone(email,failed){
 var tx=inviteText(email),sub='Pozvánka do firmy '+APP.co+' ve Vexaronetu';
 modal('<h3>Pozvánka je připravená</h3><p class="mut">'+(failed?'Pozvánka je uložená, ale e-mail se nepodařilo odeslat automaticky. Pošlete tento text sami:':'Text pozvánky, který můžete poslat znovu:')+'</p><textarea id="remTx" rows="10" readonly>'+esc(tx)+'</textarea><div class="dact"><a class="pri" href="mailto:'+encodeURIComponent(email)+'?subject='+encodeURIComponent(sub)+'&body='+encodeURIComponent(tx)+'">Otevřít v e-mailu</a><button class="btn btn-ghost" type="button" data-do="copy">Kopírovat text</button><button class="btn btn-ghost" type="button" data-app="mclose">Zavřít</button></div>')}

/* ---- AI Účetní ---- */
var ACCLIM={accountant:100,pro:150,business:500,enterprise:5000};
function accSt(t,c){var e=A('accSt');if(e){e.className='st '+(c||'');e.textContent=t}}
function accUse(u,l){var e=A('accUse');if(e)e.textContent='Zpracováno tento měsíc: '+u+' z '+l+' dokladů.'}
async function accUsage(){var e=A('accUse');if(!e)return;var lim=ACCLIM[effPlan()]||0,m0=new Date(Date.UTC(new Date().getUTCFullYear(),new Date().getUTCMonth(),1)).toISOString();
 try{var r=await getSb().from('ai_usage').select('id',{count:'exact',head:true}).eq('company_id',APP.cid).eq('kind','doc').gte('created_at',m0);
  if(r.error){e.textContent='Počítadlo dokladů ještě není nastavené v databázi (chybí tabulka ai_usage). Zpracování dokladů nebude fungovat, dokud ji správce nevytvoří.';e.className='mut fine err';return}
  accUse(r.count||0,lim)}catch(x){e.textContent=''}}
function monthKey(s){return String(s||'').slice(0,7)}
function accStats(){var d=APP.d,n=new Date(),k0=n.getFullYear()+'-'+('0'+(n.getMonth()+1)).slice(-2),p=new Date(n.getFullYear(),n.getMonth()-1,1),k1=p.getFullYear()+'-'+('0'+(p.getMonth()+1)).slice(-2),o={i0:0,e0:0,i1:0,e1:0};
 d.fe.rows.forEach(function(r){var v=Math.abs(Number(r.amount)||0),k=monthKey(r.entry_date||r.created_at),inc=isInc(r.kind);if(k===k0){if(inc)o.i0+=v;else o.e0+=v}else if(k===k1){if(inc)o.i1+=v;else o.e1+=v}});
 var un=d.invoices.rows.filter(function(x){return !x.paid_at}),t0=dayStart(0);o.unp=un.reduce(function(s,x){return s+Number(x.total||0)},0);o.unpN=un.length;o.ovN=un.filter(function(x){return x.due_on&&new Date(x.due_on)<t0}).length;return o}
function accChecks(){var d=APP.d,out=[],g={},t1=dayStart(1);
 d.fe.rows.forEach(function(r){var k=[r.kind,Math.abs(Number(r.amount)||0),String(r.entry_date||'').slice(0,10)].join('|');(g[k]=g[k]||[]).push(r)});
 Object.keys(g).forEach(function(k){if(g[k].length>1)out.push(['Možná duplicita: '+esc(g[k][0].title||'záznam'),g[k].length+'× stejná částka a datum'])});
 d.fe.rows.forEach(function(r){var v=Number(r.amount);if(!v)out.push(['Nulová nebo chybějící částka: '+esc(r.title||'záznam'),fD(r.entry_date)]);if(r.entry_date&&new Date(r.entry_date)>=new Date(t1.getTime()+864e5))out.push(['Datum v budoucnu: '+esc(r.title||'záznam'),fD(r.entry_date)])});
 var ov=overInv();if(ov.length)out.push(['Faktury po splatnosti',ov.length+' ('+fM(ov.reduce(function(s,x){return s+Number(x.total||0)},0))+')']);
 return out.slice(0,12)}
function accMsgs(){return (APP.accChat&&APP.accChat.length?APP.accChat:[{role:'assistant',content:'Dobrý den. Zeptejte se na příjmy, výdaje nebo faktury ve své evidenci.'}]).map(function(m){return '<div class="msg '+(m.role==='user'?'me':'bot')+'">'+esc(m.content)+'</div>'}).join('')}
async function accCall(payload){var ses=(await getSb().auth.getSession()).data.session;if(!ses)throw new Error('auth');var r=await dfetch('/api/accountant',{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+ses.access_token},body:JSON.stringify(Object.assign({cid:APP.cid},payload))});var j=await r.json().catch(function(){return null});return {r:r,j:j}}
function accErr(r,j){var c=j&&j.error;if(r.status===403)return 'AI Účetní je součástí tarifu AI Účetní a vyšších.';if(c==='limit')return 'Tento měsíc jste využili všech '+j.limit+' zpracovaných dokladů. Limit se obnoví začátkem dalšího měsíce.';if(r.status===429)return 'Příliš mnoho požadavků. Zkuste to za chvíli.';if(c==='usage_table')return 'Počítadlo dokladů ještě není nastavené v databázi. Napište nám na info@vexaronet.com.';if(c==='bad_file')return 'Soubor se nepodařilo přijmout. Použijte fotku (JPG, PNG, WebP, HEIC) nebo PDF do 6 MB.';if(c==='unreadable')return 'Doklad se nepodařilo přečíst. Zkuste ostřejší fotku nebo PDF.';if(c==='not_configured')return 'AI Účetní zatím není na serveru nastavená.';return 'AI Účetní teď není dostupná. Zkuste to později.'}

/* ===== Bankovní výpis (CSV) a párování plateb ===== */
var BK={rows:[]};
function bkNorm(x){return String(x||'').normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().trim()}
function bkSplit(line,d){var o=[],c='',q=false;for(var i=0;i<line.length;i++){var ch=line.charAt(i);if(ch==='"'){if(q&&line.charAt(i+1)==='"'){c+='"';i++}else q=!q}else if(ch===d&&!q){o.push(c);c=''}else c+=ch}o.push(c);return o}
function bkNum(v){var t=String(v==null?'':v).replace(/[\s ]/g,'').replace(/[^0-9,.\-+]/g,'');if(!t)return NaN;if(t.indexOf(',')>=0&&t.indexOf('.')>=0)t=t.replace(/\./g,'').replace(',','.');else t=t.replace(',','.');return parseFloat(t)}
function bkDate(v){var t=String(v||''),m=t.match(/(\d{1,2})\.\s?(\d{1,2})\.\s?(\d{4})/);if(m)return m[3]+'-'+('0'+m[2]).slice(-2)+'-'+('0'+m[1]).slice(-2);m=t.match(/(\d{4})-(\d{2})-(\d{2})/);return m?m[0]:''}
function bkParse(text){
 var ls=text.split(/\r?\n/).filter(function(l){return l.trim()});if(!ls.length)return {err:'Soubor je prázdný.'};
 var dl=';',bn=-1;[';',',','\t'].forEach(function(d){var n=ls.slice(0,15).reduce(function(a,l){return a+bkSplit(l,d).length-1},0);if(n>bn){bn=n;dl=d}});
 var hi=-1,col={};
 for(var i=0;i<Math.min(ls.length,40)&&hi<0;i++){var h=bkSplit(ls[i],dl).map(bkNorm),c={};
  h.forEach(function(x,j){
   if(c.d==null&&/^(datum|date|booking date|datum (zauctovani|provedeni|pohybu|transakce))/.test(x))c.d=j;
   else if(c.a==null&&/^(objem|castka|amount|hodnota|castka v|transaction amount)/.test(x))c.a=j;
   else if(c.v==null&&/(variabil|^vs$|variable)/.test(x))c.v=j;
   else if(c.n==null&&/(nazev protistrany|nazev uctu protistrany|protistrana|jmeno protistrany|counterparty|nazev uctu|^platce|^prijemce|^nazev$)/.test(x))c.n=j;
   else if(c.m==null&&/(zprava|poznamk|message|popis|uzivatelska identifikace|note)/.test(x))c.m=j;
   else if(c.c==null&&/^(mena|currency)/.test(x))c.c=j});
  if(c.d!=null&&c.a!=null){hi=i;col=c}}
 if(hi<0)return {err:'Nepodařilo se najít sloupce s datem a částkou. Použijte export pohybů na účtu ve formátu CSV (v internetovém bankovnictví hledejte „Export“ nebo „Stáhnout výpis“).'};
 var rows=[];
 for(var k=hi+1;k<ls.length&&rows.length<3000;k++){var p=bkSplit(ls[k],dl),dt=bkDate(p[col.d]),am=bkNum(p[col.a]);if(!dt||isNaN(am)||am===0)continue;
  rows.push({date:dt,amt:am,vs:col.v!=null?String(p[col.v]||'').replace(/\D/g,''):'',name:col.n!=null?String(p[col.n]||'').trim():'',msg:col.m!=null?String(p[col.m]||'').trim():'',cur:col.c!=null?String(p[col.c]||'').trim().toUpperCase():'CZK'})}
 if(!rows.length)return {err:'Ve výpisu jsem nenašel žádné platby.'};
 return {rows:rows}}
function bkMatch(rows){
 var inv=APP.d.invoices.rows.filter(function(x){return !x.paid_at}),used={};
 function z(v){return String(v||'').replace(/\D/g,'').replace(/^0+/,'')}
 var fe=APP.d.fe.rows;
 rows.forEach(function(r){
  r.act=null;r.on=false;r.note='';
  var kind=r.amt>0?'income':'expense',a=Math.abs(r.amt);
  if(fe.some(function(x){return Math.abs(Math.abs(Number(x.amount)||0)-a)<0.005&&String(x.entry_date||'').slice(0,10)===r.date&&(isInc(x.kind)?'income':'expense')===kind&&String(x.title||'')===(r.name||r.msg||'Bankovní pohyb')})){r.act='dup';r.note='Už je v evidenci.';return}
  if(r.amt>0){
   var cand=inv.filter(function(x){return !used[x.id]&&(x.currency||'CZK')===(r.cur||'CZK')}),hit=null,lvl='';
   if(r.vs){hit=cand.filter(function(x){return z(x.number)===z(r.vs)&&Math.abs(Number(x.total||0)-r.amt)<0.005})[0];if(hit)lvl='sure';
    else{hit=cand.filter(function(x){return z(x.number)===z(r.vs)})[0];if(hit)lvl='vs'}}
   if(!hit){var eq=cand.filter(function(x){return Math.abs(Number(x.total||0)-r.amt)<0.005});if(eq.length===1){hit=eq[0];lvl='maybe'}}
   if(hit){used[hit.id]=1;r.act='pay';r.inv=hit;r.on=(lvl==='sure');r.note=lvl==='sure'?'Sedí variabilní symbol i částka.':lvl==='vs'?'Sedí variabilní symbol, ale částka se liší ('+fM(hit.total,hit.currency)+').':'Sedí částka, variabilní symbol chybí. Zkontrolujte.';return}
   r.act='inc';r.note='Žádná faktura nesedí. Můžete zapsat jako příjem.';return}
  r.act='exp';r.note='Můžete zapsat jako výdaj.'});
 return rows}
function bkView(){
 var rs=BK.rows;if(!rs.length)return '';
 var pay=rs.filter(function(r){return r.act==='pay'&&r.on}).length;
 return '<p class="mut">Načteno '+rs.length+' plateb. Předvybrané jsou jen jistě sedící platby faktur. Ostatní si zaškrtněte sami, nic se neuloží, dokud nepotvrdíte.</p><ul class="rows big bkl">'+rs.map(function(r,i){
  var lab=r.act==='pay'?'Označit fakturu '+esc(r.inv.number||'')+' jako zaplacenou':r.act==='inc'?'Zapsat jako příjem':r.act==='exp'?'Zapsat jako výdaj':'';
  return '<li'+(r.act==='dup'?' class="off"':'')+'><label class="bkr"><input type="checkbox" data-bkrow="'+i+'"'+(r.on?' checked':'')+(r.act==='dup'?' disabled':'')+'><span><b>'+esc(r.name||r.msg||'Bankovní pohyb')+'</b><small>'+fD(r.date)+(r.vs?' · VS '+esc(r.vs):'')+' · '+esc(lab||'Přeskočeno')+' · '+esc(r.note)+'</small></span></label><span class="'+(r.amt>0?'inc':'')+'">'+(r.amt>0?'+':'−')+fM(Math.abs(r.amt),r.cur&&r.cur!=='CZK'?r.cur:'')+'</span></li>'}).join('')+'</ul><div class="dact"><button class="pri" type="button" data-acc="bk-apply">Potvrdit vybrané</button><button class="btn btn-ghost btn-sm" type="button" data-acc="bk-clear">Zrušit</button></div>'}
function bkSt(t,c){var e=A('bkSt');if(e){e.className='st '+(c||'');e.textContent=t}}
async function bkLoad(text){
 var o=bkParse(text);if(o.err){bkSt(o.err,'err');return}
 BK.rows=bkMatch(o.rows);A('bkRes').innerHTML=bkView();bkSt('Výpis načten. Zkontrolujte návrhy níže.','ok')}
async function bkFile(){
 var fi=A('bkFile'),f=fi&&fi.files&&fi.files[0];if(!f){bkSt('Vyberte soubor s výpisem (CSV).','err');return}
 if(f.size>2e6){bkSt('Soubor je příliš velký (nejvýše 2 MB).','err');return}
 try{var buf=await f.arrayBuffer();await bkLoad(bkDec(buf))}catch(e){bkSt('Soubor se nepodařilo přečíst.','err')}}
function bkDec(buf){var t=new TextDecoder('utf-8').decode(buf);if(t.indexOf('�')>=0){try{t=new TextDecoder('windows-1250').decode(buf)}catch(e){}}return t.replace(/^﻿/,'')}
function bkDemo(){
 var un=APP.d.invoices.rows.filter(function(x){return !x.paid_at}).slice(0,2),L=['Datum;Objem;Měna;Protiúčet;Název protistrany;Variabilní symbol;Zpráva pro příjemce'];
 un.forEach(function(x,i){var cu=x.customer_snapshot&&typeof x.customer_snapshot==='object'?(x.customer_snapshot.name||''):'';var d=new Date();d.setDate(d.getDate()-1-i);L.push(d.getDate()+'.'+(d.getMonth()+1)+'.'+d.getFullYear()+';'+String(Number(x.total||0)).replace('.',',')+';CZK;123456789/0800;'+(cu||'Zákazník')+';'+String(x.number||'').replace(/\D/g,'')+';Platba faktury')});
 var t=new Date();L.push(t.getDate()+'.'+(t.getMonth()+1)+'.'+t.getFullYear()+';-1250,00;CZK;987654321/0100;Kancelářské potřeby;;Nákup materiálu');
 L.push(t.getDate()+'.'+(t.getMonth()+1)+'.'+t.getFullYear()+';890,00;CZK;111222333/0300;Neznámý plátce;;Platba kartou terminál');
 bkLoad(L.join('\n'))}
async function bkApply(){
 var sel=BK.rows.filter(function(r){return r.on&&r.act&&r.act!=='dup'});if(!sel.length){bkSt('Nic není vybráno.','err');return}
 if(APP.busy)return;APP.busy=true;var okp=0,oke=0,bad=0;
 try{
  for(var i=0;i<sel.length;i++){var r=sel[i];if(r.act==='pay'){var pr=await rpcInv('paid',{id:r.inv.id,payment_date:r.date});if(pr.error)bad++;else okp++}}
  var ents=sel.filter(function(r){return r.act==='inc'||r.act==='exp'}).map(function(r){return {company_id:APP.cid,title:(r.name||r.msg||'Bankovní pohyb').slice(0,120),amount:Math.abs(r.amt),kind:r.act==='inc'?'income':'expense',entry_date:r.date}});
  if(ents.length){var er=await getSb().from('financial_entries').insert(ents);if(er.error)bad+=ents.length;else oke=ents.length}
 }finally{APP.busy=false}
 BK.rows=[];await refresh();appTab('ucetni');
 toast(bad?'Uloženo '+(okp+oke)+', nepodařilo se '+bad+'.':'Hotovo: '+okp+' zaplacených faktur, '+oke+' nových záznamů.',bad?'err':'ok')}

/* ===== Jednoduchý web: editor, AI návrh, veřejná stránka ===== */
var WEBN=6,WEBG=6;
function webDef(){var pr=(APP.d.booking_profiles.rows[0])||{};return {color:'#6d5cff',font:'sans',hero:{title:APP.co||'Vaše firma',subtitle:'',cta:'Kontaktujte nás',image:''},about:{title:'O nás',text:''},services:[],contact:{phone:pr.phone||'',email:'',address:pr.address||'',hours:''},booking:false,footer:'',style:'light',logo:'',gallery:[],reviews:[],faq:[],social:{facebook:'',instagram:''},map:false,shop:false,shopSlug:''}}
function webUrl(slug){return (location.protocol==='file:'||DEMO?'https://vexaronet.com':location.origin)+'/?w='+slug}
function webSafeTel(v){return String(v||'').replace(/[^0-9+]/g,'').slice(0,20)}
function webOk(v){return /^[^\s@<>"]+@[^\s@<>"]+\.[^\s@<>"]+$/.test(String(v||''))}
function webImg(u){u=String(u||'').trim();return /^https:\/\/[^\s"'<>\\]{4,400}$/i.test(u)?u:''}
var WEBTH={light:{bg:'#ffffff',tx:'#1b1e2e',alt:'#f6f7fb',bd:'#e6e8f2',mu:'#4a4f66',cb:'#ffffff',ft:'#7b8199'},dark:{bg:'#0f1220',tx:'#e9ecf8',alt:'#161a2e',bd:'#2a3050',mu:'#b3b9d6',cb:'#1b2038',ft:'#8f96b8'},warm:{bg:'#fffaf3',tx:'#2a211a',alt:'#f8efe2',bd:'#eadfce',mu:'#5e5146',cb:'#fffdf9',ft:'#8a7c6d'}};
var WEBFF={sans:"-apple-system,'Segoe UI',Roboto,Arial,sans-serif",serif:"Georgia,'Times New Roman',serif",round:"ui-rounded,'Trebuchet MS','Segoe UI',Verdana,sans-serif",mono:"ui-monospace,'SF Mono',Consolas,'Courier New',monospace"};
function webLum(h){var n=parseInt(h.slice(1),16),r=n>>16&255,g=n>>8&255,b=n&255;return (0.2126*r+0.7152*g+0.0722*b)/255}
var WEBIC={ph:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>',ml:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>',pn:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s7-5.6 7-11a7 7 0 1 0-14 0c0 5.4 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/></svg>',ck:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>'};
function siteHTML(d,o){o=o||{};d=d||{};
 var col=/^#[0-9a-f]{6}$/i.test(d.color||'')?d.color:'#6d5cff',ff=WEBFF[d.font]||WEBFF.sans,T=WEBTH[d.style]||WEBTH.light,onc=webLum(col)>0.62?'#14161f':'#ffffff';
 var H=d.hero||{},Ab=d.about||{},C=d.contact||{},sv=(d.services||[]).filter(function(x){return x&&x.name}),nm=o.name||'';
 var gal=(d.gallery||[]).map(webImg).filter(Boolean),rev=(d.reviews||[]).filter(function(x){return x&&x.text}),faq=(d.faq||[]).filter(function(x){return x&&x.q&&x.a}),so=d.social||{};
 var himg=webImg(H.image),logo=webImg(d.logo),tel=webSafeTel(C.phone),mail=webOk(C.email);
 function nl(t){return esc(t).replace(/\n/g,'<br>')}
 var bk=d.booking&&o.bookUrl?o.bookUrl:'',shop=d.shop&&d.shopSlug&&/^[a-z0-9-]{3,40}$/.test(d.shopSlug)?(o.shopUrl||shopUrl(d.shopSlug)):'';
 var ini=esc((nm||H.title||'W').trim().charAt(0).toUpperCase()),fav='data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="'+col+'"/><text x="32" y="44" font-size="36" font-family="Arial" font-weight="700" text-anchor="middle" fill="'+onc+'">'+(nm||H.title||'W').trim().charAt(0).toUpperCase().replace(/[<>&"]/g,'')+'</text></svg>');
 var hasCt=!!(tel||mail||C.address||C.hours||webImg(so.facebook)||webImg(so.instagram));
 var cta=bk?'<a class="b b1" href="'+esc(bk)+'" target="_top">'+esc(H.cta||'Rezervovat termín')+'</a>':(tel?'<a class="b b1" href="tel:'+tel+'" target="_top">'+esc(H.cta||'Zavolejte nám')+'</a>':(hasCt?'<a class="b b1" href="#kontakt">'+esc(H.cta||'Kontaktujte nás')+'</a>':''));
 if(shop)cta+='<a class="b b2" href="'+esc(shop)+'" target="_top">E-shop</a>';else if(sv.length)cta+='<a class="b b2" href="#sluzby">Naše služby</a>';
 var chips=[];if(C.hours)chips.push(WEBIC.ck+'<span>'+esc(String(C.hours).split('\n')[0])+'</span>');if(C.address)chips.push(WEBIC.pn+'<span>'+esc(C.address)+'</span>');
 var heroBg=himg?'linear-gradient(105deg,rgba(8,10,20,.78),rgba(8,10,20,.35)),url(\''+himg+'\') center/cover no-repeat':'radial-gradient(circle at 85% 15%,color-mix(in srgb,var(--c) 70%,#fff) 0,transparent 42%),radial-gradient(circle at 10% 110%,color-mix(in srgb,var(--c) 55%,#000) 0,transparent 55%),linear-gradient(135deg,color-mix(in srgb,var(--c) 82%,#000),color-mix(in srgb,var(--c) 38%,#05060c))';
 var nav=[];if(Ab.text)nav.push(['o-nas',Ab.title||'O nás']);if(sv.length)nav.push(['sluzby','Služby']);if(gal.length)nav.push(['galerie','Galerie']);if(rev.length)nav.push(['reference','Reference']);if(faq.length)nav.push(['otazky','Otázky']);var news=(o.news||[]).filter(function(x){return x&&x.title&&x.body}).slice(0,6);if(news.length)nav.push(['novinky','Novinky']);
 var h='<!doctype html><html lang="cs"><head><meta charset="utf-8"><base href="about:srcdoc"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+esc(H.title||nm)+'</title><meta name="description" content="'+esc(H.subtitle||'')+'"><meta name="theme-color" content="'+col+'"><link rel="icon" href="'+fav+'"><meta property="og:title" content="'+esc(H.title||nm)+'"><meta property="og:description" content="'+esc(H.subtitle||'')+'">'+(himg?'<meta property="og:image" content="'+esc(himg)+'">':'')+'<style>'
 +':root{--c:'+col+';--on:'+onc+';--bg:'+T.bg+';--tx:'+T.tx+';--alt:'+T.alt+';--bd:'+T.bd+';--mu:'+T.mu+';--cb:'+T.cb+';--t:color-mix(in srgb,var(--c) 11%,var(--bg))}*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:74px}body{margin:0;font-family:'+ff+';color:var(--tx);line-height:1.65;background:var(--bg);-webkit-font-smoothing:antialiased}img{max-width:100%}a{color:var(--c)}svg{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round;flex:none}'+(o.prev?'a{pointer-events:none}':'')
 +'.w{max-width:1040px;margin:0 auto;padding:0 22px}'
 +'.top{position:sticky;top:0;z-index:9;background:color-mix(in srgb,var(--bg) 88%,transparent);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);border-bottom:1px solid var(--bd)}.top .w{display:flex;align-items:center;justify-content:space-between;gap:16px;height:64px}.br{display:flex;align-items:center;gap:10px;font-weight:800;font-size:18px;letter-spacing:-.01em;color:var(--tx);text-decoration:none}.br img{height:34px;width:auto;border-radius:8px}.br i{width:34px;height:34px;border-radius:10px;background:var(--c);color:var(--on);display:grid;place-items:center;font-style:normal;font-size:17px}'
 +'.nv{display:flex;align-items:center;gap:22px}.nv a{color:var(--mu);text-decoration:none;font-weight:600;font-size:14.5px}.nv a:hover{color:var(--c)}.nv .nb{background:var(--c);color:var(--on);padding:9px 18px;border-radius:999px}.nv .nb:hover{color:var(--on);filter:brightness(1.08)}'
 +'.hero{background:'+heroBg+';color:#fff;position:relative;overflow:hidden}.hero .w{padding-top:'+(himg?'120px':'88px')+';padding-bottom:'+(himg?'120px':'92px')+'}.hero h1{font-size:clamp(32px,5.6vw,58px);line-height:1.08;letter-spacing:-.025em;margin:0 0 18px;max-width:780px;text-wrap:balance}.hero p{font-size:clamp(17px,2.3vw,21px);margin:0 0 30px;max-width:620px;opacity:.93}'
 +'.b{display:inline-flex;align-items:center;gap:8px;padding:14px 28px;border-radius:999px;font-weight:700;text-decoration:none;margin:0 10px 10px 0;transition:transform .18s,box-shadow .18s,filter .18s}.b:hover{transform:translateY(-2px)}.b1{background:#fff;color:#14161f;box-shadow:0 10px 28px rgba(0,0,0,.28)}.b2{color:#fff;border:2px solid rgba(255,255,255,.7)}.b2:hover{background:rgba(255,255,255,.12)}'
 +'.ch{display:flex;flex-wrap:wrap;gap:10px;margin-top:22px}.ch span{display:inline-flex}.ch div{display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.28);border-radius:999px;padding:8px 16px;font-size:14px;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px)}.ch svg{width:17px;height:17px}'
 +'section{padding:84px 0}.alt{background:var(--alt)}.ey{display:block;font-size:12.5px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--c);margin:0 0 10px}h2{font-size:clamp(26px,3.6vw,38px);line-height:1.15;letter-spacing:-.02em;margin:0 0 28px}'
 +'.ab{display:grid;gap:30px;grid-template-columns:1.1fr .9fr;align-items:start}.ab p{font-size:18px;color:var(--mu);margin:0}.ab .fa{background:var(--t);border-radius:20px;padding:26px;display:grid;gap:14px}.fa div{display:flex;align-items:flex-start;gap:12px;color:var(--tx);font-weight:600}.fa svg{color:var(--c);margin-top:2px}'
 +'.g{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:18px}.card{position:relative;border:1px solid var(--bd);background:var(--cb);border-radius:20px;padding:26px;transition:transform .2s,box-shadow .2s,border-color .2s}.card:hover{transform:translateY(-4px);box-shadow:0 16px 36px rgba(20,22,40,.12);border-color:color-mix(in srgb,var(--c) 45%,var(--bd))}.card .n{width:42px;height:42px;border-radius:12px;background:var(--t);color:var(--c);display:grid;place-items:center;font-weight:800;margin-bottom:16px}.card h3{margin:0 0 8px;font-size:19px;letter-spacing:-.01em}.card p{margin:0;color:var(--mu);font-size:15.5px}.card .pr{display:inline-block;margin-top:14px;font-weight:800;color:var(--c);background:var(--t);padding:5px 12px;border-radius:999px;font-size:14px}'
 +'.gl{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:14px}.gl img{width:100%;aspect-ratio:4/3;object-fit:cover;border-radius:18px;display:block;transition:transform .3s,box-shadow .3s}.gl img:hover{transform:scale(1.02);box-shadow:0 14px 32px rgba(0,0,0,.22)}'
 +'.q{padding-top:34px}.q:before{content:"“";position:absolute;top:6px;left:22px;font-size:64px;line-height:1;color:var(--c);opacity:.35;font-family:Georgia,serif}.q p{font-size:17px;color:var(--tx);font-style:normal}.q small{display:block;margin-top:14px;color:var(--mu);font-weight:700}'
 +'details{border:1px solid var(--bd);background:var(--cb);border-radius:16px;padding:0;margin:0 0 12px;overflow:hidden}summary{cursor:pointer;font-weight:700;padding:18px 22px;list-style:none;display:flex;justify-content:space-between;gap:16px;align-items:center}summary::-webkit-details-marker{display:none}summary:after{content:"+";font-size:24px;line-height:1;color:var(--c);font-weight:400;transition:transform .2s}details[open] summary:after{transform:rotate(45deg)}details[open]{border-color:color-mix(in srgb,var(--c) 40%,var(--bd))}details p{margin:0;padding:0 22px 20px;color:var(--mu)}'
 +'.band{background:'+heroBg+';color:#fff;padding:64px 0;text-align:center}.band h2{margin:0 0 10px;color:#fff}.band p{margin:0 0 24px;opacity:.9}.band .b{margin:0 6px 10px}'
 +'.ct{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px}.ci{display:flex;gap:14px;align-items:flex-start;background:var(--cb);border:1px solid var(--bd);border-radius:18px;padding:20px}.ci i{width:42px;height:42px;border-radius:12px;background:var(--t);color:var(--c);display:grid;place-items:center;flex:none}.ci b{display:block;font-size:13px;color:var(--mu);font-weight:700;margin-bottom:2px}.ci span,.ci a{font-weight:600;color:var(--tx);text-decoration:none;word-break:break-word}.ci a:hover{color:var(--c)}'
 +'.soc{display:flex;flex-wrap:wrap;gap:10px;margin-top:20px}.soc a{border:1px solid var(--bd);background:var(--cb);color:var(--tx);text-decoration:none;font-weight:700;border-radius:999px;padding:10px 20px}.soc a:hover{border-color:var(--c);color:var(--c)}'
 +'footer{background:var(--alt);border-top:1px solid var(--bd);padding:30px 0 '+(tel?'92px':'30px')+';color:'+T.ft+';font-size:14px}footer .w{display:flex;flex-wrap:wrap;justify-content:space-between;gap:10px 24px}footer a{color:inherit}'
 +'.call{position:fixed;left:16px;right:16px;bottom:14px;background:var(--c);color:var(--on);text-align:center;padding:15px;border-radius:999px;font-weight:800;text-decoration:none;box-shadow:0 10px 28px rgba(0,0,0,.3);display:none;z-index:9}'
 +'@keyframes up{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:none}}.hero .w>*{animation:up .7s both}.hero .w>*:nth-child(2){animation-delay:.1s}.hero .w>*:nth-child(3){animation-delay:.2s}.hero .w>*:nth-child(4){animation-delay:.3s}@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important;scroll-behavior:auto!important}}'
 +'a:focus-visible,summary:focus-visible{outline:3px solid var(--c);outline-offset:3px}'
 +'@media(max-width:760px){.nv a:not(.nb){display:none}section{padding:56px 0}.ab{grid-template-columns:1fr}.hero .w{padding-top:'+(himg?'84px':'60px')+';padding-bottom:'+(himg?'84px':'62px')+'}.call{display:block}.b{padding:13px 22px}}'
 +'</style></head><body'+(o.prev?' class="prev"':'')+'><header class="top"><div class="w"><a class="br" href="#">'+(logo?'<img src="'+esc(logo)+'" alt="">':'<i>'+ini+'</i>')+'<span>'+esc(nm||H.title||'')+'</span></a><nav class="nv">'+nav.map(function(x){return '<a href="#'+x[0]+'">'+esc(x[1])+'</a>'}).join('')+(bk?'<a class="nb" href="'+esc(bk)+'" target="_top">Rezervace</a>':(hasCt?'<a class="nb" href="#kontakt">Kontakt</a>':''))+'</nav></div></header>'
 +'<div class="hero"><div class="w"><h1>'+esc(H.title||nm)+'</h1>'+(H.subtitle?'<p>'+esc(H.subtitle)+'</p>':'<span></span>')+'<div>'+cta+'</div>'+(chips.length?'<div class="ch">'+chips.map(function(c){return '<div>'+c+'</div>'}).join('')+'</div>':'<span></span>')+'</div></div>';
 var fa=[];if(C.hours)fa.push('<div>'+WEBIC.ck+'<span>'+nl(C.hours)+'</span></div>');if(C.address)fa.push('<div>'+WEBIC.pn+'<span>'+esc(C.address)+'</span></div>');if(tel)fa.push('<div>'+WEBIC.ph+'<span>'+esc(C.phone)+'</span></div>');
 if(Ab.text)h+='<section id="o-nas"><div class="w"><span class="ey">Kdo jsme</span><h2>'+esc(Ab.title||'O nás')+'</h2><div class="ab"><p>'+nl(Ab.text)+'</p>'+(fa.length?'<div class="fa">'+fa.join('')+'</div>':'<span></span>')+'</div></div></section>';
 if(sv.length)h+='<section id="sluzby" class="alt"><div class="w"><span class="ey">Co nabízíme</span><h2>Služby</h2><div class="g">'+sv.map(function(x,k){return '<div class="card"><div class="n">'+(k+1)+'</div><h3>'+esc(x.name)+'</h3>'+(x.desc?'<p>'+esc(x.desc)+'</p>':'')+(x.price?'<span class="pr">'+esc(x.price)+'</span>':'')+'</div>'}).join('')+'</div></div></section>';
 if(gal.length)h+='<section id="galerie"><div class="w"><span class="ey">Ukázky</span><h2>Galerie</h2><div class="gl">'+gal.map(function(u){return '<img src="'+esc(u)+'" alt="" loading="lazy">'}).join('')+'</div></div></section>';
 if(rev.length)h+='<section id="reference" class="alt"><div class="w"><span class="ey">Reference</span><h2>Co říkají zákazníci</h2><div class="g">'+rev.map(function(x){return '<div class="card q"><p>'+esc(x.text)+'</p>'+(x.who?'<small>'+esc(x.who)+'</small>':'')+'</div>'}).join('')+'</div></div></section>';
 if(news.length)h+='<section id="novinky" class="alt"><div class="w" style="max-width:820px"><span class="ey">Aktuálně</span><h2>Novinky</h2>'+news.map(function(x){var dt=/^\d{4}-\d{2}-\d{2}$/.test(x.date||'')?x.date.split('-').reverse().map(Number).join('. '):'';return '<article class="card" style="margin-bottom:14px">'+(dt?'<small>'+esc(dt)+'</small>':'')+'<h3>'+esc(x.title)+'</h3><p>'+nl(x.body)+'</p></article>'}).join('')+'</div></section>';
 if(faq.length)h+='<section id="otazky"><div class="w" style="max-width:820px"><span class="ey">Dotazy</span><h2>Časté otázky</h2>'+faq.map(function(x){return '<details><summary>'+esc(x.q)+'</summary><p>'+nl(x.a)+'</p></details>'}).join('')+'</div></section>';
 if(tel||bk||shop)h+='<div class="band"><div class="w"><h2>Ozvěte se nám</h2><p>'+(H.subtitle?esc(H.subtitle):'Rádi vám pomůžeme.')+'</p>'+(bk?'<a class="b b1" href="'+esc(bk)+'" target="_top">Rezervovat termín online</a>':'')+(tel?'<a class="b '+(bk?'b2':'b1')+'" href="tel:'+tel+'" target="_top">Zavolat '+esc(C.phone)+'</a>':'')+(shop?'<a class="b b2" href="'+esc(shop)+'" target="_top">E-shop</a>':'')+'</div></div>';
 var cl=[];if(tel)cl.push('<div class="ci"><i>'+WEBIC.ph+'</i><div><b>Telefon</b><a href="tel:'+tel+'" target="_top">'+esc(C.phone)+'</a></div></div>');if(mail)cl.push('<div class="ci"><i>'+WEBIC.ml+'</i><div><b>E-mail</b><a href="mailto:'+esc(C.email)+'" target="_top">'+esc(C.email)+'</a></div></div>');
 if(C.address)cl.push('<div class="ci"><i>'+WEBIC.pn+'</i><div><b>Adresa</b><span>'+esc(C.address)+'</span>'+(d.map?'<br><a href="https://mapy.cz/zakladni?q='+encodeURIComponent(C.address)+'" target="_blank" rel="noopener">Zobrazit na mapě</a>':'')+'</div></div>');if(C.hours)cl.push('<div class="ci"><i>'+WEBIC.ck+'</i><div><b>Otevírací doba</b><span>'+nl(C.hours)+'</span></div></div>');
 var sl=[];if(webImg(so.facebook))sl.push('<a href="'+esc(webImg(so.facebook))+'" target="_blank" rel="noopener">Facebook</a>');if(webImg(so.instagram))sl.push('<a href="'+esc(webImg(so.instagram))+'" target="_blank" rel="noopener">Instagram</a>');
 if(cl.length||sl.length)h+='<section id="kontakt"><div class="w"><span class="ey">Kde nás najdete</span><h2>Kontakt</h2><div class="ct">'+cl.join('')+'</div>'+(sl.length?'<div class="soc">'+sl.join('')+'</div>':'')+'</div></section>';
 h+='<footer><div class="w"><span>'+(d.footer?esc(d.footer):'© '+esc(nm||H.title||''))+'</span><span>Web vytvořený ve <a href="https://vexaronet.com" target="_top">Vexaronetu</a></span></div></footer>'+(tel?'<a class="call" href="tel:'+tel+'" target="_top">'+esc('Zavolat: '+C.phone)+'</a>':'')+'</body></html>';
 return h}
function webView(){
 var S=APP.d.sites;if(S.err)return '<div class="draft">Editor webu vyžaduje dokončit nastavení databáze (SQL schema_web). Detail: '+esc(S.err)+'</div>';
 var row=S.rows[0]||null,d=Object.assign(webDef(),row&&row.data||{}),slug=row?row.slug:slugify(APP.co),mg=APP.role==='owner'||APP.role==='admin';
 d.hero=Object.assign(webDef().hero,d.hero);d.about=Object.assign(webDef().about,d.about);d.contact=Object.assign(webDef().contact,d.contact);d.services=d.services||[];
 var bp=APP.d.booking_profiles.rows[0],bkOn=!!(bp&&bp.enabled);
 function f(id,l,v,m,t){return '<div class="f full"><label for="'+id+'">'+l+'</label>'+(t==='ta'?'<textarea id="'+id+'" rows="3" maxlength="'+m+'">'+esc(v||'')+'</textarea>':'<input id="'+id+'" maxlength="'+m+'" value="'+esc(v||'')+'">')+'</div>'}
 function fi(id,l,v){return '<div class="f full"><label for="'+id+'">'+l+'</label><input id="'+id+'" maxlength="400" value="'+esc(v||'')+'"><div class="upr"><label class="btn btn-ghost btn-sm">Nahrát obrázek<input type="file" accept="image/jpeg,image/png,image/webp,image/gif" data-up="'+id+'" hidden></label><small class="mut">nebo vložte odkaz výše</small></div></div>'}
 var h='<div class="card2 note"><b>Jednoduchý firemní web na jedné stránce.</b> Napíšete texty (nebo si je nechte navrhnout AI), zvolíte barvu a zapnete publikování. Web se zobrazí na vašem odkazu '+esc(location.host||'vexaronet.com')+'/?w=… Vlastní doména zatím není k dispozici. AI jen navrhuje text, nic nepublikuje, o zveřejnění rozhodujete vy.</div>';
 if(row)h+='<div class="card2 bklink"><div><small class="mut">Odkaz na váš web'+(row.enabled?'':' (zatím je vypnutý)')+'</small><b>'+esc(webUrl(row.slug))+'</b>'+(DEMO?'<small class="mut">V ukázce odkaz na internetu nefunguje, tlačítko níže otevře náhled.</small>':'')+'</div><div class="dact">'+(DEMO?'':'<button type="button" class="btn btn-ghost btn-sm" data-web="copy">Kopírovat odkaz</button>')+'</div></div>';
 h+='<div class="webw"><form id="webForm" class="card2"><h3>Obsah webu</h3>'
 +'<div class="webai"><h4>Návrh textů od AI</h4><p class="mut fine">Popište, čím se zabýváte, pro koho a co nabízíte. AI navrhne nadpis, text o firmě a služby. Návrh se jen vyplní do formuláře, zkontrolujte ho a uložte.'+(hasCeo()?'':' Tato funkce je v tarifu PRO a vyšších.')+'</p><div class="f full"><label for="w_ai">Popis firmy</label><textarea id="w_ai" rows="3" maxlength="900" placeholder="Např. Rodinný autoservis v Plzni, děláme servis, pneuservis a STK přípravu pro místní řidiče a malé firmy."></textarea></div><div class="dact"><button type="button" class="btn btn-ghost btn-sm" data-web="ai"'+(hasCeo()?'':' disabled')+'>Navrhnout texty s AI</button></div><div class="st" id="webAiSt" role="status"></div></div>'
 +'<h4 style="margin:14px 0 6px">Hlavní část</h4>'+f('w_ht','Hlavní nadpis',d.hero.title,80)+f('w_hs','Podnadpis',d.hero.subtitle,160)+f('w_hc','Text tlačítka',d.hero.cta,30)
 +'<h4 style="margin:14px 0 6px">O firmě</h4>'+f('w_at','Nadpis sekce',d.about.title,60)+f('w_ax','Text',d.about.text,700,'ta')
 +'<h4 style="margin:14px 0 6px">Služby (až '+WEBN+')</h4>'+Array.apply(null,Array(WEBN)).map(function(_,i){var x=d.services[i]||{};return '<div class="fg webs"><div class="f"><label for="w_sn'+i+'">Služba '+(i+1)+'</label><input id="w_sn'+i+'" maxlength="60" value="'+esc(x.name||'')+'"></div><div class="f"><label for="w_sp'+i+'">Cena (nepovinné)</label><input id="w_sp'+i+'" maxlength="40" value="'+esc(x.price||'')+'" placeholder="např. od 500 Kč"></div><div class="f full"><label for="w_sd'+i+'">Popis</label><input id="w_sd'+i+'" maxlength="200" value="'+esc(x.desc||'')+'"></div></div>'}).join('')
 +'<h4 style="margin:14px 0 6px">Obrázky</h4><p class="mut fine">Nahrajte obrázek (JPG, PNG, WebP nebo GIF do 3 MB) nebo vložte odkaz začínající https://. Nahrané obrázky jsou veřejné, nahrávejte jen to, co chcete zveřejnit.</p>'+fi('w_hi','Obrázek v záhlaví (nepovinné)',d.hero.image)+fi('w_lg','Logo (nepovinné)',d.logo)
 +'<h4 style="margin:14px 0 6px">Galerie (až '+WEBG+' obrázků)</h4>'+Array.apply(null,Array(WEBG)).map(function(_,i){return fi('w_g'+i,'Obrázek '+(i+1),(d.gallery||[])[i])}).join('')
 +'<h4 style="margin:14px 0 6px">Reference (až 3)</h4><p class="mut fine">Napište jen skutečné recenze od vašich zákazníků a se souhlasem autora.</p>'+Array.apply(null,Array(3)).map(function(_,i){var x=(d.reviews||[])[i]||{};return '<div class="fg webs"><div class="f"><label for="w_rt'+i+'">Text reference '+(i+1)+'</label><input id="w_rt'+i+'" maxlength="300" value="'+esc(x.text||'')+'"></div><div class="f"><label for="w_rw'+i+'">Kdo (jméno, firma)</label><input id="w_rw'+i+'" maxlength="80" value="'+esc(x.who||'')+'"></div></div>'}).join('')
 +'<h4 style="margin:14px 0 6px">Časté otázky (až 5)</h4>'+Array.apply(null,Array(5)).map(function(_,i){var x=(d.faq||[])[i]||{};return '<div class="fg webs"><div class="f"><label for="w_fq'+i+'">Otázka '+(i+1)+'</label><input id="w_fq'+i+'" maxlength="140" value="'+esc(x.q||'')+'"></div><div class="f"><label for="w_fa'+i+'">Odpověď</label><input id="w_fa'+i+'" maxlength="400" value="'+esc(x.a||'')+'"></div></div>'}).join('')
 +'<h4 style="margin:14px 0 6px">Kontakt</h4><div class="fg"><div class="f"><label for="w_cp">Telefon</label><input id="w_cp" maxlength="40" value="'+esc(d.contact.phone)+'"></div><div class="f"><label for="w_ce">E-mail</label><input id="w_ce" maxlength="120" value="'+esc(d.contact.email)+'"></div></div>'+f('w_ca','Adresa',d.contact.address,200)+f('w_ch','Otevírací doba',d.contact.hours,200)+'<div class="f full"><label class="chk"><input type="checkbox" id="w_map"'+(d.map?' checked':'')+'><span>Přidat odkaz „Zobrazit na mapě“ (Mapy.cz) k adrese</span></label></div>'+f('w_fb','Facebook (odkaz začínající https://)',(d.social||{}).facebook,300)+f('w_ig','Instagram (odkaz začínající https://)',(d.social||{}).instagram,300)
 +'<h4 style="margin:14px 0 6px">Vzhled a publikování</h4><div class="fg"><div class="f"><label for="w_col">Hlavní barva</label><input id="w_col" type="color" value="'+esc(/^#[0-9a-f]{6}$/i.test(d.color)?d.color:'#6d5cff')+'"></div><div class="f"><label for="w_style">Vzhled stránky</label><select id="w_style"><option value="light"'+((d.style||'light')==='light'?' selected':'')+'>Světlý</option><option value="dark"'+(d.style==='dark'?' selected':'')+'>Tmavý</option><option value="warm"'+(d.style==='warm'?' selected':'')+'>Teplý (krémový)</option></select></div><div class="f"><label for="w_font">Písmo</label><select id="w_font"><option value="sans"'+((d.font||'sans')==='sans'?' selected':'')+'>Moderní (bezpatkové)</option><option value="round"'+(d.font==='round'?' selected':'')+'>Zaoblené</option><option value="mono"'+(d.font==='mono'?' selected':'')+'>Technické (neproporcionální)</option><option value="serif"'+(d.font==='serif'?' selected':'')+'>Klasické (patkové)</option></select></div></div>'
 +'<div class="f full"><label class="chk"><input type="checkbox" id="w_bk"'+(d.booking?' checked':'')+(bkOn?'':' disabled')+'><span>Zobrazit tlačítko online rezervace'+(bkOn?'':' (nejdřív zapněte stránku v záložce Online rezervace)')+'</span></label></div>'
 +(function(){var sh=APP.d.shop_settings&&APP.d.shop_settings.rows&&APP.d.shop_settings.rows[0],on=!!(sh&&sh.enabled&&sh.slug);return '<div class="f full"><label class="chk"><input type="checkbox" id="w_shop"'+(d.shop&&on?' checked':'')+(on?'':' disabled')+'><span>Zobrazit tlačítko E-shop'+(on?'':' (nejdřív zapněte e-shop v modulu E-shop)')+'</span></label></div>'})()
 +f('w_ft','Text v patičce (nepovinné)',d.footer,120)
 +'<div class="f full"><label for="w_slug">Adresa webu</label><div class="slugr"><span>'+esc(location.host||'vexaronet.com')+'/?w=</span><input id="w_slug" value="'+esc(slug)+'" maxlength="41" autocomplete="off"></div></div>'
 +'<div class="f full"><label class="chk"><input type="checkbox" id="w_on"'+(row&&row.enabled?' checked':'')+'><span>Web je zapnutý (veřejně viditelný)</span></label></div>'
 +'<div class="st" id="entSt" role="status"></div><div class="dact"><button class="btn btn-main" type="submit"'+(mg?'':' disabled')+'>Uložit web</button><button type="button" class="btn btn-ghost" data-web="open">Zobrazit celou stránku</button></div>'+(mg?'':'<p class="mut fine">Web mohou upravovat jen majitel a správce.</p>')+'</form>'
 +'<aside class="card2 webp"><h3>Náhled</h3><iframe id="webFr" title="Náhled webu" sandbox="" class="webfr"></iframe></aside></div>';
 return h}
function webRead(){
 var g=function(id){var e=A(id);return e?e.value.trim():''},sv=[];
 for(var i=0;i<WEBN;i++){var n=g('w_sn'+i);if(n)sv.push({name:n,desc:g('w_sd'+i),price:g('w_sp'+i)})}
 var bk=A('w_bk');
 var gl=[],rv=[],fq=[],ck=function(id){var e=A(id);return !!(e&&e.checked&&!e.disabled)};
 for(var i=0;i<WEBG;i++){var u=g('w_g'+i);if(u)gl.push(u)}
 for(var i=0;i<3;i++){var t=g('w_rt'+i);if(t)rv.push({text:t,who:g('w_rw'+i)})}
 for(var i=0;i<5;i++){var q=g('w_fq'+i),a=g('w_fa'+i);if(q&&a)fq.push({q:q,a:a})}
 var sh=APP.d.shop_settings&&APP.d.shop_settings.rows&&APP.d.shop_settings.rows[0],shOn=!!(sh&&sh.enabled&&sh.slug);
 return {color:g('w_col')||'#6d5cff',font:g('w_font')||'sans',style:g('w_style')||'light',logo:g('w_lg'),gallery:gl,reviews:rv,faq:fq,social:{facebook:g('w_fb'),instagram:g('w_ig')},map:ck('w_map'),shop:ck('w_shop')&&shOn,shopSlug:shOn?sh.slug:'',hero:{title:g('w_ht'),subtitle:g('w_hs'),cta:g('w_hc'),image:g('w_hi')},about:{title:g('w_at'),text:g('w_ax')},services:sv,contact:{phone:g('w_cp'),email:g('w_ce'),address:g('w_ca'),hours:g('w_ch')},booking:!!(bk&&bk.checked&&!bk.disabled),footer:g('w_ft')}}
function webBook(){var bp=APP.d.booking_profiles.rows[0];return bp&&bp.enabled?bookUrl(bp.slug):''}
function webPrev(){var fr=A('webFr');if(!fr)return;fr.srcdoc=siteHTML(webRead(),{prev:true,name:APP.co,bookUrl:webBook()||'#'})}
function webSt(t,c){var e=A('webAiSt');if(e){e.className='st '+(c||'');e.textContent=t}}
function webFill(x){
 function sv(id,v){var e=A(id);if(e&&v!=null)e.value=v}
 if(x.hero){sv('w_ht',x.hero.title);sv('w_hs',x.hero.subtitle);sv('w_hc',x.hero.cta)}
 if(x.about){sv('w_at',x.about.title);sv('w_ax',x.about.text)}
 if(x.services){for(var i=0;i<WEBN;i++){var o=x.services[i];sv('w_sn'+i,o?o.name:'');sv('w_sd'+i,o?o.desc:'')}}
 webPrev()}
async function webUp(inp){
 var fl=inp.files&&inp.files[0];inp.value='';if(!fl)return;
 if(DEMO){toast('V ukázce se soubory nenahrávají. V ostrém účtu tlačítko nahraje obrázek a vyplní odkaz.','err');return}
 if(!/^image\/(jpeg|png|webp|gif)$/.test(fl.type)){toast('Povolené jsou jen obrázky JPG, PNG, WebP a GIF.','err');return}
 if(fl.size>3145728){toast('Obrázek je větší než 3 MB. Zmenšete ho a zkuste to znovu.','err');return}
 if(APP.busy)return;APP.busy=true;toast('Nahrávám obrázek…','ok');
 try{var ext={'image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif'}[fl.type],pth=APP.cid+'/'+Date.now().toString(36)+Math.random().toString(36).slice(2,7)+'.'+ext,st=getSb().storage.from('site-images');
  var u=await st.upload(pth,fl,{contentType:fl.type,upsert:false});
  if(u.error){toast('Nahrání se nepovedlo: '+u.error.message,'err');return}
  var pu=st.getPublicUrl(pth).data.publicUrl,t=A(inp.dataset.up);if(t){t.value=pu;webPrev()}toast('Obrázek nahrán. Nezapomeňte web uložit.','ok')
 }catch(x){toast('Nahrání se nepovedlo. Zkuste to znovu.','err')}finally{APP.busy=false}}
document.addEventListener('change',function(e){var t=e.target;if(t&&t.matches&&t.matches('#vxapp input[data-up]'))webUp(t)});
async function webAI(){
 var ds=(A('w_ai').value||'').trim();if(ds.length<15){webSt('Napište aspoň pár vět o firmě.','err');return}
 if(!hasCeo()){webSt('AI návrh textů je v tarifu PRO a vyšších.','err');return}
 if(APP.busy)return;APP.busy=true;webSt('AI píše návrh, bývá to pár sekund…','ok');
 try{var ses=(await getSb().auth.getSession()).data.session;
  var r=await dfetch('/api/web-ai',{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+(ses?ses.access_token:'')},body:JSON.stringify({cid:APP.cid,name:APP.co,description:ds})});
  var j=await r.json().catch(function(){return null});
  if(!r.ok||!j||!j.site){var c=j&&j.error;webSt(r.status===403?'AI návrh textů je v tarifu PRO a vyšších.':r.status===429?'Příliš mnoho požadavků. Zkuste to za chvíli.':c==='not_configured'?'AI zatím není na serveru zapnutá. Napište nám na info@vexaronet.com.':'Návrh se nepodařilo vytvořit. Zkuste to znovu.','err');return}
  webFill(j.site);webSt((j.demo?'Ukázkový návrh (v ostrém účtu ho píše AI podle vašeho popisu). ':'')+'Návrh je ve formuláři, ještě není uložený. Zkontrolujte texty a upravte je podle sebe.','ok')
 }catch(x){webSt('Návrh se nepodařilo vytvořit. Zkuste to znovu.','err')}finally{APP.busy=false}}
async function saveWeb(f){
 var sl=A('w_slug').value.trim().toLowerCase();if(!/^[a-z0-9][a-z0-9-]{2,40}$/.test(sl)){entMsg('Adresa: 3 až 41 znaků, malá písmena bez diakritiky, čísla a pomlčky.');return}
 var d=webRead(),en=A('w_on').checked;
 if(en&&!d.hero.title){entMsg('Pro zapnutí webu vyplňte hlavní nadpis.');return}
 var b=f.querySelector('button[type=submit]');b.disabled=true;
 var r=await getSb().from('sites').upsert({company_id:APP.cid,slug:sl,enabled:en,data:d,updated_at:new Date().toISOString()},{onConflict:'company_id'});b.disabled=false;
 if(r.error){entMsg(/duplicate|unique|23505/i.test(r.error.message+(r.error.code||''))?'Tuto adresu už používá jiný web, zvolte jinou.':'Nepodařilo se uložit: '+r.error.message);return}
 await refresh();appTab('weby');toast(en?'Uloženo. Web je zapnutý.':'Uloženo. Web je zatím vypnutý.','ok')}
async function webOpen(slug,prev){
 var old=A('vxsite');if(old)old.remove();
 var el=document.createElement('div');el.id='vxsite';el.className='vxsite';document.body.appendChild(el);document.documentElement.style.overflow='hidden';
 var lf1=document.activeElement;function close(){el.remove();document.documentElement.style.overflow=A('vxapp')?'hidden':'';try{document.title=window.DOC_T||document.title}catch(e){}if(lf1&&lf1.focus&&document.contains(lf1))lf1.focus({preventScroll:true});if(!prev){try{history.replaceState(null,'',location.pathname)}catch(e){}}}
 var fr=document.createElement('iframe');fr.className='vxsf';fr.title='Web';fr.setAttribute('sandbox','allow-popups allow-top-navigation-by-user-activation');el.appendChild(fr);
 if(prev){var x=document.createElement('button');x.type='button';x.className='vxsx';x.textContent='Zavřít náhled';x.addEventListener('click',close);el.appendChild(x);fr.srcdoc=siteHTML(webRead(),{name:APP.co,bookUrl:webBook()});return}
 var r=null,nw=[];try{var rr=await Promise.all([getSb().rpc('public_site',{p_slug:slug}),getSb().rpc('public_site_news',{p_slug:slug}).then(function(x){return x},function(){return null})]);r=rr[0];if(rr[1]&&!rr[1].error&&Array.isArray(rr[1].data))nw=rr[1].data}catch(e){}
 if(!r||r.error||!r.data){fr.srcdoc='<!doctype html><meta charset="utf-8"><body style="font-family:Arial;padding:40px"><h1>Stránka nenalezena</h1><p>Web neexistuje nebo je vypnutý. Zkontrolujte odkaz.</p>';return}
 var dd=r.data;try{document.title=(dd.data&&dd.data.hero&&dd.data.hero.title)||dd.name||document.title}catch(e){}
 fr.srcdoc=siteHTML(dd.data,{name:dd.name,bookUrl:dd.booking?bookUrl(dd.booking):'',news:nw})}

/* ===== Marketing: AI návrhy textů a plán příspěvků ===== */
var MKK=[['social','Příspěvek na sociální sítě','Sociální sítě'],['email','E-mail zákazníkům (newsletter)','E-mail'],['ad','Text online reklamy','Reklama'],['plan','Plán obsahu na týden','Plán obsahu'],['review','Odpověď na recenzi','Recenze']],MKCH=['Instagram','Facebook','E-mail','Web nebo blog','Reklama','Jiné'],MKST={draft:'Koncept',planned:'Naplánováno',done:'Zveřejněno'};
function mkView(){
 var P=APP.d.marketing_posts;if(P.err)return '<div class="draft">Marketing vyžaduje dokončit nastavení databáze (SQL schema_marketing). Detail: '+esc(P.err)+'</div>';
 var rs=P.rows.slice().sort(function(a,b){return String(b.planned_on||b.created_at).localeCompare(String(a.planned_on||a.created_at))});
 var h='<div class="card2 note"><b>AI pomocník pro marketing.</b> Napíšete, o čem chcete psát, a AI navrhne text příspěvku, e-mailu, reklamy nebo týdenní plán. Nic se nikam neodesílá ani nepublikuje, text si zkontrolujete, upravíte a zkopírujete. Hromadné marketingové e-maily smíte posílat jen zákazníkům, kteří s tím souhlasili, a Vexaronet je zatím sám neodesílá.</div>';
 h+='<section class="card2"><h3>Navrhnout text</h3>'+(hasCeo()?'':'<p class="mut fine">Návrhy od AI jsou v tarifu PRO a vyšších. Plán příspěvků níže můžete vést i bez nich.</p>')
 +'<div class="fg"><div class="f"><label for="mk_kind">Co potřebujete</label><select id="mk_kind">'+MKK.map(function(k){return '<option value="'+k[0]+'">'+k[1]+'</option>'}).join('')+'</select></div><div class="f"><label for="mk_tone">Tón</label><select id="mk_tone"><option value="friendly">Přátelský</option><option value="pro">Profesionální</option><option value="light">Odlehčený</option></select></div>'
 +'<div class="f full"><label for="mk_topic">O čem to má být</label><textarea id="mk_topic" rows="3" maxlength="700" placeholder="Např. Od listopadu nabízíme přezutí zimních pneumatik, objednat se dá online. Napište i cenu nebo slevu, pokud ji chcete uvést."></textarea></div></div>'
 +'<div class="dact"><button type="button" class="pri" data-mk="gen"'+(hasCeo()?'':' disabled')+'>Navrhnout s AI</button></div><div class="st" id="mkSt" role="status"></div>'
 +'<div id="mkRes"></div></section>';
 h+='<section class="card2"><div class="bar2"><h3>Plán příspěvků</h3><button type="button" class="btn btn-main btn-sm" data-new="marketing_posts">+ Nový příspěvek</button></div>'+errBox(P)
 +(rs.length?'<ul class="rows big">'+rs.map(function(r){return '<li data-edit="marketing_posts:'+esc(r.id)+'"><div><b>'+esc(r.title)+'</b><small>'+esc(r.channel||'bez kanálu')+' · '+esc(MKST[r.status]||r.status)+'</small></div><span>'+(r.planned_on?fD(r.planned_on):'bez data')+'</span></li>'}).join('')+'</ul>':'<p class="mut">Zatím žádné příspěvky. Nechte si jeden navrhnout výše, nebo přidejte vlastní.</p>')+'</section>';
 return h}
function mkSt(t,c){var e=A('mkSt');if(e){e.className='st '+(c||'');e.textContent=t}}
async function mkGen(){
 var tp=(A('mk_topic').value||'').trim();if(tp.length<5){mkSt('Napište aspoň pár slov, o čem má text být.','err');return}
 if(!hasCeo()){mkSt('Návrhy od AI jsou v tarifu PRO a vyšších.','err');return}
 if(APP.busy)return;APP.busy=true;mkSt('AI píše návrh, bývá to pár sekund…','ok');A('mkRes').innerHTML='';
 try{var ses=(await getSb().auth.getSession()).data.session;
  var r=await dfetch('/api/marketing',{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+(ses?ses.access_token:'')},body:JSON.stringify({cid:APP.cid,kind:A('mk_kind').value,tone:A('mk_tone').value,topic:tp,name:APP.co})});
  var j=await r.json().catch(function(){return null});
  if(!r.ok||!j||!j.text){var c=j&&j.error;mkSt(r.status===403?'Návrhy od AI jsou v tarifu PRO a vyšších.':r.status===429?'Příliš mnoho požadavků. Zkuste to za chvíli.':c==='not_configured'?'AI zatím není na serveru zapnutá. Napište nám na info@vexaronet.com.':'Návrh se nepodařilo vytvořit. Zkuste to znovu.','err');return}
  mkSt((j.demo?'Ukázkový návrh (v ostrém účtu ho píše AI podle vašeho zadání). ':'')+'Zkontrolujte text a doplňte údaje ve značkách [doplnit].','ok');
  A('mkRes').innerHTML='<div class="f full"><label for="mk_out">Návrh textu (můžete upravit)</label><textarea id="mk_out" rows="9" maxlength="4000">'+esc(j.text)+'</textarea></div><div class="dact"><button type="button" class="btn btn-ghost btn-sm" data-mk="copy">Kopírovat</button><button type="button" class="btn btn-main btn-sm" data-mk="save">Uložit do plánu</button></div>'
 }catch(x){mkSt('Návrh se nepodařilo vytvořit. Zkuste to znovu.','err')}finally{APP.busy=false}}
async function mkSave(){
 var tx=(A('mk_out').value||'').trim();if(!tx)return;var kd=MKK.filter(function(k){return k[0]===A('mk_kind').value})[0]||MKK[0],tp=(A('mk_topic').value||'').trim();
 var ch={social:'Instagram',email:'E-mail',ad:'Reklama',plan:'Jiné',review:'Jiné'}[kd[0]];
 var r=await getSb().from('marketing_posts').insert({company_id:APP.cid,title:(kd[2]+': '+tp).slice(0,100),channel:ch,status:'draft',body:tx});
 if(r.error){mkSt('Nepodařilo se uložit: '+r.error.message,'err');return}
 await refresh();appTab('marketing');toast('Uloženo do plánu jako koncept.','ok')}

/* ===== Reporty: přehledy výkonnosti z vlastních dat ===== */
var RPP=[['m0','Tento měsíc'],['m1','Minulý měsíc'],['q','Poslední 3 měsíce'],['y','Posledních 12 měsíců'],['all','Celé období']];
function rpRange(k){var n=new Date(),a,b;
 if(k==='m0'){a=new Date(n.getFullYear(),n.getMonth(),1);b=new Date(n.getFullYear(),n.getMonth()+1,1)}
 else if(k==='m1'){a=new Date(n.getFullYear(),n.getMonth()-1,1);b=new Date(n.getFullYear(),n.getMonth(),1)}
 else if(k==='q'){a=new Date(n.getFullYear(),n.getMonth()-2,1);b=new Date(n.getFullYear(),n.getMonth()+1,1)}
 else if(k==='y'){a=new Date(n.getFullYear(),n.getMonth()-11,1);b=new Date(n.getFullYear(),n.getMonth()+1,1)}
 else{a=new Date(2000,0,1);b=new Date(2100,0,1)}
 return [a,b]}
function rpData(k){
 var R=rpRange(k),a=R[0],b=R[1],d=APP.d,t0=dayStart(0);
 function ins(v){if(!v)return false;var x=new Date(v);return !isNaN(x)&&x>=a&&x<b}
 var inv=d.invoices.rows,iss=inv.filter(function(x){return ins(x.issued_on||x.created_at)}),paid=inv.filter(function(x){return x.paid_at&&ins(x.paid_at)}),unp=inv.filter(function(x){return !x.paid_at}),over=unp.filter(function(x){return x.due_on&&new Date(x.due_on)<t0});
 function sum(r,f){return r.reduce(function(s,x){return s+(Number(f(x))||0)},0)}
 var fe=d.fe.rows.filter(function(x){return ins(x.entry_date||x.created_at)}),feI=sum(fe.filter(function(x){return isInc(x.kind)}),function(x){return Math.abs(x.amount)}),feE=sum(fe.filter(function(x){return !isInc(x.kind)}),function(x){return Math.abs(x.amount)});
 var jb=d.jobs.rows,jn=jb.filter(function(x){return ins(x.created_at)}),jd=jb.filter(function(x){return /hotov|done|dokon/i.test(x.status||'')}),jo=jb.filter(function(x){return !/hotov|done|zruš|dokon/i.test(x.status||'')});
 var cn=d.customers.rows.filter(function(x){return ins(x.created_at)}),rs=d.reservations.rows.filter(function(x){return ins(x.starts_at)}),rc=rs.filter(function(x){return x.canceled}),ro=rs.filter(function(x){return /^Online:/.test(x.title||'')});
 var by={};iss.forEach(function(x){var n=invName(x)||'Neznámý';by[n]=(by[n]||0)+Number(x.total||0)});
 var top=Object.keys(by).map(function(n){return [n,by[n]]}).sort(function(p,q){return q[1]-p[1]}).slice(0,5);
 return {R:R,issN:iss.length,issS:sum(iss,function(x){return x.total}),paidN:paid.length,paidS:sum(paid,function(x){return x.total}),unpN:unp.length,unpS:sum(unp,function(x){return x.total}),overN:over.length,overS:sum(over,function(x){return x.total}),feI:feI,feE:feE,jobsNew:jn.length,jobsNewS:sum(jn,function(x){return x.price}),jobsDone:jd.length,jobsOpen:jo.length,custNew:cn.length,custAll:d.customers.rows.length,resN:rs.length,resC:rc.length,resO:ro.length,top:top}}
function rpRows(k,x){return [['Ukazatel','Hodnota'],['Období',(RPP.filter(function(p){return p[0]===k})[0]||[0,''])[1]],['Vystavené faktury (počet)',x.issN],['Vystavené faktury (Kč)',x.issS],['Zaplaceno v období (počet)',x.paidN],['Zaplaceno v období (Kč)',x.paidS],['Nezaplacené faktury celkem (počet)',x.unpN],['Nezaplacené faktury celkem (Kč)',x.unpS],['Po splatnosti (počet)',x.overN],['Po splatnosti (Kč)',x.overS],['Příjmy v evidenci (Kč)',x.feI],['Výdaje v evidenci (Kč)',x.feE],['Nové zakázky (počet)',x.jobsNew],['Nové zakázky (Kč)',x.jobsNewS],['Hotové zakázky celkem',x.jobsDone],['Otevřené zakázky celkem',x.jobsOpen],['Noví zákazníci',x.custNew],['Zákazníci celkem',x.custAll],['Rezervace v období',x.resN],['Z toho online',x.resO],['Z toho zrušené',x.resC]].concat(x.top.map(function(t,i){return ['Top zákazník '+(i+1)+' (fakturováno, Kč)',t[0]+': '+t[1]]}))}
function reportyView(){
 var k=APP.rpP||'m0',x=rpData(k),mon=monthsBack(k==='m0'||k==='m1'?6:12),lb=mon.map(function(m){return m.toLocaleDateString('cs-CZ',{month:'short'})});
 var f=finSeries(mon),isd=byMonth(APP.d.invoices.rows.map(function(r){return {d:r.issued_on||r.created_at,__v:Number(r.total||0)}}),function(r){return r.d},mon),pdd=byMonth(APP.d.invoices.rows.filter(function(r){return r.paid_at}).map(function(r){return {d:r.paid_at,__v:Number(r.total||0)}}),function(r){return r.d},mon);
 var h='<div class="bar2"><div class="f" style="max-width:260px"><label for="rpP">Období</label><select id="rpP">'+RPP.map(function(p){return '<option value="'+p[0]+'"'+(p[0]===k?' selected':'')+'>'+p[1]+'</option>'}).join('')+'</select></div><div class="dact"><button type="button" class="btn btn-ghost btn-sm" data-rp="csv">Stáhnout CSV</button><button type="button" class="btn btn-ghost btn-sm" data-rp="print">Tisk / PDF</button></div></div>';
 h+='<div class="kpis" style="margin:12px 0">'+tile2('g','faktury','Fakturováno',fM(x.issS),x.issN+' '+plural(x.issN,'faktura','faktury','faktur'))+tile2('b','tr','Zaplaceno',fM(x.paidS),x.paidN+' '+plural(x.paidN,'faktura','faktury','faktur'))+tile2(x.overN?'r':'o','faktury','Po splatnosti',fM(x.overS),x.overN+' '+plural(x.overN,'faktura','faktury','faktur')+' (nyní)','faktury')+tile2('o','faktury','Nezaplaceno celkem',fM(x.unpS),x.unpN+' '+plural(x.unpN,'faktura','faktury','faktur')+' (nyní)')+'</div>';
 h+='<div class="two"><section class="card2"><h3>Fakturováno a zaplaceno</h3>'+barChart(lb,isd,pdd,'Fakturováno','Zaplaceno','b2','b3')+'<p class="mut fine">Posledních '+mon.length+' měsíců, bez ohledu na zvolené období.</p></section><section class="card2"><h3>Příjmy a výdaje</h3>'+barChart(lb,f.inc,f.exp,'Příjmy','Výdaje','b2','b3')+'<p class="mut fine">Zdroj: '+esc(f.src)+'.</p></section></div>';
 h+='<div class="two"><section class="card2"><h3>Zakázky a zákazníci</h3><ul class="rows"><li><b>Nové zakázky</b><span>'+x.jobsNew+' · '+fM(x.jobsNewS)+'</span></li><li><b>Otevřené zakázky (nyní)</b><span>'+x.jobsOpen+'</span></li><li><b>Hotové zakázky (celkem)</b><span>'+x.jobsDone+'</span></li><li><b>Noví zákazníci</b><span>'+x.custNew+'</span></li><li><b>Zákazníci celkem</b><span>'+x.custAll+'</span></li></ul></section>'
 +'<section class="card2"><h3>Rezervace a evidence</h3><ul class="rows"><li><b>Rezervace v období</b><span>'+x.resN+'</span></li><li><b>Z toho online</b><span>'+x.resO+'</span></li><li><b>Z toho zrušené</b><span>'+x.resC+'</span></li><li><b>Příjmy v evidenci</b><span>'+fM(x.feI)+'</span></li><li><b>Výdaje v evidenci</b><span>'+fM(x.feE)+'</span></li></ul></section></div>';
 h+='<section class="card2"><h3>Největší zákazníci podle fakturace</h3>'+(x.top.length?'<ul class="rows">'+x.top.map(function(t){return '<li><b>'+esc(t[0])+'</b><span>'+fM(t[1])+'</span></li>'}).join('')+'</ul>':'<p class="mut">V tomto období nejsou žádné faktury.</p>')+'</section>';
 h+='<section class="card2"><h3>Shrnutí slovy (AI CEO)</h3><p class="mut fine">AI shrne čísla výše a upozorní na rizika. Jen radí, nic neprovádí.'+(hasCeo()?'':' Tato funkce je v tarifu PRO a vyšších.')+'</p><div class="dact"><button type="button" class="btn btn-ghost btn-sm" data-rp="ai"'+(hasCeo()?'':' disabled')+'>Shrnout report</button></div><div class="st" id="rpSt" role="status"></div><div id="rpAi"></div></section>';
 h+='<p class="mut fine">Čísla se počítají z vašich záznamů ve Vexaronetu (faktury, evidence, zakázky, rezervace). Příjmy v evidenci a zaplacené faktury se mohou částečně překrývat, pokud stejnou platbu evidujete obojím způsobem. Nejde o účetní výkaz ani daňové přiznání.</p>';
 return h}
function rpCsv(){var k=APP.rpP||'m0',rows=rpRows(k,rpData(k)),csv='﻿'+rows.map(function(r){return r.map(function(c){var t=String(c==null?'':c);if(typeof c==='number')t=t.replace('.',',');return /[;"\n\r]/.test(t)?'"'+t.replace(/"/g,'""')+'"':t}).join(';')}).join('\r\n'),b=new Blob([csv],{type:'text/csv;charset=utf-8'}),u=URL.createObjectURL(b),a=document.createElement('a');a.href=u;a.download='vexaronet-report-'+k+'.csv';document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(u)},1500);toast('Report stažen.','ok')}
function rpPrint(){var k=APP.rpP||'m0',rows=rpRows(k,rpData(k)),fr=document.createElement('iframe');fr.style.cssText='position:fixed;right:0;bottom:0;width:0;height:0;border:0';document.body.appendChild(fr);var d=fr.contentWindow.document;d.open();
 d.write('<!doctype html><html lang="cs"><head><meta charset="utf-8"><title>Report '+esc(APP.co||'')+'</title><style>body{font-family:Arial,sans-serif;color:#111;padding:24px}h1{font-size:20px;margin:0 0 4px}p{color:#555;font-size:12px}table{border-collapse:collapse;width:100%;margin-top:12px}td,th{border-bottom:1px solid #ddd;padding:6px 8px;text-align:left;font-size:13px}th{background:#f3f3f8}</style></head><body><h1>Report: '+esc(APP.co||'')+'</h1><p>Vytvořeno '+esc(new Date().toLocaleDateString('cs-CZ'))+' ve Vexaronetu. Přehled z vlastních záznamů, nejde o účetní výkaz.</p><table>'+rows.map(function(r,i){var v=typeof r[1]==='number'&&/Kč/.test(r[0])?fM(r[1]):esc(r[1]);return '<tr>'+(i?'<td>'+esc(r[0])+'</td><td>'+v+'</td>':'<th>'+esc(r[0])+'</th><th>'+esc(r[1])+'</th>')+'</tr>'}).join('')+'</table></body></html>');d.close();
 setTimeout(function(){try{fr.contentWindow.focus();fr.contentWindow.print()}catch(e){}setTimeout(function(){fr.remove()},2000)},300)}
async function rpAI(){
 if(!hasCeo()){return}if(APP.busy)return;APP.busy=true;var k=APP.rpP||'m0',x=rpData(k),st=A('rpSt');st.className='st ok';st.textContent='AI čte čísla, bývá to pár sekund…';A('rpAi').innerHTML='';
 try{var ses=(await getSb().auth.getSession()).data.session,sm={obdobi:(RPP.filter(function(p){return p[0]===k})[0]||[0,''])[1],fakturovano_kc:x.issS,faktur_vystaveno:x.issN,zaplaceno_kc:x.paidS,po_splatnosti_kc:x.overS,po_splatnosti_pocet:x.overN,nezaplaceno_kc:x.unpS,prijmy_evidence_kc:x.feI,vydaje_evidence_kc:x.feE,nove_zakazky:x.jobsNew,otevrene_zakazky:x.jobsOpen,novi_zakaznici:x.custNew,rezervace:x.resN,rezervace_zrusene:x.resC};
  var r=await dfetch('/api/advisor',{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+(ses?ses.access_token:'')},body:JSON.stringify({cid:APP.cid,messages:[{role:'user',content:'Shrň stručně tento report za zvolené období a upozorni na největší rizika a doporuč 2 až 3 další kroky.'}],summary:sm})});
  var j=await r.json().catch(function(){return null});
  if(!r.ok||!j||!j.reply){st.className='st err';st.textContent=r.status===403?'Shrnutí je v tarifu PRO a vyšších.':r.status===429?'Příliš mnoho požadavků. Zkuste to za chvíli.':'Shrnutí se nepodařilo vytvořit. Zkuste to znovu.';return}
  st.textContent='';A('rpAi').innerHTML='<div class="draft" style="white-space:pre-wrap">'+esc(j.reply)+'</div>'
 }catch(e){st.className='st err';st.textContent='Shrnutí se nepodařilo vytvořit. Zkuste to znovu.'}finally{APP.busy=false}}

/* ===== Automatizace: pravidla navrhují úkoly, uživatel je schvaluje ===== */
var AUR=[['overdue','Faktura po splatnosti','Navrhne úkol upomenout zákazníka.'],['jobdue','Blížící se termín zakázky','Navrhne úkol pohlídat zakázku, která není hotová a termín je do 2 dnů.'],['jobdone','Hotová zakázka bez faktury','Navrhne úkol vystavit fakturu (orientačně podle jména zákazníka).'],['inactive','Zákazník bez aktivity 90 dní','Navrhne úkol ozvat se zákazníkovi.'],['tomorrow','Rezervace zítra','Navrhne úkol připravit se na zítřejší rezervaci.'],['lowstock','Zboží pod minimem na skladě','Navrhne úkol zboží objednat.']];
function auOn(k){var r=(APP.d.automation_rules&&APP.d.automation_rules.rows||[]).filter(function(x){return x.rule===k})[0];return !(r&&r.enabled===false)}
function auItems(){
 var d=APP.d,t0=dayStart(0),t2=dayStart(3),t1=dayStart(1),tm=dayStart(2),out=[],done={};
 d.tasks.rows.forEach(function(t){var m=String(t.description||'').match(/\[auto:([^\]]+)\]/);if(m)done[m[1]]=1});
 function add(rule,key,title,due,why){if(done[key])return;out.push({rule:rule,key:key,title:title.slice(0,120),due:due,why:why})}
 if(auOn('overdue'))d.invoices.rows.forEach(function(x){if(x.paid_at||!x.due_on||new Date(x.due_on)>=t0)return;add('overdue','inv:'+x.id,'Upomenout platbu: faktura '+(x.number||'')+(invName(x)?' ('+invName(x)+')':'')+', '+fM(x.total,x.currency),locD(t0),'Po splatnosti od '+fD(x.due_on))});
 if(auOn('jobdue'))d.jobs.rows.forEach(function(j){if(!j.due_at||/hotov|done|zruš|dokon/i.test(j.status||''))return;var dd=new Date(j.due_at);if(dd>=t0&&dd<t2)add('jobdue','jobdue:'+j.id,'Pohlídat termín zakázky: '+j.title,locD(dd),'Termín '+fD(j.due_at))});
 if(auOn('jobdone')){var cm={};d.customers.rows.forEach(function(c){cm[c.id]=custName(c)});d.jobs.rows.forEach(function(j){if(!/hotov|done|dokon/i.test(j.status||'')||!j.customer_id)return;var nm=cm[j.customer_id];if(!nm)return;var has=d.invoices.rows.some(function(x){return invName(x)===nm&&new Date(x.issued_on||x.created_at)>=new Date(String(j.created_at||'').slice(0,10))});if(!has)add('jobdone','jobdone:'+j.id,'Vystavit fakturu: '+j.title+' ('+nm+')',locD(t0),'Zakázka je hotová a od jejího vzniku nemá zákazník fakturu')})}
 if(auOn('inactive')){var lim=new Date(t0);lim.setDate(lim.getDate()-90);var act={};d.jobs.rows.forEach(function(j){if(j.customer_id&&new Date(j.created_at)>=lim)act[j.customer_id]=1});d.reservations.rows.forEach(function(r){if(r.customer_id&&new Date(r.starts_at)>=lim)act[r.customer_id]=1});var an={};d.invoices.rows.forEach(function(x){if(new Date(x.issued_on||x.created_at)>=lim)an[invName(x)]=1});
  d.customers.rows.forEach(function(c){if(c.archived||act[c.id]||an[custName(c)]||new Date(c.created_at)>=lim)return;add('inactive','inactive:'+c.id,'Ozvat se zákazníkovi: '+custName(c),locD(t0),'Žádná zakázka, rezervace ani faktura za posledních 90 dní')})}
 if(auOn('tomorrow'))d.reservations.rows.forEach(function(r){if(r.canceled)return;var s0=new Date(r.starts_at);if(s0>=t1&&s0<tm)add('tomorrow','res:'+r.id,'Připravit se na rezervaci zítra: '+(r.title||''),locD(t1),'Rezervace '+fD(r.starts_at,1))});
 if(auOn('lowstock')&&d.products&&!d.products.err&&d.stock_moves&&!d.stock_moves.err){var sk0=skStock();skLow().forEach(function(p){add('lowstock','low:'+p.id+':'+Math.floor(Number(sk0[p.id]||0)),'Objednat zboží: '+p.name+' (zbývá '+skN(sk0[p.id]||0)+' '+(p.unit||'ks')+')',locD(t0),'Zásoba je na nebo pod minimem '+skN(p.min_qty)+' '+(p.unit||'ks'))})}
 return out}
function auView(){
 var R=APP.d.automation_rules||{rows:[]},it=auItems(),mg=APP.role==='owner'||APP.role==='admin',cnt={};it.forEach(function(x){cnt[x.rule]=(cnt[x.rule]||0)+1});
 var h='<div class="card2 note"><b>Automatizace vám hlídá věci a navrhuje úkoly.</b> Pravidla se vyhodnotí vždy, když otevřete Vexaronet. Nic se nevytvoří samo, návrhy úkolů schvalujete tlačítkem. Běh na pozadí a automatické e-maily zákazníkům zatím nejsou.'+(R.err?' Zapínání a vypínání pravidel vyžaduje dokončit nastavení databáze (SQL schema_automatizace), do té doby jsou všechna pravidla zapnutá.':'')+'</div>';
 h+='<section class="card2"><h3>Pravidla</h3><ul class="rows big">'+AUR.map(function(r){var on=auOn(r[0]);return '<li><label class="chk"><input type="checkbox" data-au="rule:'+r[0]+'"'+(on?' checked':'')+((mg&&!R.err)?'':' disabled')+'><span><b>'+esc(r[1])+'</b><small>'+esc(r[2])+'</small></span></label><span>'+(on?(cnt[r[0]]||0)+' '+plural(cnt[r[0]]||0,'návrh','návrhy','návrhů'):'vypnuto')+'</span></li>'}).join('')+'</ul></section>';
 h+='<section class="card2"><div class="bar2"><h3>Návrhy úkolů</h3>'+(it.length&&mg?'<button type="button" class="btn btn-main btn-sm" data-au="all">Vytvořit všechny úkoly ('+it.length+')</button>':'<span></span>')+'</div>'+(it.length?'<ul class="rows big">'+it.map(function(x,i){return '<li><div><b>'+esc(x.title)+'</b><small>'+esc(x.why)+'</small></div>'+(mg?'<button type="button" class="btn btn-ghost btn-sm" data-au="one:'+i+'">Vytvořit úkol</button>':'')+'</li>'}).join('')+'</ul>':'<p class="mut">Teď není co navrhovat. Všechno vypadá v pořádku.</p>')+(mg?'':'<p class="mut fine">Úkoly z návrhů mohou vytvářet jen majitel a správce.</p>')+'</section>';
 h+='<section class="card2"><h3>Co zatím neumíme</h3><ul class="rows"><li class="off"><b>Běh pravidel bez otevření aplikace</b><span>připravujeme</span></li><li class="off"><b>Automatické e-maily a upomínky zákazníkům</b><span>připravujeme</span></li><li class="off"><b>Vlastní pravidla a propojení s dalšími službami</b><span>připravujeme</span></li></ul></section>';
 return h}
async function auCreate(list){
 if(!list.length||APP.busy)return;APP.busy=true;
 try{var rows=list.map(function(x){return {company_id:APP.cid,title:x.title,due_at:x.due,description:'[auto:'+x.key+'] '+x.why,completed:false}});
  var r=await getSb().from('tasks').insert(rows);if(r.error){toast('Nepodařilo se vytvořit úkoly: '+r.error.message,'err');return}
  await refresh();appTab('automatizace');toast('Vytvořeno úkolů: '+rows.length+'. Najdete je v záložce Úkoly.','ok')
 }finally{APP.busy=false}}
async function auToggle(k,on){
 var R=APP.d.automation_rules.rows.filter(function(x){return x.rule===k})[0],r;
 if(R)r=await getSb().from('automation_rules').update({enabled:on,updated_at:new Date().toISOString()}).eq('company_id',APP.cid).eq('rule',k);
 else r=await getSb().from('automation_rules').insert({company_id:APP.cid,rule:k,enabled:on});
 if(r.error){toast('Nepodařilo se uložit: '+r.error.message,'err')}
 await refresh();appTab('automatizace')}

/* ===== Sklad a produkty: karty zboží + pohyby skladu ===== */
var SKK={in:'Příjem na sklad',out:'Výdej ze skladu',adjust:'Oprava stavu (inventura)'};
function skStock(){var m={};((APP.d.stock_moves||{rows:[]}).rows).forEach(function(x){m[x.product_id]=(m[x.product_id]||0)+(Number(x.qty)||0)});return m}
function skN(n){return Number(n||0).toLocaleString('cs-CZ',{maximumFractionDigits:3})}
function skLow(){var st=skStock();return APP.d.products.rows.filter(function(p){return p.active!==false&&Number(p.min_qty)>0&&(st[p.id]||0)<=Number(p.min_qty)})}
function skladView(){
 var P=APP.d.products,M=APP.d.stock_moves;if(P.err||M.err)return '<div class="draft">Sklad vyžaduje dokončit nastavení databáze (SQL schema_sklad). Detail: '+esc(P.err||M.err)+'</div>';
 var st=skStock(),rs=P.rows.slice().sort(function(a,b){return String(a.name).localeCompare(String(b.name),'cs')}),low=skLow(),val=0,mg=APP.role==='owner'||APP.role==='admin';
 rs.forEach(function(p){if(p.active!==false)val+=Math.max(0,st[p.id]||0)*(Number(p.cost)||0)});
 var h='<div class="card2 note"><b>Evidence skladu.</b> Založíte kartu zboží, na ni zapisujete příjmy a výdeje a Vexaronet počítá aktuální stav. Zboží pod nastaveným minimem se zvýrazní. Stav se neodečítá sám, pohyby zapisujete vy, a sklad není propojen s fakturami.</div>';
 h+='<div class="kpis" style="margin:12px 0">'+tile2('b','sklad','Položek',String(rs.filter(function(p){return p.active!==false}).length),'')+tile2(low.length?'r':'g','warn','Pod minimem',String(low.length),low.length?'doplnit zásobu':'vše v pořádku')+tile2('o','faktury','Hodnota skladu',fM(Math.round(val)),'orientačně podle nákupní ceny')+'</div>';
 h+='<div class="bar2"><input class="srch" type="search" placeholder="Hledat zboží…" aria-label="Hledat">'+(mg?'<button type="button" class="btn btn-main btn-sm" data-new="products">+ Nové zboží</button>':'<span></span>')+'</div>'+errBox(P);
 h+=rs.length?'<ul class="rows big" id="lst">'+rs.map(function(p){var q=st[p.id]||0,lw=p.active!==false&&Number(p.min_qty)>0&&q<=Number(p.min_qty);return '<li'+(mg?' data-edit="products:'+esc(p.id)+'"':'')+(p.active===false?' class="off"':'')+'><div><b>'+esc(p.name)+'</b><small>'+(p.sku?esc(p.sku)+' · ':'')+(p.min_qty?'minimum '+skN(p.min_qty)+' '+esc(p.unit||'ks'):'bez minima')+(p.active===false?' · nepoužívá se':'')+'</small></div><span class="'+(lw?'late':'')+'">'+skN(q)+' '+esc(p.unit||'ks')+(lw?' · málo':'')+'</span>'+(mg?'<button type="button" class="btn btn-ghost btn-sm" data-sk="move:'+esc(p.id)+'">Pohyb</button>':'')+'</li>'}).join('')+'</ul>':'<p class="mut">Zatím žádné zboží. Přidejte první kartu a pak na ni zapište příjem.</p>';
 var mv=M.rows.slice().sort(function(a,b){return new Date(b.created_at)-new Date(a.created_at)}).slice(0,15),pm={};P.rows.forEach(function(p){pm[p.id]=p});
 h+='<section class="card2"><h3>Poslední pohyby</h3>'+(mv.length?'<ul class="rows">'+mv.map(function(x){var p=pm[x.product_id]||{};return '<li><div><b>'+esc(p.name||'(smazané zboží)')+'</b><small>'+esc(SKK[x.kind]||x.kind)+(x.note?' · '+esc(x.note):'')+' · '+fD(x.created_at,1)+'</small></div><span class="'+(Number(x.qty)>=0?'inc':'')+'">'+(Number(x.qty)>=0?'+':'−')+skN(Math.abs(x.qty))+' '+esc(p.unit||'ks')+'</span></li>'}).join('')+'</ul>':'<p class="mut">Zatím žádné pohyby.</p>')+'</section>';
 return h}
function skMove(pid){
 var p=APP.d.products.rows.filter(function(x){return x.id===pid})[0];if(!p)return;var q=skStock()[pid]||0;
 modal('<h3>Pohyb skladu – '+esc(p.name)+'</h3><p class="mut">Aktuální stav: <b>'+skN(q)+' '+esc(p.unit||'ks')+'</b></p><form id="skForm" data-pid="'+esc(pid)+'"><div class="fg"><div class="f"><label for="sk_k">Druh</label><select id="sk_k"><option value="in">Příjem na sklad</option><option value="out">Výdej ze skladu</option><option value="adjust">Oprava stavu (inventura)</option></select></div><div class="f"><label for="sk_q" id="sk_ql">Množství</label><input id="sk_q" type="number" step="any" min="0" required></div><div class="f full"><label for="sk_n">Poznámka (nepovinné)</label><input id="sk_n" maxlength="200"></div></div><p class="mut fine">U opravy stavu zadejte, kolik zboží jste skutečně napočítali. Rozdíl se zapíše jako pohyb.</p><div class="st" id="entSt" role="status"></div><div class="dact"><button class="btn btn-main" type="submit">Zapsat</button><button class="btn btn-ghost" type="button" data-app="mclose">Zrušit</button></div></form>')}
async function skSave(f){
 var pid=f.dataset.pid,k=A('sk_k').value,v=parseFloat(A('sk_q').value),cur=skStock()[pid]||0,p=APP.d.products.rows.filter(function(x){return x.id===pid})[0];
 if(!p||!(v>=0)||(k!=='adjust'&&!(v>0))){entMsg('Zadejte množství.');return}
 var qty=k==='in'?v:k==='out'?-v:v-cur;
 if(k==='out'&&cur-v<0&&!confirm('Na skladě je jen '+skN(cur)+' '+(p.unit||'ks')+'. Stav by klesl pod nulu. Přesto zapsat?'))return;
 if(k==='adjust'&&qty===0){entMsg('Stav se shoduje, není co opravovat.');return}
 var b=f.querySelector('button[type=submit]');b.disabled=true;
 var r=await getSb().from('stock_moves').insert({company_id:APP.cid,product_id:pid,qty:qty,kind:k,note:A('sk_n').value.trim()||null});b.disabled=false;
 if(r.error){entMsg('Nepodařilo se uložit: '+r.error.message);return}
 closeModal();await refresh();appTab('sklad');toast('Pohyb zapsán.','ok')}
async function accProcess(){
 var fi=A('accFile'),f=fi&&fi.files&&fi.files[0];
 if(!f){accSt('Vyberte soubor s dokladem (foto nebo PDF).','err');return}
 var mt=(f.type||(/\.hei[cf]$/i.test(f.name)?'image/heic':'')).toLowerCase();
 if(!/^(image\/(jpeg|png|webp|heic|heif)|application\/pdf)$/.test(mt)){accSt('Podporované jsou fotky (JPG, PNG, WebP, HEIC) a PDF.','err');return}
 if(f.size>6e6){accSt('Soubor je příliš velký (nejvýše 6 MB).','err');return}
 if(APP.busy)return;APP.busy=true;accSt('Zpracovávám doklad, bývá to pár sekund…','ok');A('accRes').innerHTML='';
 try{var data=await new Promise(function(res,rej){var fr=new FileReader();fr.onload=function(){res(String(fr.result).split(',')[1]||'')};fr.onerror=rej;fr.readAsDataURL(f)});
  var o=await accCall({mime:mt,data:data});
  if(!o.r.ok){accSt(accErr(o.r,o.j),'err');return}
  accUse(o.j.used,o.j.limit);if(o.j.stored){APP.accDoc=null;accSt('Hotovo. Doklad je uložený ke kontrole'+(o.j.duplicate_of?' a vypadá jako DUPLICITA dříve nahraného dokladu':'')+'. Do evidence se zapíše až po vašem schválení.','ok');A('accRes').innerHTML='<div class="card2"><p><b>'+esc(o.j.doc.supplier_name||'Doklad')+'</b> '+esc(o.j.doc.document_number||'')+(o.j.doc.total_amount!=null?' · '+esc(o.j.doc.total_amount)+' '+esc(o.j.doc.currency||''):'')+'</p>'+((o.j.doc.warnings||[]).length?'<div class="draft">'+o.j.doc.warnings.map(esc).join('<br>')+'</div>':'')+'<button type="button" class="btn btn-main" id="accToDocs">Zkontrolovat a schválit doklad</button></div>';var gd=A('accToDocs');if(gd)gd.addEventListener('click',function(){AIT.tab='ucetnictvi';appTab('aitym')})}else{APP.accDoc=o.j.doc;accSt('Hotovo. Zkontrolujte údaje níže, nic ještě není uložené.','ok');A('accRes').innerHTML=accForm(o.j.doc)}
 }catch(x){accSt('Zpracování se nepodařilo. Zkuste to znovu.','err')}finally{APP.busy=false}}
function accForm(d){
 var cz=!d.currency||d.currency==='CZK',w=(d.warnings||[]).slice();
 if(!cz)w.push('Doklad je v měně '+d.currency+'. Zadejte částku v Kč podle svého kurzu.');
 if(d.total_amount==null)w.push('Částka nebyla na dokladu nalezena.');
 if(d.confidence==='low')w.push('AI si u tohoto dokladu není jistá. Zkontrolujte všechny údaje.');
 var inc=d.document_type==='issued_invoice',title=[d.supplier_name,d.document_number,d.description].filter(Boolean).join(' · ')||'Doklad',
  rows=[['Dodavatel',d.supplier_name],['IČO',d.supplier_ico],['DIČ',d.supplier_dic],['Číslo dokladu',d.document_number],['Datum vystavení',d.issue_date?fD(d.issue_date):null],['Splatnost',d.due_date?fD(d.due_date):null],['Celkem na dokladu',d.total_amount==null?null:d.total_amount+' '+(d.currency||'')],['DPH',d.vat_amount==null?null:d.vat_amount+' '+(d.currency||'')+(d.vat_rate!=null?' ('+d.vat_rate+' %)':'')],['Navržená kategorie',d.category]].filter(function(x){return x[1]});
 return '<form id="accRF" class="accrf"><h4>Navržený záznam</h4>'+(w.length?'<div class="draft">'+w.map(esc).join('<br>')+'</div>':'')+'<div class="fg"><div class="f"><label for="af_kind">Druh</label><select id="af_kind"><option value="expense"'+(inc?'':' selected')+'>Výdaj</option><option value="income"'+(inc?' selected':'')+'>Příjem</option></select></div><div class="f"><label for="af_amt">Částka v Kč <i>*</i></label><input id="af_amt" type="number" step="any" min="0" required value="'+(cz&&d.total_amount!=null?esc(Math.abs(d.total_amount)):'')+'"></div><div class="f"><label for="af_date">Datum <i>*</i></label><input id="af_date" type="date" required value="'+esc(d.issue_date||locD(new Date()))+'"></div><div class="f full"><label for="af_title">Popis <i>*</i></label><input id="af_title" required maxlength="200" value="'+esc(title)+'"></div></div><details><summary>Údaje načtené z dokladu</summary><ul class="rows">'+rows.map(function(x){return '<li><b>'+x[0]+'</b><span>'+esc(x[1])+'</span></li>'}).join('')+'<li><b>Jistota AI</b><span>'+({low:'nízká',medium:'střední',high:'vysoká'}[d.confidence]||'')+'</span></li></ul></details><div class="dact"><button class="pri" type="submit">Uložit do evidence</button><button class="btn btn-ghost" type="button" data-acc="discard">Zahodit</button></div></form>'}
async function accAsk(q){
 if(APP.busy)return;APP.busy=true;APP.accChat=APP.accChat||[];APP.accChat.push({role:'user',content:q});
 var lg=A('accLog');if(lg){lg.innerHTML=accMsgs()+'<div class="msg bot" id="accWait">Píšu odpověď…</div>';lg.scrollTop=lg.scrollHeight}
 var rep=null,err='';
 try{var sm=summary(),ac=accStats();sm.prijmy_tento_mesic_kc=ac.i0;sm.vydaje_tento_mesic_kc=ac.e0;sm.prijmy_minuly_mesic_kc=ac.i1;sm.vydaje_minuly_mesic_kc=ac.e1;sm.zaznamu_v_evidenci=APP.d.fe.rows.length;
  var o=await accCall({mode:'ask',messages:APP.accChat.slice(-10),summary:sm});if(o.r.ok&&o.j&&o.j.reply)rep=o.j.reply;else err=accErr(o.r,o.j)}catch(x){err='AI Účetní teď není dostupná. Zkuste to později.'}
 if(rep)APP.accChat.push({role:'assistant',content:rep});else APP.accChat.pop();
 APP.busy=false;lg=A('accLog');if(lg){lg.innerHTML=accMsgs()+(rep?'':'<div class="msg bot err">'+esc(err)+'</div>');lg.scrollTop=lg.scrollHeight}}
function accExport(kind){var m=A('accMon')?A('accMon').value:'',d=APP.d,rows,name;
 if(kind==='ent'){rows=[['Datum','Druh','Popis','Částka v Kč']];d.fe.rows.slice().sort(function(a,b){return new Date(a.entry_date||a.created_at)-new Date(b.entry_date||b.created_at)}).forEach(function(r){var k=String(r.entry_date||r.created_at||'').slice(0,10);if(m&&k.slice(0,7)!==m)return;rows.push([k,isInc(r.kind)?'Příjem':'Výdaj',r.title||'',String(Math.abs(Number(r.amount)||0)).replace('.',',')])});name='vexaronet-prijmy-vydaje'+(m?'-'+m:'')+'.csv'}
 else{rows=[['Číslo','Zákazník','Vystaveno','Splatnost','Celkem','Měna','Zaplaceno dne']];d.invoices.rows.slice().sort(function(a,b){return new Date(a.issued_on||a.created_at)-new Date(b.issued_on||b.created_at)}).forEach(function(x){var k=String(x.issued_on||x.created_at||'').slice(0,10);if(m&&k.slice(0,7)!==m)return;rows.push([x.number||'',invName(x),k,String(x.due_on||'').slice(0,10),String(Number(x.total||0)).replace('.',','),x.currency||'CZK',String(x.paid_at||'').slice(0,10)])});name='vexaronet-faktury'+(m?'-'+m:'')+'.csv'}
 if(rows.length<2){toast('V tomto období nejsou žádná data k exportu.','err');return}
 var csv='﻿'+rows.map(function(r){return r.map(function(c){var t=String(c==null?'':c);return /[;"\n\r]/.test(t)?'"'+t.replace(/"/g,'""')+'"':t}).join(';')}).join('\r\n'),b=new Blob([csv],{type:'text/csv;charset=utf-8'}),u=URL.createObjectURL(b),a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(u)},1500);toast('Export stažen: '+name,'ok')}
/* ---- akce AI CEO (vždy po potvrzení) ---- */
function fbModal(){modal('<h3>Něco nefunguje? Zpětná vazba</h3><p class="mut">Napište nám, co se nepovedlo nebo co byste chtěli vylepšit. Přečteme si to všechno.</p><form id="fbForm"><div class="fg"><div class="f full"><label for="fbK">O co jde</label><select id="fbK"><option value="problem">Něco nefunguje</option><option value="napad">Nápad nebo přání</option><option value="jine">Jiné</option></select></div><div class="f full"><label for="fbR">Jak jste spokojeni s aplikací?</label><select id="fbR"><option value="5">5 – velmi</option><option value="4">4</option><option value="3">3</option><option value="2">2</option><option value="1">1 – vůbec</option></select></div><div class="f full"><label for="fbM">Zpráva <i>*</i></label><textarea id="fbM" rows="5" maxlength="4000" minlength="10" required placeholder="Co jste dělali a co se stalo? Např. kliknul jsem na Faktury a zobrazila se chyba."></textarea></div></div><div class="st" id="fbSt" role="status"></div><div class="dact"><button class="pri" type="submit">Odeslat</button><button class="btn btn-ghost" type="button" data-app="mclose">Zavřít</button></div></form>')}
function modal(h){var m=A('appModal');if(!m){m=document.createElement('div');m.id='appModal';m.className='amodal on';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');A('vxapp').appendChild(m)}m.className='amodal on';m.innerHTML='<div class="mbox">'+h+'</div>'}

/* ---- náhled faktury ---- */
function invHTML(f){
 var sp=f.supplier_snapshot&&typeof f.supplier_snapshot==='object'?f.supplier_snapshot:{},cu=f.customer_snapshot&&typeof f.customer_snapshot==='object'?f.customer_snapshot:{},cur=f.currency||'CZK',
  its=(Array.isArray(f.items)&&f.items)||(Array.isArray(f.lines)&&f.lines)||[],vat={},tot=0,rows='';
 function m(n){return Number(n||0).toLocaleString('cs-CZ',{minimumFractionDigits:2,maximumFractionDigits:2})+' '+(cur==='CZK'?'Kč':esc(cur))}
 if(its.length){its.forEach(function(i){var q=Number(i.quantity)||0,g=Number(i.unit_gross)||0,r=Number(i.vat_rate)||0,l=q*g;tot+=l;var k=String(r);vat[k]=vat[k]||{g:0};vat[k].g+=l;
   rows+='<tr><td>'+esc(i.description||'')+'</td><td class="r">'+esc(q)+' '+esc(i.unit||'')+'</td><td class="r">'+m(g)+'</td><td class="r">'+r+' %</td><td class="r">'+m(l)+'</td></tr>'})}
 else{tot=Number(f.total)||0;rows='<tr><td colspan="4">Celková částka faktury (položky nejsou v tomto zobrazení k dispozici)</td><td class="r">'+m(tot)+'</td></tr>'}
 var rec='';Object.keys(vat).sort(function(a,b){return b-a}).forEach(function(k){var g=vat[k].g,r=Number(k),n=r?g/(1+r/100):g;rec+='<tr><td>'+r+' %</td><td class="r">'+m(n)+'</td><td class="r">'+m(g-n)+'</td><td class="r">'+m(g)+'</td></tr>'});
 function blk(t,o){return '<div><h4>'+t+'</h4><b>'+esc(o.legal_name||o.name||o.company_name||'–')+'</b><br>'+(o.address_text||o.billing_address?esc(o.address_text||o.billing_address)+'<br>':'')+(o.ico?'IČO: '+esc(o.ico)+'<br>':'')+(o.dic?'DIČ: '+esc(o.dic)+'<br>':'')+(o.email?esc(o.email):'')+'</div>'}
 return '<div class="invdoc"><div class="ih"><div><h2>Faktura – daňový doklad</h2><div class="inum">č. '+esc(f.number||'bez čísla')+'</div></div><div class="ist '+(f.paid_at?'ok':'')+'">'+(f.paid_at?'ZAPLACENO':'K ÚHRADĚ')+'</div></div>'
 +'<div class="i2">'+blk('Dodavatel',sp)+blk('Odběratel',cu)+'</div>'
 +'<div class="i3"><div><small>Datum vystavení</small><b>'+fD(f.issued_on)+'</b></div><div><small>Datum zdan. plnění</small><b>'+fD(f.taxable_supply_on||f.issued_on)+'</b></div><div><small>Splatnost</small><b>'+fD(f.due_on)+'</b></div><div><small>Číslo účtu</small><b>'+esc(sp.bank_account||sp.iban||'–')+'</b></div></div>'
 +'<table class="it"><thead><tr><th>Popis</th><th class="r">Množství</th><th class="r">Cena/jedn. s DPH</th><th class="r">DPH</th><th class="r">Celkem s DPH</th></tr></thead><tbody>'+rows+'</tbody></table>'
 +(rec?'<table class="it sm"><thead><tr><th>Sazba DPH</th><th class="r">Základ</th><th class="r">DPH</th><th class="r">Celkem</th></tr></thead><tbody>'+rec+'</tbody></table>':'')
 +'<div class="itot">Celkem k úhradě <b>'+m(Number(f.total)||tot)+'</b></div>'+(f.paid_at?'<p class="ifine">Uhrazeno dne '+fD(f.paid_at)+'.</p>':'')+'<p class="ifine">Vystaveno ve Vexaronetu. Náhled faktury; odesílání e-mailem a QR platba se připravují.</p></div>'}
var INVCSS='.invdoc{background:#fff;color:#14172b;border-radius:10px;padding:26px;font:14px/1.5 system-ui,Arial,sans-serif;text-align:left}.invdoc h2{margin:0;font-size:22px;color:#14172b}.invdoc h4{margin:0 0 4px;font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:#6b7090}.invdoc .ih{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;border-bottom:2px solid #5b6eff;padding-bottom:12px;margin-bottom:16px}.invdoc .inum{color:#5b6eff;font-weight:700;margin-top:2px}.invdoc .ist{border:2px solid #d9822b;color:#d9822b;font-weight:800;padding:4px 10px;border-radius:8px;white-space:nowrap}.invdoc .ist.ok{border-color:#1a9d63;color:#1a9d63}.invdoc .i2{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:16px}.invdoc .i3{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;background:#f2f4fb;padding:10px 12px;border-radius:8px;margin-bottom:16px}.invdoc .i3 small{display:block;color:#6b7090;font-size:11px}.invdoc table{width:100%;border-collapse:collapse;margin-bottom:12px}.invdoc th{text-align:left;font-size:11px;color:#6b7090;border-bottom:1px solid #d5d9ea;padding:6px 4px}.invdoc td{padding:7px 4px;border-bottom:1px solid #eceef7}.invdoc .r{text-align:right}.invdoc .sm td,.invdoc .sm th{font-size:12px}.invdoc .itot{text-align:right;font-size:16px;margin-top:8px}.invdoc .itot b{font-size:22px;color:#5b6eff;margin-left:8px}.invdoc .ifine{color:#6b7090;font-size:12px;margin:8px 0 0}@media(max-width:620px){.invdoc{padding:16px}.invdoc .i2{grid-template-columns:1fr}.invdoc .i3{grid-template-columns:1fr 1fr}.invdoc .it{font-size:12px}}';
function invView(id){var f=APP.d.invoices.rows.filter(function(x){return x.id===id})[0];if(!f)return;APP.invOpen=f;
 modal('<style>'+INVCSS+'</style>'+invHTML(f)+'<div class="dact"><button class="btn btn-main btn-sm" type="button" data-invprint="1">Vytisknout / uložit jako PDF</button><button class="btn btn-ghost btn-sm" type="button" data-app="mclose">Zavřít</button></div>')}
function invPrint(){var f=APP.invOpen;if(!f)return;var fr=document.createElement('iframe');fr.style.cssText='position:fixed;right:0;bottom:0;width:0;height:0;border:0';document.body.appendChild(fr);var d=fr.contentWindow.document;d.open();d.write('<!doctype html><html lang="cs"><head><meta charset="utf-8"><title>Faktura '+esc(f.number||'')+'</title><style>body{margin:0;padding:20px}'+INVCSS+'.invdoc{padding:0}</style></head><body>'+invHTML(f)+'</body></html>');d.close();setTimeout(function(){try{fr.contentWindow.focus();fr.contentWindow.print()}catch(e){}setTimeout(function(){fr.remove()},2000)},300)}

/* ---- kalendář ---- */
var CALK={r:'Rezervace',j:'Termín zakázky',s:'Směna',t:'Úkol'},CALO={r:0,s:1,j:2,t:3};
function hmm(v){return new Date(v).toLocaleTimeString('cs-CZ',{hour:'2-digit',minute:'2-digit'})}
function calItems(){var m={},d=APP.d;
 function add(k,dt,o){if(!dt)return;var dd=new Date(dt);if(isNaN(dd))return;var key=locD(dd);o.k=k;o.at=dd.getTime();(m[key]=m[key]||[]).push(o)}
 d.reservations.rows.forEach(function(r){if(!r.canceled)add('r',r.starts_at,{id:r.id,ent:'reservations',t:r.title||'Rezervace',tm:hmm(r.starts_at)+' – '+hmm(r.ends_at),lab:hmm(r.starts_at)+' '+(r.title||'Rezervace')})});
 d.jobs.rows.forEach(function(j){if(!DONE.test(j.status||''))add('j',j.due_at,{id:j.id,ent:'jobs',t:j.title||'Zakázka',tm:'termín dokončení',lab:j.title||'Zakázka'})});
 d.tasks.rows.forEach(function(t){if(!t.completed)add('t',t.due_at,{id:t.id,ent:'tasks',t:t.title||'Úkol',tm:'termín úkolu',lab:t.title||'Úkol'})});
 (d.shifts&&d.shifts.rows||[]).forEach(function(x){var nm=String(x.person||'').split('@')[0];add('s',x.starts_at,{id:x.id,ent:'shifts',t:nm+(x.note?' – '+x.note:''),tm:hmm(x.starts_at)+' – '+hmm(x.ends_at),lab:nm.split(' ')[0]+' '+hmm(x.starts_at)+'–'+hmm(x.ends_at).replace(/^0/,'')})});
 Object.keys(m).forEach(function(k){m[k].sort(function(a,b){return (CALO[a.k]-CALO[b.k])||(a.at-b.at)})});return m}
function calList(){
 var cm=cmap(),x=APP.d.reservations,rs=x.rows.slice().sort(function(a,b){return new Date(a.starts_at)-new Date(b.starts_at)});
 if(!rs.length)return '<p class="mut">Zatím žádné rezervace.</p>';
 var h='',cur='',now=dayStart(0);h+='<div class="cal">';
 rs.forEach(function(r){var k=locD(r.starts_at);if(k!==cur){if(cur)h+='</ul>';cur=k;var d=new Date(r.starts_at);h+='<h4 class="dh'+(d<now?' past':'')+(k===locD(new Date())?' today':'')+'">'+d.toLocaleDateString('cs-CZ',{weekday:'long',day:'numeric',month:'long',year:'numeric'})+'</h4><ul class="rows big">'}
  h+='<li data-edit="reservations:'+esc(r.id)+'"'+(r.canceled?' class="off"':'')+'><div><b>'+esc(r.title||'Rezervace')+'</b><small>'+esc(cm[r.customer_id]||'bez zákazníka')+(r.location_id&&locName(r.location_id)?' · '+esc(locName(r.location_id)):'')+'</small></div><span>'+hmm(r.starts_at)+' – '+hmm(r.ends_at)+(r.canceled?' · zrušeno':'')+'</span></li>'});
 return h+'</ul></div>'}
function teamNames(){var a=[];(APP.team||[]).forEach(function(x){if(x.email)a.push(x.email)});if(APP.meta&&APP.meta.full_name&&a.indexOf(APP.meta.full_name)<0)a.unshift(APP.meta.full_name);return a}
function calRe(){var m=A('appMain'),y=m?m.scrollTop:0;appTab(APP.tab);if(m)m.scrollTop=y}
/* ---- online rezervace (veřejná stránka) ---- */
var BKDN=['Pondělí','Úterý','Středa','Čtvrtek','Pátek','Sobota','Neděle'];
function slugify(t){return String(t||'').normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,40)}
function bookUrl(sl){return (location.protocol==='file:'||DEMO?'https://vexaronet.com':location.origin)+'/?r='+sl}
function onlineView(){
 var P=APP.d.booking_profiles,pr=P.rows[0]||{},sv=APP.d.booking_services,hrs=pr.hours||{},has=!!pr.slug,slug=pr.slug||slugify(APP.co);
 if(P.err)return '<div class="draft">Online rezervace vyžadují dokončit nastavení databáze (SQL schema_rezervace). Detail: '+esc(P.err)+'</div>';
 var h='<div class="card2 note"><b>Veřejná rezervační stránka.</b> Nastavíte otevírací dobu a služby, zkopírujete odkaz a pošlete ho zákazníkům (web, Instagram, vizitka, e-mail). Zákazník si sám vybere službu a volný termín, rezervace se vám objeví v kalendáři. Zákazník po rezervaci dostane potvrzení e-mailem se souborem do kalendáře.</div>';
 if(has)h+='<div class="card2 bklink"><div><small class="mut">Váš odkaz pro zákazníky'+(pr.enabled?'':' (stránka je zatím vypnutá)')+'</small><b>'+esc(bookUrl(pr.slug))+'</b>'+(DEMO?'<small class="mut">V ukázce odkaz na internetu nefunguje, tlačítko níže otevře náhled.</small>':'')+'</div><div class="dact">'+(DEMO?'':'<button type="button" class="btn btn-ghost btn-sm" data-bkcopy="1">Kopírovat odkaz</button>')+'<button type="button" class="btn btn-main btn-sm" data-bkopen="1">'+(DEMO?'Zobrazit jako zákazník':'Otevřít stránku')+'</button></div></div>';
 h+='<form id="bookForm" class="card2"><h3>Nastavení stránky</h3><div class="fg"><div class="f full"><label class="chk"><input type="checkbox" id="bk_on"'+(pr.enabled?' checked':'')+'><span>Stránka je zapnutá (zákazníci se mohou objednávat)</span></label></div>'
 +'<div class="f full"><label for="bk_slug">Adresa stránky</label><div class="slugr"><span>vexaronet.com/?r=</span><input id="bk_slug" value="'+esc(slug)+'" maxlength="41" autocomplete="off"></div></div>'
 +'<div class="f full"><label for="bk_title">Nadpis</label><input id="bk_title" maxlength="120" value="'+esc(pr.title||(APP.co+' – online rezervace'))+'"></div>'
 +'<div class="f full"><label for="bk_desc">Krátký popis</label><textarea id="bk_desc" rows="2" maxlength="400">'+esc(pr.description||'')+'</textarea></div>'
 +'<div class="f"><label for="bk_addr">Adresa provozovny</label><input id="bk_addr" maxlength="200" value="'+esc(pr.address||'')+'"></div><div class="f"><label for="bk_tel">Telefon</label><input id="bk_tel" maxlength="40" value="'+esc(pr.phone||'')+'"></div></div>'
 +'<h4 style="margin:16px 0 8px">Otevírací doba</h4><div class="hrs">'+BKDN.map(function(n,i){var d=i+1,o=has?hrs[d]:(d<=5?{o:'08:00',c:'17:00'}:null);return '<div class="hr"><label class="chk"><input type="checkbox" id="hk_'+d+'_on"'+(o?' checked':'')+'><span>'+n+'</span></label><input type="time" id="hk_'+d+'_o" value="'+esc(o?o.o:'08:00')+'" aria-label="Od"><span>–</span><input type="time" id="hk_'+d+'_c" value="'+esc(o?o.c:'17:00')+'" aria-label="Do"></div>'}).join('')+'</div>'
 +'<div class="fg" style="margin-top:12px"><div class="f"><label for="bk_step">Krok nabízených časů</label><select id="bk_step">'+[15,30,45,60].map(function(m){return '<option value="'+m+'"'+((pr.slot_minutes||30)===m?' selected':'')+'>'+m+' minut</option>'}).join('')+'</select></div><div class="f"><label for="bk_cap">Kolik zákazníků najednou (kapacita)</label><input id="bk_cap" type="number" min="1" max="50" value="'+esc(pr.capacity||1)+'"></div></div>'
 +'<div class="st" id="entSt" role="status"></div><div class="dact"><button class="btn btn-main" type="submit">Uložit nastavení</button></div></form>'
 +'<section class="card2"><div class="bar2"><h3>Služby</h3><button type="button" class="btn btn-main btn-sm" data-new="booking_services">+ Přidat službu</button></div>'+errBox(sv)
 +(sv.rows.length?'<ul class="rows big">'+sv.rows.map(function(x){return '<li data-edit="booking_services:'+esc(x.id)+'"'+(x.active===false?' class="off"':'')+'><div><b>'+esc(x.name)+'</b><small>'+esc(x.duration_min)+' min'+(x.active===false?' · nenabízí se':'')+'</small></div><span>'+(x.price!=null?fM(x.price):'cena neuvedena')+'</span></li>'}).join('')+'</ul>':'<p class="mut">Zatím žádné služby. Přidejte první nebo použijte doporučení pro váš obor níže.</p>')+(function(){var rs=(prof().svc||[]).filter(function(x){return !sv.rows.some(function(y){return String(y.name).toLowerCase()===x[0].toLowerCase()})});return rs.length?'<h4>Doporučené služby pro obor '+esc(obKey(APP.ind))+'</h4><p class="mut fine">Kliknutím otevřete formulář s předvyplněným názvem a délkou. Cenu doplníte vy, protože ji znáte nejlépe.</p><div class="chipsr">'+rs.map(function(x,i){return '<button type="button" class="btn btn-ghost btn-sm" data-svc="'+esc(x[0])+'">+ '+esc(x[0])+' ('+x[1]+' min)</button>'}).join('')+'</div>':''})()+'</section>';
 return h}
async function saveBook(f){
 var sl=A('bk_slug').value.trim().toLowerCase();if(!/^[a-z0-9][a-z0-9-]{2,40}$/.test(sl)){entMsg('Adresa: 3 až 41 znaků, malá písmena bez diakritiky, čísla a pomlčky.');return}
 var hh={};for(var d=1;d<=7;d++){if(A('hk_'+d+'_on').checked){var o=A('hk_'+d+'_o').value,c=A('hk_'+d+'_c').value;if(!o||!c||o>=c){entMsg('Zkontrolujte otevírací dobu ('+BKDN[d-1]+').');return}hh[d]={o:o,c:c}}}
 var en=A('bk_on').checked;
 if(en&&!APP.d.booking_services.rows.some(function(x){return x.active!==false})){entMsg('Pro zapnutí stránky přidejte alespoň jednu službu.');return}
 if(en&&!Object.keys(hh).length){entMsg('Nastavte alespoň jeden otevřený den.');return}
 var row={company_id:APP.cid,slug:sl,enabled:en,title:A('bk_title').value.trim()||null,description:A('bk_desc').value.trim()||null,address:A('bk_addr').value.trim()||null,phone:A('bk_tel').value.trim()||null,hours:hh,slot_minutes:Number(A('bk_step').value)||30,capacity:Math.max(1,parseInt(A('bk_cap').value)||1),updated_at:new Date().toISOString()};
 var b=f.querySelector('button[type=submit]');b.disabled=true;var r=await getSb().from('booking_profiles').upsert(row,{onConflict:'company_id'});b.disabled=false;
 if(r.error){entMsg(/duplicate|unique|23505/i.test(r.error.message+(r.error.code||''))?'Tuto adresu už používá jiná firma, zvolte jinou.':'Nepodařilo se uložit: '+r.error.message);return}
 await refresh();appTab('online');toast(en?'Uloženo. Stránka je zapnutá.':'Uloženo. Stránka je zatím vypnutá.','ok')}
function bookOpen(slug,prev){
 var old=A('vxbook');if(old)old.remove();
 var el=document.createElement('div');el.id='vxbook';el.className='vxbook';document.body.appendChild(el);document.documentElement.style.overflow='hidden';
 var B={info:null,svc:null,day:null,slot:null,slots:null,f:{n:'',e:'',p:'',c:false},msg:'',done:null,busy:false,nf:false};
 function ymd(d){return d.getFullYear()+'-'+('0'+(d.getMonth()+1)).slice(-2)+'-'+('0'+d.getDate()).slice(-2)}
 function tm(v){return new Date(v).toLocaleTimeString('cs-CZ',{hour:'2-digit',minute:'2-digit',timeZone:'Europe/Prague'})}
 function close(){el.remove();document.documentElement.style.overflow=A('vxapp')?'hidden':'';if(prev&&A('vxapp'))refresh().then(function(){appTab(APP.tab)});if(!prev){try{history.replaceState(null,'',location.pathname)}catch(e){}}}
 function draw(){
  var I=B.info,h='<div class="bkw"><button type="button" class="bkx" data-bk="close" aria-label="Zavřít">×</button>';
  if(prev)h+='<div class="bkprev">Náhled: takto uvidí stránku vaši zákazníci. Rezervace v ukázce zůstane jen v ukázkových datech.</div>';
  if(B.nf){el.innerHTML=h+'<h1>Stránka nenalezena</h1><p class="bkd">Rezervační stránka neexistuje nebo je vypnutá. Zkontrolujte odkaz.</p></div>';return}
  if(!I){el.innerHTML=h+'<p class="bkd">Načítám…</p></div>';return}
  h+='<h1>'+esc(I.title||I.name)+'</h1>'+(I.description?'<p class="bkd">'+esc(I.description)+'</p>':'')+'<p class="bkm">'+esc(I.name)+(I.address?' · '+esc(I.address):'')+(I.phone?' · '+esc(I.phone):'')+'</p>';
  if(B.done){var dn=B.done,dd=new Date(dn.start);h+='<div class="bkok"><div class="bkck">✓</div><h2>Rezervace je uložená</h2><p><b>'+esc(dn.service)+'</b><br>'+esc(dd.toLocaleDateString('cs-CZ',{weekday:'long',day:'numeric',month:'long',year:'numeric',timeZone:'Europe/Prague'}))+' v '+esc(tm(dn.start))+'<br>'+esc(dn.business)+'</p><p class="bkm">'+(dn.mail==='sent'?'Potvrzení jsme poslali na váš e-mail, včetně souboru do kalendáře. Pokud nemůžete přijít, dejte provozovně vědět.':DEMO?'V ukázce se e-mail neodesílá. V ostrém provozu zákazník dostane potvrzení e-mailem.':'Potvrzení e-mailem se nepodařilo odeslat, termín si prosím poznamenejte. Pokud nemůžete přijít, dejte provozovně vědět.')+'</p></div>'}
  else{
   h+='<h2>1. Vyberte službu</h2><div class="bks">'+(I.services||[]).map(function(x){return '<button type="button" class="bkc'+(B.svc===x.id?' on':'')+'" data-bks="'+esc(x.id)+'"><b>'+esc(x.name)+'</b><small>'+esc(x.duration_min)+' min'+(x.price!=null?' · '+Number(x.price).toLocaleString('cs-CZ')+' Kč':'')+'</small></button>'}).join('')+'</div>';
   if(B.svc){h+='<h2>2. Vyberte den</h2><div class="bkd2">';var n=0;for(var i=0;i<28&&n<21;i++){var d=new Date();d.setDate(d.getDate()+i);var dw=d.getDay()||7;if(I.hours&&I.hours[dw]){n++;h+='<button type="button" class="bkc sm'+(B.day===ymd(d)?' on':'')+'" data-bkd="'+ymd(d)+'"><b>'+esc(d.toLocaleDateString('cs-CZ',{weekday:'short'}))+'</b><small>'+d.getDate()+'. '+(d.getMonth()+1)+'.</small></button>'}}h+='</div>'}
   if(B.day){h+='<h2>3. Vyberte čas</h2>';if(B.slots===null)h+='<p class="bkd">Načítám volné časy…</p>';else if(!B.slots.length)h+='<p class="bkd">Tento den už není nic volného. Zkuste jiný den.</p>';else h+='<div class="bkt">'+B.slots.map(function(t){return '<button type="button" class="bkc sm'+(B.slot===t?' on':'')+'" data-bkt="'+esc(t)+'">'+esc(tm(t))+'</button>'}).join('')+'</div>'}
   if(B.slot){h+='<h2>4. Vaše údaje</h2><form id="bkForm"><div class="bkfg"><label>Jméno a příjmení<input id="bk_n" maxlength="120" required autocomplete="name" value="'+esc(B.f.n)+'"></label><label>E-mail<input id="bk_e" type="email" maxlength="200" required autocomplete="email" value="'+esc(B.f.e)+'"></label><label>Telefon (nepovinné)<input id="bk_p" type="tel" maxlength="40" autocomplete="tel" value="'+esc(B.f.p)+'"></label></div><label class="bkcons"><input type="checkbox" id="bk_c"'+(B.f.c?' checked':'')+' required><span>Souhlasím, že provozovna zpracuje mé jméno, e-mail a telefon za účelem vyřízení této rezervace.</span></label>'+(B.msg?'<div class="bkerr" role="alert">'+esc(B.msg)+'</div>':'')+'<button class="bkgo" type="submit"'+(B.busy?' disabled':'')+'>'+(B.busy?'Ukládám…':'Rezervovat')+'</button></form>'}
   else if(B.msg)h+='<div class="bkerr" role="alert">'+esc(B.msg)+'</div>'}
  h+='<p class="bkf">Rezervační stránka běží na <b>Vexaronet</b>.</p></div>';
  var st=el.scrollTop;el.innerHTML=h;el.scrollTop=st}
 async function loadSlots(){B.slots=null;draw();try{var r=await getSb().rpc('public_slots',{p_slug:slug,p_service:B.svc,p_day:B.day});B.slots=r.error?[]:(r.data||[])}catch(e){B.slots=[]}draw()}
 el.addEventListener('input',function(e){var t=e.target;if(t.id==='bk_n')B.f.n=t.value;else if(t.id==='bk_e')B.f.e=t.value;else if(t.id==='bk_p')B.f.p=t.value;else if(t.id==='bk_c')B.f.c=t.checked});
 el.addEventListener('click',function(e){var t=e.target.closest('[data-bk],[data-bks],[data-bkd],[data-bkt]');if(!t)return;
  if(t.dataset.bk==='close'){close();return}
  if(t.dataset.bks){B.svc=t.dataset.bks;B.day=null;B.slot=null;B.slots=null;B.msg='';draw();return}
  if(t.dataset.bkd){B.day=t.dataset.bkd;B.slot=null;B.msg='';loadSlots();return}
  if(t.dataset.bkt){B.slot=t.dataset.bkt;B.msg='';draw();setTimeout(function(){var n=A('bk_n');if(n)n.focus()},50)}});
 el.addEventListener('submit',async function(e){if(e.target.id!=='bkForm')return;e.preventDefault();if(B.busy)return;B.busy=true;B.msg='';draw();
  var r=null;
  if(!DEMO){try{var fr=await fetch('/api/book',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({slug:slug,service:B.svc,start:B.slot,name:B.f.n,email:B.f.e,phone:B.f.p||null})});if(fr.status!==404&&fr.status!==405){var fj=await fr.json().catch(function(){return null});r=fr.ok&&fj&&fj.ok?{data:fj}:{error:{message:String(fj&&fj.error||'x')}}}}catch(x){r=null}}
  if(!r){try{r=await getSb().rpc('public_book',{p_slug:slug,p_service:B.svc,p_start:B.slot,p_name:B.f.n,p_email:B.f.e,p_phone:B.f.p||null})}catch(x){r={error:{message:'x'}}}}
  B.busy=false;
  if(r.error||!r.data){var m=String(r.error&&r.error.message||'');B.msg=/slot_taken/.test(m)?'Tento čas mezitím někdo obsadil. Vyberte prosím jiný.':/bad_email/.test(m)?'Zadejte platný e-mail.':/bad_name/.test(m)?'Zadejte jméno a příjmení.':/too_many/.test(m)?'Příliš mnoho rezervací za krátkou dobu. Zkuste to později.':'Rezervaci se nepodařilo uložit. Zkuste to znovu.';if(/slot_taken/.test(m)){B.slot=null;loadSlots();return}draw();return}
  B.done=r.data;draw()});
 draw();
 (async function(){try{var c=getSb();if(!c){B.nf=true;draw();return}var r=await c.rpc('public_booking_info',{p_slug:slug});if(r.error||!r.data){B.nf=true}else B.info=r.data}catch(e){B.nf=true}draw()})()}
function invName(f){var cu=f.customer_snapshot;return cu&&typeof cu==='object'?(cu.name||cu.company_name||''):''}
function overInv(){var t0=dayStart(0);return APP.d.invoices.rows.filter(function(x){return !x.paid_at&&x.due_on&&new Date(x.due_on)<t0})}
function overJobs(){var t0=dayStart(0);return APP.d.jobs.rows.filter(function(x){return x.due_at&&!DONE.test(x.status||'')&&new Date(x.due_at)<t0})}
function reminderText(f){return 'Dobrý den'+(invName(f)?', '+invName(f):'')+',\ndovolujeme si Vás upozornit, že faktura č. '+(f.number||'')+' ve výši '+fM(f.total,f.currency)+' byla splatná dne '+fD(f.due_on)+'. Prosíme o její úhradu. Pokud jste již platbu provedli, považujte tento e-mail za bezpředmětný.\nDěkujeme a zdravíme,\n'+APP.co}
function doAct(a){
 if(a==='reminders'){var L=overInv();if(!L.length){toast('Žádné faktury po splatnosti.');return}
  modal('<h3>Upomínky k '+L.length+' '+plural(L.length,'faktuře','fakturám','fakturám')+'</h3><p class="mut">Odesílání e-mailů zatím není připojené. Texty si zkopírujte a pošlete sami. Můžete také vytvořit úkoly k urgenci.</p><textarea id="remTx" rows="10" readonly>'+esc(L.map(reminderText).join('\n\n---\n\n'))+'</textarea><div class="dact"><button class="pri" type="button" data-do="copy">Zkopírovat texty</button><button class="btn btn-ghost" type="button" data-do="remtasks">Vytvořit úkoly k urgenci</button><button class="btn btn-ghost" type="button" data-app="mclose">Zavřít</button></div>');return}
 if(a==='jobtasks'){var J=overJobs();modal('<h3>Vytvořit úkoly?</h3><p>Vytvořím '+J.length+' '+plural(J.length,'úkol','úkoly','úkolů')+' s termínem dnes:</p><ul class="ticks">'+J.map(function(j){return '<li>Kontaktovat zákazníka: '+esc(j.title)+'</li>'}).join('')+'</ul><div class="dact"><button class="pri" type="button" data-do="jobtasks">Ano, vytvořit</button><button class="btn btn-ghost" type="button" data-app="mclose">Zrušit</button></div>');return}
 if(a==='grow'){appTab('ceo');setTimeout(function(){ceoAsk('Na základě čísel navrhni 3 konkrétní kroky, jak v příštích 30 dnech zvýšit tržby a snížit závislost na největším zákazníkovi.')},50);return}
 if(a==='winback'){appTab('ceo');setTimeout(function(){ceoAsk('Připrav krátký přátelský e-mail pro zákazníky, kteří u nás 90 dní nic neobjednali. Nabídni jim domluvit termín.')},50);return}
 if(a==='report'){var L=weekFacts();modal('<h3>Týdenní report AI CEO</h3><p class="mut">Fakta z vašich dat za posledních 7 dní. Slovní shrnutí od AI je rada, ne účetní závěr.</p><textarea id="remTx" rows="11" readonly>'+esc(L.join('\n'))+'</textarea><div class="dact"><button class="pri" type="button" data-do="copy">Zkopírovat</button>'+(hasCeo()?'<button class="btn btn-ghost" type="button" data-do="repai">Slovní shrnutí od AI</button>':'')+'<button class="btn btn-ghost" type="button" data-app="mclose">Zavřít</button></div>');return}
 if(a==='offer'){appTab('ceo');setTimeout(function(){ceoAsk('Připrav krátkou obchodní nabídku pro stávající zákazníky, kteří zatím nemají žádnou zakázku.')},50)}}
async function mkTasks(titles){
 var have={};APP.d.tasks.rows.forEach(function(t){if(!t.completed)have[t.title]=1});var rows=titles.filter(function(t){return !have[t]}).map(function(t){return {company_id:APP.cid,title:t,due_at:new Date(dayStart(0).getTime()+12*36e5).toISOString()}});
 if(!rows.length){closeModal();appTab('ukoly');toast('Tyto úkoly už máte v části Úkoly.');return}
 var r=await getSb().from('tasks').insert(rows);if(r.error){toast('Nepodařilo se vytvořit úkoly: '+r.error.message,'err');return}
 closeModal();await refresh();appTab('ukoly');toast('Vytvořeno úkolů: '+rows.length+'. Najdete je v části Úkoly.','ok')}
function cmap(){var m={};APP.d.customers.rows.forEach(function(x){m[x.id]=custName(x)});return m}
function head(ent,btn,ph){return '<div class="bar2">'+(ph?'<input class="srch" type="search" placeholder="'+ph+'" aria-label="Hledat">':'<span></span>')+'<button type="button" class="btn btn-main btn-sm" data-new="'+ent+'">'+btn+'</button></div>'}

/* ===== Import a export zákazníků (CSV) ===== */
var CI={rows:[],skip:0};
function csTools(ent){var n=APP.d[ent]&&APP.d[ent].rows.length;return '<div class="dact cstools">'+(ent==='customers'?'<button type="button" class="btn btn-ghost btn-sm" data-cs="imp">Import z CSV / Excelu</button>':'')+(n?'<button type="button" class="btn btn-ghost btn-sm" data-cs="exp:'+ent+'">Export do CSV</button>':'')+'</div>'}
function csDl(rows,name){var csv='﻿'+rows.map(function(r){return r.map(function(c){var t=String(c==null?'':c);return /[;"\n\r]/.test(t)?'"'+t.replace(/"/g,'""')+'"':t}).join(';')}).join('\r\n'),b=new Blob([csv],{type:'text/csv;charset=utf-8'}),u=URL.createObjectURL(b),a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(u)},1500)}
function csExport(ent){var d=APP.d,rows;
 if(ent==='customers'){rows=[['Jméno / firma','E-mail','Telefon','Fakturační adresa','IČO','DIČ','Poznámka']];d.customers.rows.forEach(function(c){rows.push([c.name||'',c.email||'',c.phone||'',c.billing_address||'',c.ico||'',c.dic||'',c.notes||''])})}
 else{rows=[['Název','Zákazník','Stav','Cena v Kč','Termín','Popis']];d.jobs.rows.forEach(function(j){var cu=d.customers.rows.filter(function(x){return x.id===j.customer_id})[0];rows.push([j.title||'',cu?custName(cu):'',stLab(j),j.price==null?'':String(j.price).replace('.',','),String(j.due_at||'').slice(0,10),j.description||''])})}
 if(rows.length<2){toast('Není co exportovat.','err');return}
 csDl(rows,ent==='customers'?'vexaronet-zakaznici.csv':'vexaronet-zakazky.csv');toast('Export stažen.','ok')}
function ciParse(text){
 var ls=String(text||'').replace(/^﻿/,'').split(/\r?\n/).filter(function(l){return l.trim()});
 if(ls.length<2)return {err:'Soubor je prázdný nebo obsahuje jen záhlaví.'};
 var dl=';',bn=-1;[';',',','\t'].forEach(function(d){var n=bkSplit(ls[0],d).length;if(n>bn){bn=n;dl=d}});
 var h=bkSplit(ls[0],dl).map(bkNorm),c={};
 h.forEach(function(x,j){
  if(c.name==null&&/^(jmeno|nazev|firma|zakaznik|klient|name|obchodni jmeno|jmeno a prijmeni|nazev firmy|jmeno firmy)/.test(x))c.name=j;
  else if(c.email==null&&/e-?mail/.test(x))c.email=j;
  else if(c.phone==null&&/(telefon|mobil|phone|gsm|^tel)/.test(x))c.phone=j;
  else if(c.dic==null&&/^(dic|ic dph|vat)/.test(x))c.dic=j;
  else if(c.ico==null&&/^(ico|ic|ic o)$/.test(x))c.ico=j;
  else if(c.billing_address==null&&/(adres|ulice|sidlo|address)/.test(x))c.billing_address=j;
  else if(c.notes==null&&/(poznamk|note|komentar)/.test(x))c.notes=j});
 if(c.name==null)return {err:'V záhlaví nevidím sloupec se jménem. Přejmenujte první řádek tak, aby sloupec s jmény zákazníků měl název „Jméno“ nebo „Firma“ (další sloupce: E-mail, Telefon, IČO, DIČ, Adresa, Poznámka).'};
 var ex={};APP.d.customers.rows.forEach(function(r){ex[(r.email||r.name||'').toLowerCase().trim()]=1});
 var out=[],skip=0,seen={};
 ls.slice(1,501).forEach(function(l){var p=bkSplit(l,dl),o={};['name','email','phone','ico','dic','billing_address','notes'].forEach(function(k){var v=c[k]!=null?String(p[c[k]]||'').trim():'';if(v)o[k]=v.slice(0,500)});
  if(!o.name){return}
  var key=(o.email||o.name).toLowerCase().trim();if(ex[key]||seen[key]){skip++;return}seen[key]=1;out.push(o)});
 return {rows:out,skip:skip,total:Math.max(0,ls.length-1),cols:Object.keys(c)}}
function ciModal(){CI={rows:[],skip:0};modal('<h3>Import zákazníků</h3><p class="mut">Máte zákazníky v Excelu? Uložte tabulku jako <b>CSV</b> (Soubor → Uložit jako → CSV) a nahrajte ji sem. Rozpoznáme sloupce Jméno / Firma, E-mail, Telefon, IČO, DIČ, Adresa a Poznámka. Před importem uvidíte náhled a nic se neuloží bez vašeho potvrzení. Zákazníci, které už máte (stejný e-mail nebo jméno), se přeskočí.</p><div class="f full"><label for="ciFile">Soubor CSV</label><input id="ciFile" type="file" accept=".csv,.txt,text/csv"></div><div class="st" id="ciSt" role="status"></div><div id="ciRes"></div><div class="dact"><button class="pri" type="button" data-cs="read">Načíst soubor</button><button class="btn btn-ghost" type="button" data-app="mclose">Zavřít</button></div>')}
function ciSt(t,c){var e=A('ciSt');if(e){e.className='st'+(c?' '+c:'');e.textContent=t||''}}
async function ciRead(){var fi=A('ciFile'),f=fi&&fi.files&&fi.files[0];if(!f){ciSt('Vyberte soubor CSV.','err');return}
 if(f.size>2e6){ciSt('Soubor je příliš velký (nejvýše 2 MB).','err');return}
 var t=await f.text();var r=ciParse(t);if(r.err){ciSt(r.err,'err');A('ciRes').innerHTML='';return}
 var lim=effPlan()==='start'?Math.max(0,50-APP.d.customers.rows.length):500;
 if(!r.rows.length){ciSt('Nenašel jsem žádné nové zákazníky'+(r.skip?' ('+r.skip+' už v evidenci je).':'.'),'err');A('ciRes').innerHTML='';return}
 var use=r.rows.slice(0,lim);CI={rows:use,skip:r.skip};
 var warn=use.length<r.rows.length?'<p class="mut fine">Tarif START umožňuje nejvýše 50 zákazníků, naimportuje se prvních '+use.length+'.</p>':'';
 if(!use.length){ciSt('Tarif START umožňuje nejvýše 50 zákazníků a limit už je naplněný.','err');return}
 ciSt('','');
 A('ciRes').innerHTML='<p><b>Nalezeno '+r.rows.length+' nových zákazníků</b>'+(r.skip?', '+r.skip+' už v evidenci je a přeskočí se':'')+'. Ukázka prvních řádků:</p><ul class="rows">'+use.slice(0,5).map(function(o){return '<li><b>'+esc(o.name)+'</b><span>'+[o.email,o.phone,o.ico].filter(Boolean).map(esc).join(' · ')+'</span></li>'}).join('')+'</ul>'+warn+'<div class="dact"><button class="pri" type="button" data-cs="go">Importovat '+use.length+' zákazníků</button></div>'}
async function ciGo(){if(!CI.rows.length)return;var b=document.querySelector('[data-cs=go]');if(b)b.disabled=true;
 try{for(var i=0;i<CI.rows.length;i+=100){var ch=CI.rows.slice(i,i+100).map(function(o){return Object.assign({company_id:APP.cid},o)});var r=await getSb().from('customers').insert(ch);if(r.error)throw r.error}}
 catch(ex){if(b)b.disabled=false;ciSt('Import se nepodařilo dokončit: '+(ex.message||ex)+'. Již vložené záznamy zůstaly, zkuste soubor načíst znovu, duplicity se přeskočí.','err');await refresh();return}
 var n=CI.rows.length;CI={rows:[],skip:0};closeModal();await refresh();appTab('zakaznici');toast('Naimportováno '+n+' zákazníků.','ok')}
function listView(ent,ph,btn,row,emptyT,sort){
 var x=APP.d[ent],rs=x.rows.slice();if(sort)rs.sort(sort);var h=head(ent,btn,ph)+errBox(x);
 if(!rs.length)return h+'<p class="mut">'+emptyT+'</p>';
 return h+'<ul class="rows big" id="lst">'+rs.map(function(r){return '<li data-edit="'+ent+':'+esc(r.id)+'">'+row(r)+'</li>'}).join('')+'</ul>'}

/* ---- formuláře (přidání, úprava, mazání) ---- */
function crm2On(k){return !APP.crm2||APP.crm2[k||'cust']!==false}
function custFields(){var n=crm2On('cust');return [{k:'name',l:'Jméno / firma',t:'text',req:1},{k:'email',l:'E-mail',t:'email'},{k:'phone',l:'Telefon',t:'tel'}].concat(n?[{k:'status',l:'Stav klienta',t:'sel',opts:CRMCS.map(function(x){return [x[0],x[1]]}),req:1},{k:'country_code',l:'Stát',t:'sel',opts:[['','– neuvedeno –']].concat(VXEU.list().map(function(x){return [x.code,x.name]}))}]:[],[{k:'billing_address',l:'Fakturační adresa'},{k:'ico',l:n?'IČO / registrační číslo firmy':'IČO'},{k:'dic',l:n?'DIČ / IČ DPH (např. CZ12345678, DE123456789)':'DIČ'}],n?[{k:'website',l:'Web (https://…)'},{k:'source',l:'Odkud klient přišel',list:['Doporučení','Web','Sociální sítě','Reklama','Telefon','Veletrh','Jiné']},{k:'tags',l:'Štítky (oddělte čárkou)'},{k:'next_contact_on',l:'Další kontakt (připomenutí)',t:'dateonly'}]:[],[{k:'notes',l:'Poznámka',t:'textarea'},{k:'archived',l:'Archivovat (skrýt ze seznamu)',t:'bool'}])}
function locFld(){var L=(APP.d.locations||{rows:[]}).rows;return L.length?[{k:'location_id',l:'Pobočka',t:'loc'}]:[]}
function locName(id){var L=(APP.d.locations||{rows:[]}).rows.filter(function(x){return x.id===id})[0];return L?L.name:''}
function entDef(ent){
 var cu=APP.d.customers.rows;
 var D={
  customers:{n:'zákazníka',f:custFields},
  jobs:{n:'zakázku',f:function(){var st=(prof().statuses||[]).slice();APP.d.jobs.rows.forEach(function(j){var l=stLab(j);if(l&&st.indexOf(l)<0)st.push(l)});return [{k:'title',l:'Název',req:1},{k:'customer_id',l:'Zákazník',t:'cust'},{k:'price',l:'Cena (Kč)',t:'number'},{k:'due_at',l:'Termín',t:'date'},{k:'status',l:'Stav',t:'text',list:st},{k:'description',l:'Popis',t:'textarea'},{k:'notes',l:'Poznámky',t:'textarea'}].concat(locFld())}},
  reservations:{n:'rezervaci',f:function(){return [{k:'title',l:'Název',req:1},{k:'customer_id',l:'Zákazník',t:'cust'},{k:'starts_at',l:'Začátek',t:'datetime-local',req:1},{k:'ends_at',l:'Konec',t:'datetime-local',req:1},{k:'reminder_minutes',l:'Připomenout minut předem',t:'number'}].concat(locFld(),[{k:'canceled',l:'Zrušeno',t:'bool'}])}},
  financial_entries:{n:'finanční záznam',f:function(){var ks=['income','expense'];APP.d.fe.rows.forEach(function(r){if(r.kind&&ks.indexOf(r.kind)<0)ks.push(r.kind)});return [{k:'title',l:'Popis',req:1},{k:'kind',l:'Druh',t:'sel',opts:ks.map(function(k){return [k,KL(k)]}),req:1},{k:'amount',l:'Částka (Kč)',t:'number',req:1},{k:'entry_date',l:'Datum',t:'dateonly',req:1}]}},
  shifts:{n:'směnu',f:function(){return [{k:'person',l:'Zaměstnanec (jméno nebo e-mail)',req:1,list:teamNames()},{k:'starts_at',l:'Začátek směny',t:'datetime-local',req:1},{k:'ends_at',l:'Konec směny',t:'datetime-local',req:1},{k:'note',l:'Poznámka'}].concat(locFld())}},
  booking_services:{n:'službu',f:function(){return [{k:'name',l:'Název služby',req:1},{k:'duration_min',l:'Délka (minuty)',t:'number',req:1},{k:'price',l:'Cena (Kč, nepovinné)',t:'number'},{k:'active',l:'Nabízet zákazníkům',t:'bool',def:1}]}},
  marketing_posts:{n:'příspěvek',f:function(){return [{k:'title',l:'Název',req:1},{k:'channel',l:'Kanál',t:'sel',opts:MKCH.map(function(c){return [c,c]})},{k:'status',l:'Stav',t:'sel',opts:Object.keys(MKST).map(function(k){return [k,MKST[k]]}),req:1},{k:'planned_on',l:'Naplánováno na',t:'dateonly'},{k:'body',l:'Text',t:'textarea'}]}},
  products:{n:'zboží',f:function(){return [{k:'name',l:'Název',req:1},{k:'sku',l:'Kód (nepovinné)'},{k:'unit',l:'Jednotka (ks, l, m…)',t:'text',list:['ks','l','kg','m','bal']},{k:'cost',l:'Nákupní cena (Kč)',t:'number'},{k:'price',l:'Prodejní cena (Kč)',t:'number'},{k:'min_qty',l:'Minimální zásoba (upozornění)',t:'number'},{k:'active',l:'Používá se',t:'bool',def:1},{k:'shop_visible',l:'Zobrazit v e-shopu (veřejný obchod)',t:'bool'},{k:'description',l:'Popis pro e-shop',t:'textarea'},{k:'image_url',l:'Odkaz na obrázek (https://…, nepovinné)'},{k:'vat_rate',l:'Sazba DPH pro e-shop (%, u plátců DPH)',t:'number'}]}},
  locations:{n:'pobočku',f:function(){return [{k:'name',l:'Název pobočky',req:1},{k:'address',l:'Adresa (ulice a číslo)'},{k:'city',l:'Město'},{k:'phone',l:'Telefon',t:'tel'},{k:'email',l:'E-mail',t:'email'},{k:'hours',l:'Otevírací doba (např. Po–Pá 8–17)'},{k:'note',l:'Poznámka',t:'textarea'},{k:'active',l:'Pobočka je v provozu',t:'bool',def:1}]}},
  deals:{n:'obchodní případ',f:function(){return [{k:'title',l:'Název případu',req:1},{k:'customer_id',l:'Zákazník',t:'cust'},{k:'value',l:'Hodnota (Kč)',t:'number'},{k:'stage',l:'Fáze',t:'sel',opts:CRMST.map(function(s){return [s[0],s[1]]}),req:1},{k:'probability',l:'Pravděpodobnost úspěchu (%)',t:'number'},{k:'expected_close',l:'Očekávané uzavření',t:'dateonly'},{k:'note',l:'Poznámka',t:'textarea'}].concat(crm2On('deal')?[{k:'lost_reason',l:'Důvod prohry (jen u prohraného případu)'}]:[])}},
  tasks:{n:'úkol',f:function(){return [{k:'title',l:'Úkol',req:1}].concat(crm2On('task')?[{k:'customer_id',l:'Klient',t:'cust'}]:[],[{k:'due_at',l:'Termín',t:'date'},{k:'description',l:'Popis',t:'textarea'},{k:'completed',l:'Hotovo',t:'bool'}])}}
 };return D[ent]}

function rpcInv(action,doc){return getSb().rpc('invoice_action',{cid:APP.cid,action:action,doc:doc})}
function itemRow(){return '<div class="irow"><input class="id" placeholder="Popis položky" aria-label="Popis"><input class="iq" type="number" step="any" value="1" aria-label="Množství"><input class="iu" value="ks" aria-label="Jednotka"><input class="ip" type="number" step="any" placeholder="Cena s DPH" aria-label="Cena za jednotku s DPH"><select class="iv" aria-label="Sazba DPH"><option>21</option><option>12</option><option>0</option></select><button type="button" class="lnk" data-delrow="1" aria-label="Odebrat">×</button></div>'}
function invTotals(){var t=0;[].forEach.call(document.querySelectorAll('#iRows .irow'),function(r){t+=(parseFloat(r.querySelector('.iq').value)||0)*(parseFloat(r.querySelector('.ip').value)||0)});var e=A('iTot');if(e)e.textContent='Celkem s DPH: '+fM(Math.round(t*100)/100)}
function invForm(){var lm=limitMsg('invoices');if(lm){toast(lm,'err');return}
 var cs=APP.d.customers.rows,td=locD(new Date()),du=locD(new Date(Date.now()+14*864e5));
 if(!cs.length){toast('Nejdřív přidejte zákazníka (menu Zákazníci, tlačítko + Zákazník). Bez zákazníka nejde faktura vystavit.','err');return}
 modal('<h3>Nová faktura</h3><form id="invForm"><div class="fg"><div class="f full"><label for="iC">Zákazník <i>*</i></label><select id="iC">'+cs.map(function(x){return '<option value="'+esc(x.id)+'">'+esc(custName(x))+'</option>'}).join('')+'</select></div><div class="f"><label for="iI">Datum vystavení</label><input id="iI" type="date" value="'+td+'"></div><div class="f"><label for="iT">Datum zdanitelného plnění</label><input id="iT" type="date" value="'+td+'"></div><div class="f"><label for="iD">Splatnost</label><input id="iD" type="date" value="'+du+'"></div><div class="f"><label for="iCur">Měna</label><select id="iCur"><option>CZK</option><option>EUR</option></select></div><div class="f full"><label for="iJ">Zakázka (nepovinné)</label><select id="iJ"><option value="">– bez zakázky –</option>'+APP.d.jobs.rows.map(function(j){return '<option value="'+esc(j.id)+'">'+esc(j.title)+'</option>'}).join('')+'</select></div></div><h4>Položky</h4><div id="iRows">'+itemRow()+'</div><button type="button" class="btn btn-ghost btn-sm" data-addrow="1">+ Položka</button><p class="mut" id="iTot"></p><p class="mut fine">Sazby DPH a jejich použití musí ověřit účetní.</p><div class="st" id="entSt" role="status"></div><div class="dact"><button class="pri" type="submit">Vystavit fakturu</button><button class="btn btn-ghost" type="button" data-app="mclose">Zrušit</button></div></form>')}
function profForm(){
 var last=APP.d.invoices.rows.filter(function(x){return x.supplier_snapshot&&typeof x.supplier_snapshot==='object'}).sort(function(a,b){return new Date(b.created_at)-new Date(a.created_at)})[0],sp=last?last.supplier_snapshot:{};
 function f(k,l,req,t){return '<div class="f"><label for="p_'+k+'">'+l+(req?' <i>*</i>':'')+'</label><input id="p_'+k+'" type="'+(t||'text')+'" value="'+esc(sp[k]==null?'':sp[k])+'"></div>'}
 modal('<h3>Fakturační údaje (dodavatel)</h3><p class="mut">Údaje, které se objeví na fakturách. Uloží se přes pravidla ve vaší databázi.</p><form id="profForm"><div class="fg">'+f('legal_name','Obchodní jméno',1)+f('ico','IČO')+f('dic','DIČ')+f('address_text','Adresa')+f('bank_account','Číslo účtu')+f('iban','IBAN')+f('email','E-mail','','email')+f('country_code','Země (kód)')+f('default_due_days','Splatnost (dní)','','number')+f('default_currency','Výchozí měna')+f('registration_text','Zápis v rejstříku')+'<div class="f full"><label class="chk"><input type="checkbox" id="p_vat_payer"'+(sp.vat_payer?' checked':'')+'><span>Jsem plátce DPH</span></label></div></div><div class="st" id="entSt" role="status"></div><div class="dact"><button class="pri" type="submit">Uložit</button><button class="btn btn-ghost" type="button" data-app="mclose">Zrušit</button></div></form>')}
var PLANPR={start:'zdarma',accountant:'399 Kč / měsíc',pro:'699 Kč / měsíc',business:'1 199 Kč / měsíc',enterprise:'individuální cena'};
/* Změna tarifu (docs/PRAVNI_SOULAD.md, oblast 5): platby nejsou spuštěné, placený tarif je jen NEZÁVAZNÁ ŽÁDOST.
   Tlačítko proto nesmí působit jako závazná objednávka. Před odesláním je vidět cena, období, (ne)obnovování a ukončení. */
function planInfo(x){if(x==='start')return 'Zdarma, bez časového omezení. Žádná platba ani obnovování.';
 if(x==='enterprise')return 'Cena individuálně podle nabídky. Žádost nic neobjednává.';
 return PLANPR[x]+' bez DPH, účtovací období 1 měsíc. Po schválení žádosti nejdřív 30 dní zdarma (jednou na firmu). Platby zatím nejsou spuštěné: nic se neúčtuje ani automaticky neobnovuje. Než začneme účtovat, pošleme vám cenu, období, obnovování a podmínky ukončení k výslovnému potvrzení. Tarif lze kdykoli ukončit přechodem na START.'}
function planModal(){
 var cur=effPlan(),opts=PLAN_ALLOWED.filter(function(x){return x!==cur}).map(function(x){return '<label class="chk"><input type="radio" name="pl" value="'+x+'"><span><b>'+esc(PLANN[x])+'</b> – '+PLANPR[x]+(x==='start'?'':' (bez DPH)')+'<small style="display:block">'+esc(planInfo(x))+'</small></span></label>'}).join('');
 modal('<h3>Změna tarifu</h3><p class="mut">Aktuální tarif: <b>'+esc(PLANN[cur])+'</b>.</p><form id="planForm"><div class="chks" style="grid-template-columns:1fr">'+opts+'</div><div class="f full"><label for="plN">Poznámka (nepovinné)</label><input id="plN" maxlength="300"></div><div class="draft" id="plSum">Přechod na START proběhne ihned a data zůstanou zachována. U placených tarifů jde o <b>nezávaznou žádost</b>: nic neobjednáváte a nic se neúčtuje, protože platební brána zatím není připojená.</div><div class="st" id="entSt" role="status"></div><div class="dact"><button class="pri" type="submit" id="plGo">Odeslat nezávaznou žádost</button><button class="btn btn-ghost" type="button" data-app="mclose">Zrušit</button></div></form>')}
async function sendPlanRequest(want,note){var r=await getSb().from('plan_requests').insert({company_id:APP.cid,current_plan:effPlan(),requested_plan:want,note:note||null});if(r.error)throw r.error}
function isInc(k){return /inc|přij|prij|^in$|revenue|výnos/i.test(String(k))}
function KL(k){return k==='income'?'Příjem':(k==='expense'?'Výdaj':(isInc(k)?'Příjem ('+k+')':'Výdaj ('+k+')'))}
function openForm(ent,id,pre){var lm=!id&&limitMsg(ent);if(lm){toast(lm,'err');return}
 var def=entDef(ent),row=id?(APP.d[ent].rows.filter(function(r){return String(r.id)===id})[0]||{}):(pre||{}),F=def.f();if(ent==='jobs'&&id)row=Object.assign({},row,{status:stLab(row)});
 if(!id&&!pre&&ent==='jobs'){var PP=prof();row={description:PP.tpl||'',status:(PP.statuses||[])[0]||''}}
 var h='<h3>'+(id?'Upravit':'Nový')+' – '+def.n+'</h3><form id="entForm" data-ent="'+ent+'" data-id="'+esc(id||'')+'"><div class="fg">';
 F.forEach(function(f){var v=row[f.k],lab='<label for="e_'+f.k+'">'+f.l+(f.req?' <i>*</i>':'')+'</label>',c='';
  if(f.t==='cust')c='<select id="e_'+f.k+'">'+'<option value="">– bez zákazníka –</option>'+APP.d.customers.rows.map(function(x){return '<option value="'+esc(x.id)+'"'+(x.id===v?' selected':'')+'>'+esc(custName(x))+'</option>'}).join('')+'</select>';
  else if(f.t==='loc')c='<select id="e_'+f.k+'"><option value="">– bez pobočky –</option>'+APP.d.locations.rows.filter(function(x){return x.active!==false||x.id===v}).map(function(x){return '<option value="'+esc(x.id)+'"'+(x.id===v?' selected':'')+'>'+esc(x.name)+'</option>'}).join('')+'</select>';
  else if(f.t==='sel')c='<select id="e_'+f.k+'">'+f.opts.map(function(o){return '<option value="'+esc(o[0])+'"'+(o[0]===v?' selected':'')+'>'+esc(o[1])+'</option>'}).join('')+'</select>';
  else if(f.t==='textarea')c='<textarea id="e_'+f.k+'" rows="3">'+esc(v||'')+'</textarea>';
  else if(f.t==='bool'){h+='<div class="f full"><label class="chk"><input type="checkbox" id="e_'+f.k+'"'+((v==null&&f.def)||v?' checked':'')+'><span>'+f.l+'</span></label></div>';return}
  else{var val=v==null?'':v;if(f.t==='date')val=v?locD(v):'';if(f.t==='dateonly')val=v||'';if(f.t==='datetime-local')val=v?loc(v):'';c='<input id="e_'+f.k+'" type="'+(f.t==='dateonly'?'date':(f.t||'text'))+'" value="'+esc(val)+'"'+(f.t==='number'?' step="any"':'')+(f.list?' list="dl_'+f.k+'"':'')+'>'+(f.list?'<datalist id="dl_'+f.k+'">'+f.list.map(function(s){return '<option value="'+esc(s)+'">'}).join('')+'</datalist>':'')}
  h+='<div class="f'+(f.t==='textarea'?' full':'')+'">'+lab+c+'</div>'});
 h+='</div><div class="st" id="entSt" role="status"></div><div class="dact"><button class="btn btn-main" type="submit">Uložit</button>'+(id?'<button class="btn btn-ghost" type="button" data-del="1">Smazat</button>':'')+'<button class="btn btn-ghost" type="button" data-app="mclose">Zrušit</button></div></form>';
 var m=A('appModal');if(!m){m=document.createElement('div');m.id='appModal';m.className='amodal';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');A('vxapp').appendChild(m)}
 m.innerHTML='<div class="mbox">'+h+'</div>';m.classList.add('on');crmAfterForm(ent,id);var fi=m.querySelector('input,select,textarea');if(fi)fi.focus()}
function closeModal(){var m=A('appModal');if(m)m.remove()}
function entMsg(t){var e=A('entSt');if(e){e.className='st err';e.textContent=t}}
async function saveEnt(form){
 var ent=form.dataset.ent,id=form.dataset.id,F=entDef(ent).f(),row={};
 for(var i=0;i<F.length;i++){var f=F[i],el=A('e_'+f.k);if(!el)continue;var v=f.t==='bool'?el.checked:el.value.trim();
  if(f.req&&!v){entMsg('Vyplňte pole: '+f.l+'.');return}
  if(f.t==='bool')row[f.k]=v;
  else if(f.t==='number')row[f.k]=v===''?null:Number(v);
  else if(f.t==='dateonly')row[f.k]=v||null;
  else if(f.t==='date')row[f.k]=v?new Date(v+'T12:00:00').toISOString():null;
  else if(f.t==='datetime-local')row[f.k]=v?new Date(v).toISOString():null;
  else if(f.t==='cust'||f.t==='loc')row[f.k]=v||null;
  else row[f.k]=v===''?(id?null:undefined):v;
  if(row[f.k]===undefined)delete row[f.k]}
 if(ent==='customers'){var ce=crmCustCheck(row,id);if(ce){entMsg(ce);return}}
 if(ent==='deals'&&crm2On('deal')&&id&&row.stage!=='lost'&&row.lost_reason===null)delete row.lost_reason;
 if(ent==='deals'){if(row.value==null)row.value=0;if(row.probability==null){var ds=CRMST.filter(function(s){return s[0]===row.stage})[0];row.probability=ds?ds[2]:10}row.probability=Math.max(0,Math.min(100,Math.round(row.probability)));if(row.value<0){entMsg('Hodnota nesmí být záporná.');return};row.updated_at=new Date().toISOString()}
 if((ent==='reservations'||ent==='shifts')&&new Date(row.ends_at)<=new Date(row.starts_at)){entMsg('Konec musí být po začátku.');return}
 if(ent==='jobs'&&row.status!==undefined){var lb=row.status;row.status=stCanon(lb);row.stage=STC[lb]?null:(lb||null)}
 if(ent==='products'){if(!row.unit)row.unit='ks';if(row.min_qty==null||isNaN(row.min_qty)||row.min_qty<0)row.min_qty=0}
 if(ent==='booking_services'&&!(row.duration_min>=5&&row.duration_min<=600)){entMsg('Délka služby musí být 5 až 600 minut.');return}
 var b=form.querySelector('button[type=submit]');b.disabled=true;var q=getSb().from(ent),r;
 if(id)r=await q.update(row).eq('id',id).eq('company_id',APP.cid);else{row.company_id=APP.cid;r=await q.insert(row)}
 b.disabled=false;if(r.error){entMsg('Nepodařilo se uložit: '+r.error.message);return}
 closeModal();await refresh();appTab(APP.tab);toast('Uloženo.','ok')}
async function delEnt(form){
 if(!confirm('Opravdu smazat tento záznam? Akci nelze vrátit.'))return;
 var r=await getSb().from(form.dataset.ent).delete().eq('id',form.dataset.id).eq('company_id',APP.cid);
 if(r.error){entMsg('Nepodařilo se smazat: '+r.error.message);return}
 closeModal();await refresh();appTab(APP.tab);toast('Smazáno.','ok')}
function themeToggle(){var r=document.documentElement,n=r.getAttribute('data-theme')==='light'?'dark':'light';r.setAttribute('data-theme',n);try{localStorage.setItem('vx-theme',n)}catch(e){}}
async function askAI(msgs,out){
 var ses=(await getSb().auth.getSession()).data.session;if(!ses){out('Přihlášení vypršelo. Přihlaste se znovu.');return null}
 try{var r=await dfetch('/api/advisor',{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+ses.access_token},body:JSON.stringify({cid:APP.cid,messages:msgs,summary:summary()})});
  if(r.status===403){out('AI CEO je součástí tarifu Vexaronet PRO a vyšších.');return null}
  if(r.status===429){out('Příliš mnoho dotazů. Zkuste to za chvíli.');return null}
  if(!r.ok)throw new Error(r.status);var d=await r.json();if(!d.reply)throw new Error('e');return d.reply}catch(e){out('AI poradce teď není dostupný. Zkuste to později.');return null}}
document.addEventListener('click',async function(e){
 if(shopClick(e))return;
 var shx=e.target.closest('#vxapp [data-shop]');if(shx){var sk=shx.dataset.shop;if(sk==='open')shopOpen(String(shopCfg().slug),true);else if(sk==='copy'){var u=shopUrl(shopCfg().slug);try{navigator.clipboard.writeText(u);toast('Odkaz zkopírován.','ok')}catch(x){toast(u)}}else if(sk==='prof')profForm();else if(sk.indexOf('ord:')===0)shopOrderModal(sk.slice(4));else shopOrderAct(sk);return}
 if(e.target.closest('[data-demo]')){e.preventDefault();var mn2=A('mnav');if(mn2&&mn2.classList.contains('on'))menu(false);startDemo();return}
 if(e.target.closest('[data-demo-signup]')){closeApp();showAuth('signup');return}
 var dt=e.target.closest('.demot');if(dt){var db=dt.closest('.demobar'),op=db.classList.toggle('open');dt.setAttribute('aria-expanded',String(op));return}
 if(e.target.closest('#openApp')){openApp();return}
 var a=e.target.closest('#vxapp [data-app]');
 if(a){var k=a.dataset.app;
  if(k==='close')closeApp();
  else if(k==='side')A('vxapp').classList.toggle('side');
  else if(k==='bell')A('appBell').classList.toggle('on');
  else if(k==='quick'){var q=A('qPop');if(q)q.classList.toggle('on')}
  else if(k==='theme')themeToggle();
  else if(k==='mclose')closeModal();
  else if(k==='plan'){if(document.documentElement.classList.contains('appmode'))toast('Tarif a předplatné se spravují na webu vexaronet.com.');else planModal()}
  else if(k==='digmodal')digModal();
  else if(k==='fb')fbModal();
  else if(k==='lbak')localBackup();
  else if(k==='lres'){var lf=A('lresf');if(lf)lf.click()}
  else if(k==='stepsoff'){try{localStorage.setItem('vxsteps_'+(APP.cid||'x'),'1')}catch(e){}appTab(APP.tab)}
  else if(k==='digsave')digSave();
  else if(k==='digtest')digTest();
  else if(k==='hidebeta'){APP.betaHidden=true;appTab(APP.tab)}
  else if(k==='logout'){if(DEMO){closeApp();return}var c=getSb();if(c)await c.auth.signOut();closeApp()}
  return}
 var dd=e.target.closest('#vxapp [data-do]');
 if(dd){var w=dd.dataset.do;if(w==='repai'){closeModal();appTab('ceo');setTimeout(function(){ceoAsk('Napiš krátké slovní shrnutí uplynulého týdne mé firmy a 3 priority na další týden. Fakta: '+weekFacts().join('; '))},50);return}if(w==='copy'){var tx=A('remTx'),okc=false;try{await navigator.clipboard.writeText(tx.value);okc=true}catch(x){try{tx.focus();tx.select();tx.setSelectionRange(0,tx.value.length);okc=document.execCommand('copy')}catch(y){okc=false}}if(okc){var ol=dd.textContent;dd.textContent='Zkopírováno ✓';setTimeout(function(){dd.textContent=ol},2200);toast('Zkopírováno do schránky.','ok')}else{tx.focus();tx.select();toast('Text je označený, zkopírujte ho pomocí Ctrl+C (na telefonu podržte a zvolte Kopírovat).')}}
  else if(w==='remtasks')mkTasks(overInv().map(function(f){return 'Urgovat fakturu '+(f.number||'')+(invName(f)?' ('+invName(f)+')':'')}));
  else if(w==='jobtasks')mkTasks(overJobs().map(function(j){return 'Kontaktovat zákazníka: '+j.title}));return}
 var ac=e.target.closest('#vxapp [data-act]');if(ac){doAct(ac.dataset.act);return}
 var qq=e.target.closest('#vxapp [data-q]');if(qq){ceoAsk(ceoQs()[+qq.dataset.q][1]);return}
 if(e.target.closest('#vxapp [data-newinv]')){invEditor();return}
 if(e.target.closest('#vxapp [data-invprof]')){profForm();return}
 if(e.target.closest('#vxapp [data-addrow]')){A('iRows').insertAdjacentHTML('beforeend',itemRow());return}
 var dr=e.target.closest('#vxapp [data-delrow]');if(dr){if(document.querySelectorAll('#iRows .irow').length>1){dr.closest('.irow').remove();invTotals()}return}
 var cn=e.target.closest('#vxapp [data-calnav]');if(cn){var v=+cn.dataset.calnav,M0=APP.calM||new Date();APP.calM=v===0?new Date(new Date().getFullYear(),new Date().getMonth(),1):new Date(M0.getFullYear(),M0.getMonth()+v,1);if(v===0)APP.calSel=locD(new Date());calRe();return}
 var cdy=e.target.closest('#vxapp [data-calday]');if(cdy){APP.calSel=cdy.dataset.calday;calRe();return}
 var cmd=e.target.closest('#vxapp [data-calmode]');if(cmd){APP.calMode=cmd.dataset.calmode;calRe();return}
 if(e.target.closest('#vxapp [data-bkcopy]')){var bp=APP.d.booking_profiles.rows[0];if(bp&&navigator.clipboard)navigator.clipboard.writeText(bookUrl(bp.slug)).then(function(){toast('Odkaz zkopírován.','ok')},function(){toast('Zkopírujte odkaz ručně.','err')});return}
 if(e.target.closest('#vxapp [data-bkopen]')){var bp2=APP.d.booking_profiles.rows[0];if(!bp2)return;if(DEMO)bookOpen(bp2.slug,true);else window.open(bookUrl(bp2.slug),'_blank','noopener');return}
 var iv=e.target.closest('#vxapp [data-invview]');if(iv){invView(iv.dataset.invview);return}
 if(e.target.closest('#vxapp [data-invprint]')){invPrint();return}
 var pay=e.target.closest('#vxapp [data-pay]');if(pay){if(!confirm('Označit fakturu jako zaplacenou dnes? Změna se promítne do účetních údajů.'))return;var pr=await rpcInv('paid',{id:pay.dataset.pay,payment_date:locD(new Date())});if(pr.error){toast('Nepodařilo se uložit: '+pr.error.message,'err');return}await refresh();appTab('faktury');toast('Faktura označena jako zaplacená.','ok');return}
 var ux=e.target.closest('#vxapp button[data-au]');if(ux){var uk=ux.dataset.au;if(uk==='all')auCreate(auItems());else if(uk.indexOf('one:')===0){var ui=auItems()[+uk.slice(4)];if(ui)auCreate([ui])}return}
 var cx=e.target.closest('#vxapp [data-cs]');if(cx){var ck=cx.dataset.cs;if(ck==='imp')ciModal();else if(ck==='read')ciRead();else if(ck==='go')ciGo();else if(ck.indexOf('exp:')===0)csExport(ck.slice(4));return}
 var rx=e.target.closest('#vxapp [data-rp]');if(rx){var rk=rx.dataset.rp;if(rk==='csv')rpCsv();else if(rk==='print')rpPrint();else if(rk==='ai')rpAI();return}
 var mx=e.target.closest('#vxapp [data-mk]');if(mx){var mk=mx.dataset.mk;if(mk==='gen')mkGen();else if(mk==='save')mkSave();else if(mk==='copy'){var mo=A('mk_out');try{navigator.clipboard.writeText(mo.value);toast('Text zkopírován.','ok')}catch(x){mo.select();toast('Označeno, zkopírujte ručně (Ctrl+C).','ok')}}return}
 var wx=e.target.closest('#vxapp [data-web]');if(wx){var wk=wx.dataset.web;if(wk==='ai')webAI();else if(wk==='open')webOpen('',true);else if(wk==='copy'){var wr=APP.d.sites.rows[0];if(wr){try{navigator.clipboard.writeText(webUrl(wr.slug));toast('Odkaz zkopírován.','ok')}catch(x){toast(webUrl(wr.slug),'ok')}}}return}
 var ex0=e.target.closest('#vxapp [data-ei]');if(ex0){var ek=ex0.dataset.ei;if(ek==='load')eiLoad();else if(ek==='run')eiRun();else if(ek==='clear'){APP.ei=null;A('eiRes').innerHTML='';eiSt('','')}return}
 var ax=e.target.closest('#vxapp [data-acc]');if(ax){var ak=ax.dataset.acc;if(ak==='process')accProcess();else if(ak==='discard'){A('accRes').innerHTML='';accSt('','')}else if(ak==='csv-ent')accExport('ent');else if(ak==='csv-inv')accExport('inv');else if(ak==='bk-file')bkFile();else if(ak==='bk-demo')bkDemo();else if(ak==='bk-apply')bkApply();else if(ak==='bk-clear'){BK.rows=[];A('bkRes').innerHTML='';bkSt('','')}return}
 var ck=e.target.closest('#vxapp [data-clock]');if(ck){if(ck.disabled)return;ck.disabled=true;await clockDo(ck.dataset.clock,ck.dataset.uid);return}
 if(e.target.closest('#vxapp [data-invnew]')){inviteModal();return}
 var is=e.target.closest('#vxapp [data-invshow]');if(is){var iv=(APP.invs||[]).filter(function(x){return x.id===is.dataset.invshow})[0];if(iv)inviteDone(iv.email);return}
 var ic=e.target.closest('#vxapp [data-invcancel]');if(ic){if(!confirm('Zrušit tuto pozvánku?'))return;var cr=await getSb().rpc('cancel_invite',{invite_id:ic.dataset.invcancel});if(cr.error){toast('Nepodařilo se zrušit: '+teamErr(cr.error.message),'err');return}toast('Pozvánka zrušena.','ok');loadTeam();return}
 var rm=e.target.closest('#vxapp [data-rmm]');if(rm){if(!confirm('Odebrat tohoto člena z firmy? Ztratí přístup k datům firmy.'))return;var rr2=await getSb().rpc('remove_member',{cid:APP.cid,member_id:rm.dataset.rmm});if(rr2.error){toast('Nepodařilo se odebrat: '+teamErr(rr2.error.message),'err');return}toast('Člen odebrán.','ok');loadTeam();return}
 var so=e.target.closest('#vxapp [data-soon]');if(so){toast(so.dataset.soon);return}
 var pq=A('qPop');if(pq&&pq.classList.contains('on')&&!e.target.closest('.qw'))pq.classList.remove('on');
 if(A('appBell')&&A('appBell').classList.contains('on')&&!e.target.closest('.bellw'))A('appBell').classList.remove('on');
 var t=e.target.closest('#vxapp [data-tab]');if(t){appTab(t.dataset.tab);return}
 var sx=e.target.closest('#vxapp [data-sk]');if(sx){var sv=sx.dataset.sk;if(sv.indexOf('move:')===0)skMove(sv.slice(5));return}
 var sv0=e.target.closest('#vxapp [data-svc]');if(sv0){var sn=sv0.dataset.svc,ssv=(prof().svc||[]).filter(function(x){return x[0]===sn})[0];openForm('booking_services',null,{name:sn,duration_min:ssv?ssv[1]:30});return}
 var nw=e.target.closest('#vxapp [data-new]');if(nw){if(pq)pq.classList.remove('on');openForm(nw.dataset.new);return}
 var ed=e.target.closest('#vxapp [data-edit]');if(ed&&!e.target.closest('input')){var p=ed.dataset.edit.split(':');openForm(p[0],p.slice(1).join(':'));return}
 if(e.target.closest('#vxapp [data-del]')){delEnt(A('entForm'));return}
 if(e.target.classList&&e.target.classList.contains('amodal'))closeModal()});
document.addEventListener('change',async function(e){
 var t=e.target;if(t.id==='demoOb'){APP.ind=t.value;renderNav();try{localStorage.removeItem('vxsteps_'+(APP.cid||'x'))}catch(x){}appTab('prehled');return}if(t.dataset&&t.dataset.rate){var uid=t.dataset.rate,raw=String(t.value).replace(',','.').trim(),val=parseFloat(raw);if(raw===''||isNaN(val)||val<0){toast('Zadejte sazbu v Kč za hodinu (0 nebo více).','err');return}var rr=await getSb().from('member_rates').upsert({company_id:APP.cid,user_id:uid,hourly_rate:val,updated_at:new Date().toISOString()},{onConflict:DEMO?'user_id':'company_id,user_id'});if(rr.error){toast('Sazbu se nepodařilo uložit: '+rr.error.message,'err');return}APP.d.rates=await qt('member_rates');toast('Sazba uložena.','ok');var bx=A('attBox');if(bx)bx.innerHTML=attHtml();return}if(t.dataset&&t.dataset.au&&t.dataset.au.indexOf('rule:')===0){await auToggle(t.dataset.au.slice(5),t.checked);return}if(t.id==='rpP'){APP.rpP=t.value;appTab('reporty');return}if(t.dataset&&t.dataset.bkrow!=null&&BK.rows[+t.dataset.bkrow]){BK.rows[+t.dataset.bkrow].on=t.checked;return}if(t.dataset&&t.dataset.task){var r=await getSb().from('tasks').update({completed:t.checked}).eq('id',t.dataset.task).eq('company_id',APP.cid);if(r.error){toast('Nepodařilo se uložit: '+r.error.message,'err');t.checked=!t.checked}else{await refresh();appTab('ukoly')}}});
document.addEventListener('change',function(e){var t=e.target;if(t&&t.name==='so_d'&&A('vxsite')&&A('vxsite').contains(t)){SH.form={n:A('so_n').value,e:A('so_e').value,t:A('so_t').value,a:A('so_a').value,p:A('so_p').value};SH.delivery=t.value;shopHtml();var rr=document.querySelector('#shopOrd input[name=so_d]:checked');if(rr)rr.focus()}});
document.addEventListener('input',function(e){if(e.target.closest&&e.target.closest('#webForm'))webPrev();if(e.target.closest&&e.target.closest('#iRows'))invTotals();if(e.target.classList&&e.target.classList.contains('srch')){var v=e.target.value.toLowerCase();[].forEach.call(document.querySelectorAll('#lst li'),function(li){li.style.display=li.textContent.toLowerCase().indexOf(v)<0?'none':''})}});
document.addEventListener('submit',async function(e){
 var f=e.target;
 if(f.id==='shopForm'){e.preventDefault();shopSave(f);return}
 if(f.id==='shopOrd'){e.preventDefault();shopSubmit(f);return}
 if(f.id==='entForm'){e.preventDefault();saveEnt(f);return}
 if(f.id==='bookForm'){e.preventDefault();saveBook(f);return}
 if(f.id==='obForm'){e.preventDefault();var ov=A('obSel').value,ro=await getSb().auth.updateUser({data:{ui_industry:ov}});if(ro.error){toast('Nepodařilo se uložit: '+ro.error.message,'err');return}APP.meta=(ro.data&&ro.data.user&&ro.data.user.user_metadata)||Object.assign({},APP.meta,{ui_industry:ov});APP.ind=ov;renderNav();toast('Aplikace je nastavená pro obor: '+ov,'ok');appTab(APP.tab);return}
 if(f.id==='onbForm'||f.id==='featForm'){e.preventDefault();var ft=[].map.call(f.querySelectorAll('input[name=ft]:checked'),function(x){return x.value}),co=(A('oC')||A('pC')).value;
  var r=await getSb().auth.updateUser({data:{country:co,features:ft,onboarded:true}});if(r.error){toast('Nepodařilo se uložit: '+r.error.message,'err');return}
  APP.meta=r.data.user.user_metadata||{};toast('Nastavení uloženo.','ok');appTab(APP.tab);return}
 if(f.id==='fbForm'){e.preventDefault();var fk=A('fbK').value,fm=A('fbM').value.trim(),st=A('fbSt'),fb=f.querySelector('button[type=submit]');if(fm.length<10){st.className='st err';st.textContent='Napište prosím alespoň 10 znaků.';return}fb.disabled=true;var em=APP.user&&APP.user.email||'',pg=(APP.tab||'')+'',fr=await getSb().from('feedback').insert({company_id:APP.cid,user_id:APP.user&&APP.user.id,email:em,category:({problem:'problem',napad:'suggestion',jine:'experience'})[fk]||'problem',rating:+A('fbR').value||5,message:fm,page:pg,user_agent:(navigator.userAgent||'').slice(0,300)});fb.disabled=false;if(fr.error){var mt='mailto:info@vexaronet.com?subject='+encodeURIComponent('Vexaronet: zpětná vazba')+'&body='+encodeURIComponent(fm+'\n\n---\nStránka: '+pg+'\nE-mail: '+em);st.className='st err';st.innerHTML='Zprávu se nepodařilo uložit. Můžete nám ji poslat e-mailem: <a href="'+mt+'">info@vexaronet.com</a>.';return}closeModal();toast('Děkujeme, zpráva odeslána.','ok');return}
 if(f.id==='invForm'){e.preventDefault();var its=[].map.call(f.querySelectorAll('#iRows .irow'),function(r){return {description:r.querySelector('.id').value.trim(),quantity:parseFloat(r.querySelector('.iq').value)||0,unit:r.querySelector('.iu').value.trim()||'ks',unit_gross:parseFloat(r.querySelector('.ip').value),vat_rate:parseFloat(r.querySelector('.iv').value)}}).filter(function(i){return i.description&&i.quantity>0&&!isNaN(i.unit_gross)});
  if(!its.length){entMsg('Přidejte alespoň jednu položku s popisem, množstvím a cenou.');return}
  var cu=APP.d.customers.rows.filter(function(x){return x.id===A('iC').value})[0]||{};
  if(!confirm('Vystavit fakturu? Přidělí se číslo faktury a vystavenou fakturu už nelze vzít zpět.'))return;
  var doc={customer:{id:cu.id,name:cu.name,email:cu.email||null,ico:cu.ico||null,dic:cu.dic||null,billing_address:cu.billing_address||null,address_text:cu.billing_address||null,country_code:cu.country_code||null},items:its,issued_on:A('iI').value,taxable_supply_on:A('iT').value,due_on:A('iD').value,currency:A('iCur').value,language:'cs'};if(A('iJ').value)doc.job_id=A('iJ').value;
  var b=f.querySelector('button[type=submit]');b.disabled=true;var jobId=A('iJ').value,r;
  try{
   if(!jobId){var tt=its.reduce(function(a,i){return a+i.quantity*i.unit_gross},0),jr=await getSb().from('jobs').insert({company_id:APP.cid,customer_id:cu.id,title:'Faktura: '+its[0].description.slice(0,80),price:Math.round(tt*100)/100,status:'done',stage:'Hotovo'}).select('id');
    if(jr.error)throw jr.error;jobId=jr.data&&jr.data[0]&&jr.data[0].id;if(!jobId)throw new Error('Nepodařilo se připravit fakturu.')}
   var sr=await rpcInv('start',{job_id:jobId});if(sr.error)throw sr.error;
   var dr=sr.data||{};if(!dr.id)throw new Error('Nepodařilo se založit fakturu.');doc.id=dr.id;doc.job_id=jobId;
   r=await rpcInv('issue',doc)}catch(ex){r={error:ex}}
  b.disabled=false;
  if(r.error&&/fakturační údaje/i.test(r.error.message||'')){toast('Nejdřív vyplňte fakturační údaje dodavatele (vaše firma) a pak fakturu vystavte znovu.','err');profForm();return}
  if(r.error){entMsg('Fakturu se nepodařilo vystavit: '+r.error.message+'. Zkontrolujte, že máte v části Faktury vyplněné Fakturační údaje (dodavatel) a vybraného zákazníka. Pokud to nepomůže, použijte tlačítko Něco nefunguje? v menu a popište, co se stalo.');return}
  closeModal();await refresh();appTab('faktury');toast('Faktura vystavena'+(r.data&&r.data.number?' (č. '+r.data.number+')':'')+'.','ok');return}
 if(f.id==='profForm'){e.preventDefault();if(!A('p_legal_name').value.trim()){entMsg('Vyplňte obchodní jméno.');return}
  var d={};['legal_name','ico','dic','address_text','bank_account','iban','email','country_code','default_currency','registration_text'].forEach(function(k){var v=A('p_'+k).value.trim();if(v)d[k]=v});
  var dd=A('p_default_due_days').value;if(dd)d.default_due_days=Number(dd);d.vat_payer=A('p_vat_payer').checked;
  var r2=await rpcInv('profile',d);if(r2.error){entMsg('Nepodařilo se uložit: '+r2.error.message);return}closeModal();try{await refresh()}catch(x){}toast('Fakturační údaje uloženy.','ok');if(APP.tab==='faktury')appTab('faktury');return}
 if(f.id==='skForm'){e.preventDefault();await skSave(f);return}
 if(f.id==='webForm'){e.preventDefault();await saveWeb(f);return}
 if(f.id==='accForm'){e.preventDefault();var ai=A('accIn'),aq=ai.value.trim();if(!aq)return;ai.value='';accAsk(aq);return}
 if(f.id==='accRF'){e.preventDefault();var am=parseFloat(A('af_amt').value),ad=A('af_date').value,ak2=A('af_kind').value,at=A('af_title').value.trim();
  if(!(am>=0)||!ad||!at){accSt('Vyplňte částku, datum a popis.','err');return}
  var dp=APP.d.fe.rows.some(function(x){return Math.abs(Math.abs(Number(x.amount)||0)-am)<0.005&&String(x.entry_date||'').slice(0,10)===ad&&x.kind===ak2});
  if(dp&&!confirm('V evidenci už je záznam se stejnou částkou, datem a druhem. Přesto uložit?'))return;
  var sb=f.querySelector('button[type=submit]');sb.disabled=true;var ir2=await getSb().from('financial_entries').insert({company_id:APP.cid,title:at,amount:am,kind:ak2,entry_date:ad});sb.disabled=false;
  if(ir2.error){accSt('Nepodařilo se uložit: '+ir2.error.message,'err');return}
  await refresh();appTab('ucetni');toast('Doklad uložen do evidence.','ok');return}
 if(f.id==='inviteForm'){e.preventDefault();var em=A('ivE').value.trim().toLowerCase();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)){entMsg('Zadejte platný e-mail.');return}var TY={'gamil.com':'gmail.com','gmial.com':'gmail.com','gmai.com':'gmail.com','gmail.cz':'gmail.com','gmaill.com':'gmail.com','gnail.com':'gmail.com','seznan.cz':'seznam.cz','sezman.cz':'seznam.cz','seznam.com':'seznam.cz','email.com':'email.cz','outlok.com':'outlook.com','hotmial.com':'hotmail.com'},dm=em.split('@')[1];if(TY[dm]&&A('ivE').dataset.ok!==em){entMsg('Nemyslíte '+em.split('@')[0]+'@'+TY[dm]+'? Adresa vypadá jako překlep. Opravte ji, nebo odešlete znovu, pokud je správně.');A('ivE').dataset.ok=em;return}
  var ib=f.querySelector('button[type=submit]');ib.disabled=true;var ses=(await getSb().auth.getSession()).data.session,ir=null,ij=null;try{ir=await dfetch('/api/invite',{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+(ses?ses.access_token:'')},body:JSON.stringify({cid:APP.cid,email:em,role:A('ivR').value})});ij=await ir.json().catch(function(){return null})}catch(x){}ib.disabled=false;
  if(!ir||!ir.ok){entMsg(ij&&ij.message?teamErr(ij.message):(ir&&ir.status===429?'Příliš mnoho pozvánek za krátkou dobu, zkuste to později.':'Pozvánku se nepodařilo vytvořit. Zkuste to znovu.'));return}
  await loadTeam();if(DEMO){closeModal();toast('Ukázka: pozvánka je jen vyzkoušená, e-mail se neodesílá.','ok')}else if(ij&&ij.mail==='sent'){closeModal();toast('Pozvánka odeslána na '+em+'.','ok')}else inviteDone(em,true);return}
 if(f.id==='planForm'){e.preventDefault();var sel=f.querySelector('input[name=pl]:checked');if(!sel){entMsg('Vyberte tarif.');return}var want=sel.value,note=A('plN').value.trim(),bt=f.querySelector('button[type=submit]');bt.disabled=true;
  try{
   if(want==='start'){if(!confirm('Přejít na tarif START? AI CEO a rozšířené funkce se vypnou, data zůstanou zachována.')){bt.disabled=false;return}
    var u=await getSb().from('subscriptions').update({plan:'start'}).eq('company_id',APP.cid).select();
    if(!u.error&&u.data&&u.data.length){var rs=await getSb().from('subscriptions').select('*').eq('company_id',APP.cid).limit(1);APP.sub=rs.data&&rs.data[0]||APP.sub;closeModal();subCard();appTab('profil');toast('Přešli jste na tarif START.','ok');return}}
   await sendPlanRequest(want,note);closeModal();toast('Nezávazná žádost o tarif odeslána. Nic se neúčtuje. Ozveme se vám e-mailem.','ok')
  }catch(x){entMsg('Žádost se nepodařilo odeslat ('+((x&&(x.code||x.message))||'chyba')+'). Napište nám na info@vexaronet.com.')}bt.disabled=false;return}
 if(f.id==='goalForm'){e.preventDefault();var gv=Math.round(Number(A('goalIn').value));if(!(gv>=0)||gv>1e9){toast('Zadejte platné číslo.','err');return}try{localStorage.setItem('vxgoal_'+APP.cid,String(gv))}catch(x){}APP.meta.goal_kc=gv;if(!DEMO){try{var gr=await getSb().auth.updateUser({data:{goal_kc:gv}});if(gr&&gr.error)toast('Cíl je uložen jen v tomto prohlížeči.')}catch(x){}}toast('Cíl uložen.','ok');appTab('ceo');return}
 if(f.id==='ceoForm'){e.preventDefault();var inp=A('ceoIn'),q=inp.value.trim();if(!q)return;inp.value='';ceoAsk(q);return}
 if(f.id==='gsForm'){e.preventDefault();var gi=A('gsIn'),g=gi.value.trim();if(!g)return;gi.value='';if(!A('ceoLog'))appTab('ceo');ceoAsk(g)}});
document.addEventListener('keydown',function(e){
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'&&A('gsIn')){e.preventDefault();A('gsIn').focus();return}
 if(e.key==='Escape'){if(A('appModal'))closeModal();else if(A('vxapp')&&!dlg.open)closeApp()}});


/* chat */
var fab=$('#chatFab'),chat=$('#chat'),body=$('#chatBody'),sugg=$('#chatSugg'),cf=$('#chatForm'),cin=$('#chatIn');
var hist=[];try{hist=JSON.parse(sessionStorage.getItem('vx-chat-v3')||'[]')}catch(e){}
function save(){try{sessionStorage.setItem('vx-chat-v3',JSON.stringify(hist.slice(-20)))}catch(e){}}
function add(t,c){var d=document.createElement('div');d.className='msg '+c;d.textContent=t;body.appendChild(d);body.scrollTop=body.scrollHeight;return d}
function openChat(o){chat.classList.toggle('on',o);fab.setAttribute('aria-expanded',o);if(o){if(!body.children.length){add('Dobrý den, jsem AI asistent Vexaronetu. Poradím, co platforma bude umět a v jaké je fázi. Na co se chcete zeptat?','bot');hist.forEach(function(m){add(m.content,m.role==='user'?'me':'bot')})}
 if(!sugg.children.length&&!hist.length)['Co Vexaronet umí?','Kolik to stojí?','Je už k dispozici?'].forEach(function(q){var b=document.createElement('button');b.type='button';b.textContent=q;b.onclick=function(){cin.value=q;cf.requestSubmit()};sugg.appendChild(b)});setTimeout(function(){cin.focus()},50)}}
fab.addEventListener('click',function(){openChat(!chat.classList.contains('on'))});$('#chatX').addEventListener('click',function(){openChat(false)});$('#openChat').addEventListener('click',function(){openChat(true)});
cin.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();cf.requestSubmit()}});
cf.addEventListener('submit',function(e){e.preventDefault();var t=cin.value.trim();if(!t)return;cin.value='';sugg.innerHTML='';add(t,'me');hist.push({role:'user',content:t});save();var w=add('Píšu odpověď…','bot');
 fetch('/api/chat',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({messages:hist.slice(-12)})}).then(function(r){if(!r.ok)throw new Error(r.status);return r.json()}).then(function(d){if(!d.reply)throw new Error('e');w.textContent=d.reply;hist.push({role:'assistant',content:d.reply});save();body.scrollTop=body.scrollHeight}).catch(function(){w.className='msg bot err';w.textContent='AI asistent zatím není dostupný nebo se nepodařilo spojit. Napište nám prosím na info@vexaronet.com.';hist.pop();save()})});
@@FAKT@@
@@CRM@@
@@CRM2@@
@@CONSENT@@
@@PROFIL@@
@@AUTOPILOT@@
@@APDASH@@
})();
</script>
</body>
</html>'''


# Fonty hostované lokálně (SIL OFL 1.1, assets/fonts/OFL-*.txt). Zdroj: npm @fontsource-variable/manrope a /sora 5.3.0.
FONT_CSS = ''.join("@font-face{font-family:'%s';font-style:normal;font-display:swap;font-weight:%s;src:url(/assets/fonts/%s-%s-wght-normal.woff2) format('woff2-variations'),url(/assets/fonts/%s-%s-wght-normal.woff2) format('woff2');unicode-range:%s}" % (fam, wt, fid, sub, fid, sub, rng)
  for fam, fid, wt in (('Manrope', 'manrope', '200 800'), ('Sora', 'sora', '100 800'))
  for sub, rng in (('latin-ext', 'U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF'),
                   ('latin', 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD')))
out = (tpl.replace('@@CSS@@', FONT_CSS + css + extra_css).replace('@@KEYS@@', keys).replace('@@MODS@@', mods_html)
       .replace('@@BIZOPTS@@', biz_opts).replace('@@BIZ@@', biz_chips).replace('@@PLANS@@', plans_html).replace('@@STAGES@@', stages_html)
       .replace('@@MODDATA@@', json.dumps({m['id']: dict(name=m['name'], short=m['short'], items=m['items'], stage=m['stage'], state=m['state'], stlab=ST[m['state']], note=m['note']) for m in MODS}, ensure_ascii=False).replace('</', '<\\/'))
       .replace('@@BIZDATA@@', json.dumps(BIZ, ensure_ascii=False)))
out = out.replace('@@FAKT@@', open('src/qr.js',encoding='utf-8').read().replace('if(typeof module','if(0&&typeof module')+'\n'+open('src/inv.js',encoding='utf-8').read().replace('if(typeof module','if(0&&typeof module')+'\n'+open('src/faktury_ui.js',encoding='utf-8').read())
out = out.replace('@@EU@@', open('src/eu.js',encoding='utf-8').read().replace('if(typeof module','if(0&&typeof module'))
out = out.replace('@@CRM@@', open('src/crm_ui.js',encoding='utf-8').read())
_nm = lambda t: t.replace('if(typeof module', 'if(0&&typeof module')
out = out.replace('@@PROFIL@@', _nm(open('src/jsonschema_mini.js',encoding='utf-8').read()) + '\n' + _nm(open('src/profile_core.js',encoding='utf-8').read())
    + '\nvar VXPSCHEMA=' + json.dumps(json.load(open('src/onboarding_schema.json',encoding='utf-8')), ensure_ascii=False, separators=(',', ':')) + ';\n'
    + open('src/profile_ui.js',encoding='utf-8').read())
out = out.replace('@@AUTOPILOT@@', _nm(open('src/autopilot_core.js',encoding='utf-8').read()) + '\n' + open('src/autopilot_ui.js',encoding='utf-8').read())
out = out.replace('@@CONSENT@@', open('src/consent.js',encoding='utf-8').read() + '\n' + open('src/dsa_ui.js',encoding='utf-8').read() + '\n' + open('src/registrace_ui.js',encoding='utf-8').read())
out = out.replace('@@APDASH@@', open('src/autopilot_dash.js',encoding='utf-8').read() + '\n' + open('src/ai_marketing_ui.js',encoding='utf-8').read() + '\n' + open('src/social_ui.js',encoding='utf-8').read() + '\n' + _nm(open('src/bank_csv.js',encoding='utf-8').read()) + '\n' + open('src/ai_team_ui.js',encoding='utf-8').read())
out = out.replace('@@CRM2@@', open('src/crm2_ui.js',encoding='utf-8').read())
out = (out.replace('@@CFG_SBURL@@', _json.dumps(CFG.get('supabase_url', 'https://VASE-PROJEKT.supabase.co')))
          .replace('@@CFG_SBKEY@@', _json.dumps(CFG.get('supabase_publishable_key', 'VAS_PUBLISHABLE_KLIC')))
          .replace('@@CFG_FEED@@', _json.dumps(CFG.get('update_feed', ''))).replace('@@CFG_ED@@', _json.dumps(CFG.get('edition', 'saas'))).replace('@@CFG_OFF@@', _json.dumps(CFG.get('modules_off', SRC_OFF if CFG.get('edition', 'saas') in ('source', 'local') else []))).replace('@@LAUNCH@@', _json.dumps(CFG.get('launch_date', ''))).replace('@@VERSION@@', _json.dumps(VERSION)))
assert '@@' not in out
open(D + 'index.html', 'w', encoding='utf-8').write(out)
open(D + 'version.json', 'w', encoding='utf-8').write(_json.dumps({'version': VERSION}))
# Hlavičky (CSP) podle konfigurace: adresa vlastní databáze a případně zdroj informací o aktualizacích
import re as _re
try:
    _h = open(D + '_headers', encoding='utf-8').read()
    _host = _re.sub(r'^https?://', '', CFG.get('supabase_url', 'https://VASE-PROJEKT.supabase.co')).rstrip('/')
    _h = _re.sub(r'https://[a-z0-9-]+\.supabase\.co', 'https://' + _host, _h)
    _h = _re.sub(r'wss://[a-z0-9-]+\.supabase\.co', 'wss://' + _host, _h)
    _feed = CFG.get('update_feed', '')
    _m = _re.match(r'(https://[^/]+)/', _feed + '/') if _feed else None
    if _m and _m.group(1) not in _h:
        _h = _h.replace('connect-src ', 'connect-src ' + _m.group(1) + ' ', 1)
    open(D + '_headers', 'w', encoding='utf-8').write(_h)
except FileNotFoundError:
    pass
print('OK', len(out))

# ===== Statické právní stránky (skutečné adresy /podminky/, /ochrana-udaju/, /cookies/) =====
import subprocess, os
_m = re.search(r"^var LEGAL=.*?;$", out, re.M)
assert _m, 'LEGAL nenalezeno'
_js = _m.group(0) + "\nconsole.log(JSON.stringify(LEGAL));"
LEG = json.loads(subprocess.run(['node', '-e', _js], capture_output=True, text=True, check=True).stdout)
LEG_T = {'podminky': ('Obchodní podmínky', 'Obchodní podmínky služby Vexaronet (návrh pro beta verzi).'),
         'ochrana-udaju': ('Ochrana osobních údajů', 'Zásady ochrany osobních údajů služby Vexaronet (návrh pro beta verzi).'),
         'licence': ('Licenční podmínky', 'Licenční podmínky aplikace Vexaronet pro počítač a zdrojového kódu.'),
         'cookies': ('Informace o cookies', 'Informace o cookies a úložišti prohlížeče na webu Vexaronet.'),
         'dsa': ('Kontaktní místa (DSA)', 'Kontaktní místa a hlášení nezákonného obsahu podle nařízení o digitálních službách.')}
LEG_CSS = ('*{box-sizing:border-box}html{-webkit-text-size-adjust:100%}body{margin:0;font:16px/1.65 system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;background:#070a1c;color:#e8ebff}'
  'a{color:#9db4ff}.w{max-width:760px;margin:0 auto;padding:20px 16px 56px}.top{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;padding:6px 0 18px;border-bottom:1px solid rgba(150,175,255,.2);margin-bottom:22px}'
  '.top a.lg{font-weight:800;letter-spacing:.04em;color:#fff;text-decoration:none}.btn{display:inline-block;padding:10px 16px;border-radius:12px;border:1px solid rgba(150,175,255,.4);color:#fff;text-decoration:none;min-height:44px;line-height:1.4}'
  'h1{font-size:1.9rem;line-height:1.2;margin:.3em 0 .4em}h3{margin:1.6em 0 .4em;font-size:1.1rem}.mut{color:#a9b0d6}.eyebrow{display:block;color:#9db4ff;font-size:.8rem;text-transform:uppercase;letter-spacing:.08em}'
  '.draft{padding:12px 14px;border-radius:12px;border:1px solid rgba(255,190,90,.55);background:rgba(255,190,90,.1);margin:14px 0}ul{padding-left:1.2em}li{margin:.4em 0}'
  'footer{margin-top:40px;padding-top:16px;border-top:1px solid rgba(150,175,255,.2);font-size:.92rem;display:flex;gap:16px;flex-wrap:wrap}'
  '@media(prefers-color-scheme:light){body{background:#f6f7fc;color:#14183a}a{color:#2b4bd6}.top a.lg,.btn{color:#14183a}.mut{color:#555b82}.eyebrow{color:#2b4bd6}.top,footer{border-color:#d9dcec}.btn{border-color:#b9c0e6}}')
for _k, _body in LEG.items():
    _t, _d = LEG_T[_k]
    _body = _body.replace('<h2 id="dT">', '<h1 id="dT">').replace('</h2>', '</h1>', 1)
    _nav = ''.join('<a href="/%s/">%s</a>' % (k2, LEG_T[k2][0]) for k2 in LEG_T if k2 != _k)
    _html = ('<!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
      '<title>%s – Vexaronet</title><meta name="description" content="%s"><link rel="canonical" href="https://vexaronet.com/%s/">'
      '<meta name="robots" content="index,follow"><meta name="theme-color" content="#070a1c"><style>%s</style></head><body><div class="w">'
      '<div class="top"><a class="lg" href="/">VEXARONET</a><a class="btn" href="/">Zpět na Vexaronet</a></div><main>%s</main>'
      '<footer><a href="/">Úvodní stránka</a>%s<a href="mailto:info@vexaronet.com">info@vexaronet.com</a></footer></div></body></html>') % (_t, _d, _k, LEG_CSS, _body, _nav)
    os.makedirs(D + _k, exist_ok=True)
    open(D + _k + '/index.html', 'w', encoding='utf-8').write(_html)
print('Právní stránky:', ', '.join(LEG))
# ===== Stránky /nahlasit/ (oznámení podle čl. 16 DSA) a /odhlasit/ (odhlášení z novinek) =====
FORM_CSS = LEG_CSS + ('label{display:block;font-weight:600;margin:14px 0 4px}input,select,textarea{width:100%;font:inherit;padding:10px 12px;border-radius:10px;border:1px solid rgba(150,175,255,.45);background:rgba(255,255,255,.04);color:inherit}'
  'textarea{min-height:110px}.chk{display:flex;gap:10px;align-items:flex-start;font-weight:400}.chk input{width:20px;height:20px;margin-top:3px}.hp{position:absolute;left:-9999px}'
  'button{font:inherit;cursor:pointer;padding:12px 18px;border-radius:12px;border:1px solid rgba(150,175,255,.6);background:#2b3aa8;color:#fff;font-weight:700;min-height:44px;margin-top:16px}'
  '.st{margin-top:14px;padding:12px 14px;border-radius:12px}.st.ok{border:1px solid rgba(80,200,140,.6);background:rgba(80,200,140,.12)}.st.err{border:1px solid rgba(255,110,130,.6);background:rgba(255,110,130,.1)}small{display:block;color:#a9b0d6}')
def _page(slug, title, desc, body, script):
    html = ('<!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
      '<title>%s – Vexaronet</title><meta name="description" content="%s"><meta name="robots" content="%s"><meta name="referrer" content="no-referrer">'
      '<meta name="theme-color" content="#070a1c"><style>%s</style></head><body><div class="w">'
      '<div class="top"><a class="lg" href="/">VEXARONET</a><a class="btn" href="/">Zpět na Vexaronet</a></div><main>%s</main>'
      '<footer><a href="/">Úvodní stránka</a><a href="/podminky/">Obchodní podmínky</a><a href="/ochrana-udaju/">Ochrana osobních údajů</a><a href="/dsa/">Kontaktní místa (DSA)</a></footer></div>'
      '<script>%s</script></body></html>') % (title, desc, 'noindex' if slug == 'odhlasit' else 'index,follow', FORM_CSS, body, script)
    os.makedirs(D + slug, exist_ok=True)
    open(D + slug + '/index.html', 'w', encoding='utf-8').write(html)
_page('nahlasit', 'Nahlásit nezákonný obsah', 'Oznámení obsahu, který považujete za nezákonný (čl. 16 nařízení o digitálních službách).',
  '<span class="eyebrow">Nařízení o digitálních službách</span><h1>Nahlásit nezákonný obsah</h1>'
  '<p>Formulář slouží k oznámení konkrétního obsahu na webech, e-shopech a rezervačních stránkách, které ve Vexaronetu zveřejnily firmy. Oznámení posoudí člověk; obsah neodstraňujeme automaticky. Přijetí potvrdíme e-mailem.</p>'
  '<form id="f" novalidate><label for="u">Adresa (URL) obsahu <small>Každou adresu na samostatný řádek, nejvýše 10.</small></label><textarea id="u" required rows="3" placeholder="https://vexaronet.com/?w=…"></textarea>'
  '<label for="d">Kde přesně je obsah na stránce (nepovinné)</label><input id="d" maxlength="2000" placeholder="např. sekce Služby, 2. odstavec; obrázek v galerii">'
  '<label for="c">Druh nezákonnosti</label><select id="c" required><option value="">Vyberte…</option><option value="podvod">Podvod nebo klamavá nabídka</option><option value="dusevni_vlastnictvi">Porušení autorských práv nebo ochranné známky</option>'
  '<option value="osobni_udaje">Neoprávněné zveřejnění osobních údajů</option><option value="nenavist">Nenávistný obsah nebo podněcování k násilí</option><option value="nebezpecne_zbozi">Nebezpečné nebo zakázané zboží</option>'
  '<option value="spotrebitel">Porušení práv spotřebitele</option><option value="terorismus">Teroristický obsah</option><option value="csam">Sexuální zneužívání dětí</option><option value="jine">Jiné</option></select>'
  '<label for="x">Proč je obsah nezákonný <small>Dostatečně podložené vysvětlení, nejméně 30 znaků; případně odkaz na předpis.</small></label><textarea id="x" required minlength="30" maxlength="5000"></textarea>'
  '<label for="n">Jméno a příjmení nebo název subjektu <small id="nh">Povinné (u sexuálního zneužívání dětí nepovinné).</small></label><input id="n" autocomplete="name" maxlength="200">'
  '<label for="e">E-mail <small id="eh">Povinný; pošleme na něj potvrzení a rozhodnutí.</small></label><input id="e" type="email" autocomplete="email" maxlength="254">'
  '<label class="chk"><input type="checkbox" id="g" required><span>Prohlašuji, že v dobré víře považuji informace a tvrzení v tomto oznámení za přesné a úplné.</span></label>'
  '<input class="hp" id="hp" tabindex="-1" autocomplete="off" aria-hidden="true">'
  '<button type="submit" id="go">Odeslat oznámení</button><div id="st" class="st" role="status" aria-live="polite" hidden></div></form>'
  '<p class="mut" style="margin-top:22px">Údaje zpracujeme jen k vyřízení oznámení (viz <a href="/ochrana-udaju/">Ochrana osobních údajů</a>). Kontaktní místa: <a href="/dsa/">Kontaktní místa (DSA)</a>.</p>',
  r"""(function(){var f=document.getElementById('f'),st=document.getElementById('st');function $(i){return document.getElementById(i)}
try{var q=new URLSearchParams(location.search).get('u');if(q&&/^https?:\/\/\S{3,1990}$/i.test(q))$('u').value=q}catch(e){}
function msg(t,ok){st.hidden=false;st.className='st '+(ok?'ok':'err');st.textContent=t}
$('c').addEventListener('change',function(){var cs=$('c').value==='csam';$('nh').textContent=cs?'Nepovinné.':'Povinné (u sexuálního zneužívání dětí nepovinné).';$('eh').textContent=cs?'Nepovinný; bez něj vám nepošleme potvrzení.':'Povinný; pošleme na něj potvrzení a rozhodnutí.'});
f.addEventListener('submit',function(e){e.preventDefault();var urls=$('u').value.split(/\s*\n\s*/).map(function(s){return s.trim()}).filter(Boolean),cs=$('c').value==='csam',em=$('e').value.trim(),nm=$('n').value.trim();
 if(!urls.length||urls.length>10||urls.some(function(u){return !/^https?:\/\/\S+$/i.test(u)})){msg('Uveďte 1 až 10 platných adres začínajících http:// nebo https://.');$('u').focus();return}
 if(!$('c').value){msg('Vyberte druh nezákonnosti.');$('c').focus();return}
 if($('x').value.trim().length<30){msg('Vysvětlete prosím podrobněji, proč je obsah nezákonný (nejméně 30 znaků).');$('x').focus();return}
 if(!cs&&(nm.length<2||!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em))){msg('Vyplňte jméno a platný e-mail.');(nm.length<2?$('n'):$('e')).focus();return}
 if(em&&!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)){msg('Zkontrolujte e-mail.');$('e').focus();return}
 if(!$('g').checked){msg('Potvrďte prohlášení o dobré víře.');$('g').focus();return}
 $('go').disabled=true;msg('Odesílám…',true);
 fetch('/api/dsa-notice',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({urls:urls,details:$('d').value,category:$('c').value,explanation:$('x').value,name:nm,email:em,good_faith:true,hp:$('hp').value})})
 .then(function(r){return r.json().then(function(j){return [r.status,j]})}).then(function(a){var s=a[0],j=a[1]||{};$('go').disabled=false;
  if(s===200&&j.ref){f.reset();msg('Oznámení jsme přijali. Referenční číslo: '+j.ref+'.'+(j.ack==='sent'?' Potvrzení jsme poslali e-mailem.':'')+' O rozhodnutí vás budeme informovat.',true);return}
  if(s===429){msg('Odeslali jste příliš mnoho oznámení. Zkuste to prosím později.');return}
  if(s===400){msg('Zkontrolujte prosím vyplněné údaje.');return}
  msg('Oznámení se nepodařilo odeslat. Pošlete ho prosím e-mailem na '+(j.contact||'info@vexaronet.com')+'.')}).catch(function(){$('go').disabled=false;msg('Oznámení se nepodařilo odeslat. Zkuste to prosím znovu.')})})})();""")
_page('odhlasit', 'Odhlášení z novinek', 'Odhlášení z e-mailových novinek Vexaronet.',
  '<span class="eyebrow">Novinky Vexaronet</span><h1>Odhlášení z novinek</h1><div id="box"><p>Načítám…</p></div>',
  r"""(function(){var t='';try{t=new URLSearchParams(location.search).get('t')||''}catch(e){}if(/^[0-9a-f]{64}$/.test(t)){try{history.replaceState(null,'',location.pathname)}catch(e){}}else t='';
var b=document.getElementById('box');
if(!t){b.innerHTML='<p>Odkaz pro odhlášení je neúplný. Použijte prosím celý odkaz z e-mailu, nebo napište na <a href="mailto:info@vexaronet.com">info@vexaronet.com</a> a odhlásíme vás ručně.</p>';return}
b.innerHTML='<p>Kliknutím se odhlásíte z e-mailových novinek Vexaronetu. Nepotřebujete se přihlašovat. Nezbytné zprávy k účtu (např. obnova hesla) tím nevypnete.</p><button type="button" id="go">Odhlásit se z novinek</button><div id="st" class="st" role="status" aria-live="polite" hidden></div>';
document.getElementById('go').addEventListener('click',function(){var g=this,st=document.getElementById('st');g.disabled=true;
 fetch('/api/unsubscribe',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({token:t})}).then(function(r){return r.json().then(function(j){return [r.status,j]})}).then(function(a){st.hidden=false;
  if(a[0]===200&&a[1]&&a[1].ok){st.className='st ok';st.textContent='Hotovo. Z novinek jste odhlášeni a další už vám neposíláme.';g.remove();return}
  g.disabled=false;st.className='st err';st.textContent=a[0]===404||a[0]===400?'Odkaz není platný. Napište prosím na info@vexaronet.com a odhlásíme vás ručně.':'Odhlášení se teď nepodařilo. Zkuste to prosím znovu za chvíli.'})
 .catch(function(){g.disabled=false})})})();""")
print('Stránky: nahlasit, odhlasit')


# ===== Veřejný výstup pro Cloudflare Pages: JEN tyto soubory (allowlist) =====
# Cloudflare Pages nasazuje složku `public/` (Settings → Builds → Build output directory = public).
# Serverové funkce se dál sestavují z `functions/` v kořeni repozitáře a do `public/` se nekopírují.
# Interní soubory (docs/, db/, src/, tests/, tools/, build.py, schémata, *.md…) se tak na web nedostanou.
# Nový veřejný soubor je potřeba přidat sem; test tests/public_dir.py hlídá, že výstup nic nepostrádá ani nepřidává.
import shutil
PUBLIC_FILES = ['index.html', '404.html', 'sw.js', 'manifest.webmanifest', 'robots.txt', 'sitemap.xml', '_headers', '_redirects']
PUBLIC_DIRS = ['assets', 'stazeni'] + list(LEG) + ['nahlasit', 'odhlasit']
_P = D + 'public/'
shutil.rmtree(_P, ignore_errors=True)
os.makedirs(_P)
for _f in PUBLIC_FILES:
    shutil.copy2(D + _f, _P + _f)
for _d in PUBLIC_DIRS:
    shutil.copytree(D + _d, _P + _d)
# _routes.json: serverové funkce se volají jen pro /api/* a pro interní cesty z kořene repozitáře
# (functions/_middleware.js na nich vrátí 404 i tehdy, když Cloudflare drží starou kopii v mezipaměti).
_pub = set(PUBLIC_FILES + PUBLIC_DIRS + ['public'])
_internal = sorted(x for x in os.listdir(D) if not x.startswith('.') and x not in _pub)
_routes = ['/api/*'] + ['/public/*'] + [('/%s/*' % x) if os.path.isdir(D + x) else ('/' + x) for x in _internal]
assert len(_routes) <= 100, 'Cloudflare dovoluje nejvýše 100 pravidel v _routes.json'
open(_P + '_routes.json', 'w', encoding='utf-8').write(json.dumps({'version': 1, 'include': _routes, 'exclude': []}, ensure_ascii=False, indent=1) + '\n')
print('Veřejný výstup public/:', ', '.join(PUBLIC_FILES + [d + '/' for d in PUBLIC_DIRS]))
